/* Script Name : L_MenuSecRef.sql.
   Author      : Manoj Doshi, Ingenium Computing Private Limited On 28th May 1999.
   Description : Inserting initial data into Menu Secuirty Reference Table.                 
*/

/* PROMPT *****[ Starting L_MenuSecRef.sql ]***** */
Delete from T_MenuSecRef;

Insert Into T_MenuSecRef
  ( Menu_Name, Menu_Desc, Menu_Path, SetAble, Menu_ID, Parent_ID )
Values
  ( 'System', 'System', 'System', 1, 1, Null);

Insert Into T_MenuSecRef
  ( Menu_Name, Menu_Desc, Menu_Path, SetAble, Menu_ID, Parent_ID )
Values
  ( 'Logout', 'Logout Of System', 'System|Logout', 1, 2, 1);

Insert Into T_MenuSecRef
  ( Menu_Name, Menu_Desc, Menu_Path, SetAble, Menu_ID, Parent_ID )
Values
  ( 'Change Password', 'Change Password', 'System|Change Password', 1, 3, 1);

Insert Into T_MenuSecRef
    ( Menu_Name, Menu_Desc, Menu_Path, SetAble, Menu_ID, Parent_ID )
Values
  ( 'Administration', 'Administration', 'Administration', 1, 4, Null);

Insert Into T_MenuSecRef
    ( Menu_Name, Menu_Desc, Menu_Path, SetAble, Menu_ID, Parent_ID )
Values
  ( 'Security', 'Secuirty', 'Administration|Security', 1, 5, 4);

Insert Into T_MenuSecRef
    ( Menu_Name, Menu_Desc, Menu_Path, SetAble, Menu_ID, Parent_ID )
Values
  ( 'User', 'User Information', 'Administration|Security|User', 1, 6, 5);

Insert Into T_MenuSecRef
    ( Menu_Name, Menu_Desc, Menu_Path, SetAble, Menu_ID, Parent_ID )
Values
  ( 'Group', 'Group Information', 'Administration|Security|Group', 1, 7, 5);

Insert Into T_MenuSecRef
    ( Menu_Name, Menu_Desc, Menu_Path, SetAble, Menu_ID, Parent_ID )
Values
  ( 'Rights Control', 'Rights Control', 'Administration|Security|Rights Control', 1, 8, 5);

Insert Into T_MenuSecRef
    ( Menu_Name, Menu_Desc, Menu_Path, SetAble, Menu_ID, Parent_ID )
Values
  ( 'Menu', 'Menu Security', 'Administration|Security|Rights Control|Menu', 1, 9, 8);

Insert Into T_MenuSecRef
    ( Menu_Name, Menu_Desc, Menu_Path, SetAble, Menu_ID, Parent_ID )
Values
  ( 'Object', 'Object Security Settings', 'Administration|Security|Rights Control|Object', 1, 10, 8);

Insert Into T_MenuSecRef
    ( Menu_Name, Menu_Desc, Menu_Path, SetAble, Menu_ID, Parent_ID )
Values
  ( 'Record Security', 'Record Security Information', 'Administration|Security|Record Security', 1, 11, 5);

Insert Into T_MenuSecRef
    ( Menu_Name, Menu_Desc, Menu_Path, SetAble, Menu_ID, Parent_ID )
Values
  ( 'Parameter', 'Parameter', 'Administration|Parameter', 1, 12, 4);

Insert Into T_MenuSecRef
    ( Menu_Name, Menu_Desc, Menu_Path, SetAble, Menu_ID, Parent_ID )
Values
  ( 'Message', 'Message', 'Administration|Message', 1, 13, 4);

Insert Into T_MenuSecRef
    ( Menu_Name, Menu_Desc, Menu_Path, SetAble, Menu_ID, Parent_ID )
Values
  ( 'Configuration', 'Security Configuration', 'Administration|Configuration', 1, 14, 4);

Insert Into T_MenuSecRef
    ( Menu_Name, Menu_Desc, Menu_Path, SetAble, Menu_ID, Parent_ID )
Values
  ( 'News Data', 'News Data', 'Administration|New Data', 1, 15, 4);

Insert Into T_MenuSecRef
    ( Menu_Name, Menu_Desc, Menu_Path, SetAble, Menu_ID, Parent_ID )
Values
  ( 'View DataLogs', 'View Data Logs', 'Administration|View DataLogs', 1, 16, 4);

Insert Into T_MenuSecRef
    ( Menu_Name, Menu_Desc, Menu_Path, SetAble, Menu_ID, Parent_ID )
Values
  ( 'Standard Data', 'Standard Data', 'Standard Data', 1, 17, Null);

Insert Into T_MenuSecRef
    ( Menu_Name, Menu_Desc, Menu_Path, SetAble, Menu_ID, Parent_ID )
Values
  ( 'Domain', 'Domain', 'Standard Data|Domain', 1, 18, 17);

Insert Into T_MenuSecRef
    ( Menu_Name, Menu_Desc, Menu_Path, SetAble, Menu_ID, Parent_ID )
Values
  ( 'Address Type', 'Address Type', 'Standard Data|Domain|Address Type', 1, 19, 18);

Insert Into T_MenuSecRef
    ( Menu_Name, Menu_Desc, Menu_Path, SetAble, Menu_ID, Parent_ID )
Values
  ( 'Client Type', 'Client Type', 'Standard Data|Domain|Client Type', 1, 20, 18);

Insert Into T_MenuSecRef
    ( Menu_Name, Menu_Desc, Menu_Path, SetAble, Menu_ID, Parent_ID )
Values
  ( 'Delivery Status', 'Delivery Status', 'Standard Data|Domain|Delivery Status', 1, 21, 18);

Insert Into T_MenuSecRef
    ( Menu_Name, Menu_Desc, Menu_Path, SetAble, Menu_ID, Parent_ID )
Values
  ( 'Function Type', 'Function Type', 'Standard Data|Domain|Function Type', 1, 22, 18);

Insert Into T_MenuSecRef
    ( Menu_Name, Menu_Desc, Menu_Path, SetAble, Menu_ID, Parent_ID )
Values
  ( 'Object Type', 'Object Type', 'Standard Data|Domain|Object Type', 1, 23, 18);

Insert Into T_MenuSecRef
    ( Menu_Name, Menu_Desc, Menu_Path, SetAble, Menu_ID, Parent_ID )
Values
  ( 'Operation Mode', 'Operation Mode', 'Standard Data|Domain|Operation Mode', 1, 24, 18);

Insert Into T_MenuSecRef
    ( Menu_Name, Menu_Desc, Menu_Path, SetAble, Menu_ID, Parent_ID )
Values
  ( 'Order Status', 'Order Status', 'Standard Data|Domain|Order Status', 1, 25, 18);

Insert Into T_MenuSecRef
    ( Menu_Name, Menu_Desc, Menu_Path, SetAble, Menu_ID, Parent_ID )
Values
  ( 'Parameter Class', 'Parameter Class', 'Standard Data|Domain|Parameter Class', 1, 26, 18);

Insert Into T_MenuSecRef
    ( Menu_Name, Menu_Desc, Menu_Path, SetAble, Menu_ID, Parent_ID )
Values
  ( 'Parameter Type', 'Parameter Type', 'Standard Data|Domain|Parameter Type', 1, 27, 18);

Insert Into T_MenuSecRef
    ( Menu_Name, Menu_Desc, Menu_Path, SetAble, Menu_ID, Parent_ID )
Values
  ( 'Security Level', 'Security Level', 'Standard Data|Domain|Security Level', 1, 28, 18);

Insert Into T_MenuSecRef
    ( Menu_Name, Menu_Desc, Menu_Path, SetAble, Menu_ID, Parent_ID )
Values
  ( 'Shipment Type', 'Shipment Type', 'Standard Data|Domain|Shipment Type', 1, 29, 18);

Insert Into T_MenuSecRef
    ( Menu_Name, Menu_Desc, Menu_Path, SetAble, Menu_ID, Parent_ID )
Values
  ( 'Unit Type', 'Unit Type', 'Standard Data|Domain|Unit', 1, 30, 18);

Insert Into T_MenuSecRef
    ( Menu_Name, Menu_Desc, Menu_Path, SetAble, Menu_ID, Parent_ID )
Values
  ( 'Font Color', 'Font Color', 'Standard Data|Domain|Font Color', 1, 31, 18);

Insert Into T_MenuSecRef
    ( Menu_Name, Menu_Desc, Menu_Path, SetAble, Menu_ID, Parent_ID )
Values
  ( 'Font Face', 'Font Face', 'Standard Data|Domain|Font Face', 1, 32, 18);

Insert Into T_MenuSecRef
    ( Menu_Name, Menu_Desc, Menu_Path, SetAble, Menu_ID, Parent_ID )
Values
  ( 'Font Size', 'Font Size', 'Standard Data|Domain|Font Size', 1, 33, 18);

Insert Into T_MenuSecRef
    ( Menu_Name, Menu_Desc, Menu_Path, SetAble, Menu_ID, Parent_ID )
Values
  ( 'Employee', 'Employee Data', 'Standard Data|Employee', 1, 34, 17);

Insert Into T_MenuSecRef
    ( Menu_Name, Menu_Desc, Menu_Path, SetAble, Menu_ID, Parent_ID )
Values
  ( 'Client', 'Client Data', 'Standard Data|Client', 1, 35, 17);

Insert Into T_MenuSecRef
    ( Menu_Name, Menu_Desc, Menu_Path, SetAble, Menu_ID, Parent_ID )
Values
  ( 'Branch', 'Branch Data', 'Standard Data|Branch', 1, 36, 17);

Insert Into T_MenuSecRef
    ( Menu_Name, Menu_Desc, Menu_Path, SetAble, Menu_ID, Parent_ID )
Values
  ( 'Item', 'Item', 'Standard Data|Item', 1, 37, 17);

Insert Into T_MenuSecRef
    ( Menu_Name, Menu_Desc, Menu_Path, SetAble, Menu_ID, Parent_ID )
Values
  ( 'Item Class', 'Item Class', 'Standard Data|Item|Item Class', 1, 38, 37);

Insert Into T_MenuSecRef
    ( Menu_Name, Menu_Desc, Menu_Path, SetAble, Menu_ID, Parent_ID )
Values
  ( 'Item Pack', 'Item Pack', 'Standard Data|Item|Item Pack', 1, 39, 37);

Insert Into T_MenuSecRef
    ( Menu_Name, Menu_Desc, Menu_Path, SetAble, Menu_ID, Parent_ID )
Values
  ( 'Item Group', 'Item Group', 'Standard Data|Item|Item Group', 1, 40, 37);

Insert Into T_MenuSecRef
    ( Menu_Name, Menu_Desc, Menu_Path, SetAble, Menu_ID, Parent_ID )
Values
  ( 'Item Data', 'Item Data', 'Standard Data|Item|Item', 1, 41, 37);

Insert Into T_MenuSecRef
    ( Menu_Name, Menu_Desc, Menu_Path, SetAble, Menu_ID, Parent_ID )
Values
  ( 'ClientItem', 'Client Item', 'Standard Data|Item|ClientItem', 1, 42, 37);

Insert Into T_MenuSecRef
    ( Menu_Name, Menu_Desc, Menu_Path, SetAble, Menu_ID, Parent_ID )
Values
  ( 'Item Rate', 'Item Rate', 'Standard Data|Item|Item Rate', 1, 43, 37);

Insert Into T_MenuSecRef
    ( Menu_Name, Menu_Desc, Menu_Path, SetAble, Menu_ID, Parent_ID )
Values
  ( 'ClientItem Rate', 'ClientItem Rate', 'Standard Data|Item|ClientItem Rate', 1, 44, 37);

Insert Into T_MenuSecRef
    ( Menu_Name, Menu_Desc, Menu_Path, SetAble, Menu_ID, Parent_ID )
Values
  ( 'Address', 'Address', 'Standard Data|Address', 1, 45, 17);

Insert Into T_MenuSecRef
    ( Menu_Name, Menu_Desc, Menu_Path, SetAble, Menu_ID, Parent_ID )
Values
  ( 'Order Administration', 'Order Administration', 'Standard Data|Order Administration', 1, 46, 17);

Insert Into T_MenuSecRef
    ( Menu_Name, Menu_Desc, Menu_Path, SetAble, Menu_ID, Parent_ID )
Values
  ( 'User Relationships', 'User Relationships', 'Standard Data|User Relationships', 1, 47, 17);

Insert Into T_MenuSecRef
    ( Menu_Name, Menu_Desc, Menu_Path, SetAble, Menu_ID, Parent_ID )
Values
  ( 'Transaction', 'Transaction', 'Transaction', 1, 48, Null);

Insert Into T_MenuSecRef
    ( Menu_Name, Menu_Desc, Menu_Path, SetAble, Menu_ID, Parent_ID )
Values
  ( 'Order Entry', 'Order Entry', 'Transaction|Order Entry', 1, 49, 48);

Insert Into T_MenuSecRef
    ( Menu_Name, Menu_Desc, Menu_Path, SetAble, Menu_ID, Parent_ID )
Values
  ( 'Manual', 'Manual|Shopping-Cart', 'Transaction|Order Entry|Manual/Shopping Cart', 1, 50, 49);

Insert Into T_MenuSecRef
    ( Menu_Name, Menu_Desc, Menu_Path, SetAble, Menu_ID, Parent_ID )
Values
  ( 'Using Template', 'From Template', 'Transaction|Order Entry|Using Template', 1, 51, 49);

Insert Into T_MenuSecRef
    ( Menu_Name, Menu_Desc, Menu_Path, SetAble, Menu_ID, Parent_ID )
Values
  ( 'Order Maintenance', 'Order Maintenance', 'Transaction|Order Maintenance', 1, 53, 48);

Insert Into T_MenuSecRef
    ( Menu_Name, Menu_Desc, Menu_Path, SetAble, Menu_ID, Parent_ID )
Values
  ( 'Change Order Status', 'Change Order Status', 'Transaction|Change Order Status', 1, 54, 48);

Insert Into T_MenuSecRef
    ( Menu_Name, Menu_Desc, Menu_Path, SetAble, Menu_ID, Parent_ID )
Values
  ( 'Delivery Entry', 'Delivery Entry', 'Transaction|Delivery Entry', 1, 55, 48);

Insert Into T_MenuSecRef
    ( Menu_Name, Menu_Desc, Menu_Path, SetAble, Menu_ID, Parent_ID )
Values
  ( 'Delivery Maintenance', 'Delivery Maintenance', 'Transaction|Delivery Maintenance', 1, 69, 48);

Insert Into T_MenuSecRef
    ( Menu_Name, Menu_Desc, Menu_Path, SetAble, Menu_ID, Parent_ID )
Values
  ( 'Special Task', 'Special Task', 'Special Task', 1, 56, Null);

Insert Into T_MenuSecRef
    ( Menu_Name, Menu_Desc, Menu_Path, SetAble, Menu_ID, Parent_ID )
Values
  ( 'Preferences', 'Preferences', 'Special Task|Preferences', 1, 57, 56);

Insert Into T_MenuSecRef
    ( Menu_Name, Menu_Desc, Menu_Path, SetAble, Menu_ID, Parent_ID )
Values
  ( 'Define Order Templates', 'Define Order Templates', 'Special Task|Define Order Template', 1, 58, 56);

Insert Into T_MenuSecRef
    ( Menu_Name, Menu_Desc, Menu_Path, SetAble, Menu_ID, Parent_ID )
Values
  ( 'Shopping-Cart Configuration', 'Shopping-Cart Configuration', 'Special Task|Shopping-Cart Configuration', 1, 59, 56);

Insert Into T_MenuSecRef
    ( Menu_Name, Menu_Desc, Menu_Path, SetAble, Menu_ID, Parent_ID )
Values
  ( 'Report', 'Report', 'Special Task|Report', 1, 60, 56);

Insert Into T_MenuSecRef
    ( Menu_Name, Menu_Desc, Menu_Path, SetAble, Menu_ID, Parent_ID )
Values
  ( 'Order Report', 'Order Report', 'Special Task|Report|Order Report', 1, 61, 60);

Insert Into T_MenuSecRef
    ( Menu_Name, Menu_Desc, Menu_Path, SetAble, Menu_ID, Parent_ID )
Values
  ( 'Client Wise Order Report', 'Client Wise Order Report', 'Special Task|Report|Client Wise Order Report', 1, 70, 60);

Insert Into T_MenuSecRef
    ( Menu_Name, Menu_Desc, Menu_Path, SetAble, Menu_ID, Parent_ID )
Values
  ( 'Pending Order Report', 'Pending Order Report', 'Special Task|Report|Pending Order Report', 1, 71, 60);

Insert Into T_MenuSecRef
    ( Menu_Name, Menu_Desc, Menu_Path, SetAble, Menu_ID, Parent_ID )
Values
  ( 'Delivery Order Report', 'Delivery Order Report', 'Special Task|Report|Delivery Order Report', 1, 72, 60);

Insert Into T_MenuSecRef
    ( Menu_Name, Menu_Desc, Menu_Path, SetAble, Menu_ID, Parent_ID )
Values
  ( 'Security Report', 'Security Report', 'Special Task|Report|Security Report', 1, 73, 60);

Insert Into T_MenuSecRef
    ( Menu_Name, Menu_Desc, Menu_Path, SetAble, Menu_ID, Parent_ID )
Values
  ( 'Data Export', 'Data Export', 'Special Task|Data Export', 1, 62, 56);

Insert Into T_MenuSecRef
    ( Menu_Name, Menu_Desc, Menu_Path, SetAble, Menu_ID, Parent_ID )
Values
  ( 'Others', 'Others', 'Others', 1, 63, Null);

Insert Into T_MenuSecRef
    ( Menu_Name, Menu_Desc, Menu_Path, SetAble, Menu_ID, Parent_ID )
Values
  ( 'News Room', 'News Room', 'Others|News Room', 1, 64, 63);

Insert Into T_MenuSecRef
    ( Menu_Name, Menu_Desc, Menu_Path, SetAble, Menu_ID, Parent_ID )
Values
  ( 'Your Query-Suggestions-Feedback-Comment', 'Others|Your Query/Suggestions/Feedback/Comment', 'Others|Your Query-Suggestions-Feedback-Comment', 1, 65, 63);

Insert Into T_MenuSecRef
    ( Menu_Name, Menu_Desc, Menu_Path, SetAble, Menu_ID, Parent_ID )
Values
  ( 'Download Help Manual', 'Download Help Manual', 'Others|Download Help Manual', 1, 66, 63);

Insert Into T_MenuSecRef
    ( Menu_Name, Menu_Desc, Menu_Path, SetAble, Menu_ID, Parent_ID )
Values
  ( 'Help', 'Help', 'Others|Help', 1, 67, 63);

Insert Into T_MenuSecRef
    ( Menu_Name, Menu_Desc, Menu_Path, SetAble, Menu_ID, Parent_ID )
Values
  ( 'About', 'About', 'Others|About', 1, 68, 63);

commit;

/* PROMPT *****[ Ending L_Client.sql ]***** */
