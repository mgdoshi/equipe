/* Script Name : L_Param.sql.
   Author      : Manoj Doshi.
   Description : Inserting initial data into Param Table. 
*/

/* PROMPT *****[ Starting L_Param.sql ]***** */

/* Prompt Creating Param attribute values for Client Type */

Insert Into T_Param
  ( Param_ID, Param_Name, DM_ParType, DM_ParClass, Param_Value, Modifier, Change_Dt )
Values
  ( NEXTVAL('S_Param'), 'DEFAULT_IMAGE_SETTING', 'S', 'A', 'OFF', 'INGDB', 'now'::datetime );

Insert Into T_Param
  ( Param_ID, Param_Name, DM_ParType, DM_ParClass, Param_Value, Modifier, Change_Dt )
Values
  ( NEXTVAL('S_Param'), 'DEFAULT_LANG', 'S', 'A', 'ENG', 'INGDB', 'now'::datetime );

Insert Into T_Param
  ( Param_ID, Param_Name, DM_ParType, DM_ParClass, Param_Value, Modifier, Change_Dt )
Values
  ( NEXTVAL('S_PARAM'), 'DATA_LOGGING', 'C', 'B', 'OFF', 'INGDB', 'now'::datetime );

Insert Into T_Param
  ( Param_ID, Param_Name, DM_ParType, DM_ParClass, Param_Value, Modifier, Change_Dt )
Values
  ( NEXTVAL('S_Param'), 'DEFAULT_FONT', 'S', 'C', 'ARIAL', 'INGDB', 'now'::datetime );

Insert Into T_Param
  ( Param_ID, Param_Name, DM_ParType, DM_ParClass, Param_Value, Modifier, Change_Dt )
Values
  ( NEXTVAL('S_Param'), 'AUTOGEN_ORDER_NR', 'S', 'C', 'ON', 'INGDB', 'now'::datetime );

Insert Into T_Param
  ( Param_ID, Param_Name, DM_ParType, DM_ParClass, Param_Value, Modifier, Change_Dt )
Values
  ( NEXTVAL('S_Param'), 'AUTO_ORDERNR_PREFIX', 'S', 'C', 'ORD/TIN/99/', 'INGDB', 'now'::datetime );

Insert Into T_Param
  ( Param_ID, Param_Name, DM_ParType, DM_ParClass, Param_Value, Modifier, Change_Dt )
Values
  ( NEXTVAL('S_Param'), 'AUTO_ORDERNR_SUFIX', 'S', 'C', '/ING', 'INGDB', 'now'::datetime );

Insert Into T_Param
  ( Param_ID, Param_Name, DM_ParType, DM_ParClass, Param_Value, Modifier, Change_Dt )
Values
  ( NEXTVAL('S_Param'), 'AUTOGEN_DELIVERY_NR', 'S', 'C', 'ON', 'INGDB', 'now'::datetime );

Insert Into T_Param
  ( Param_ID, Param_Name, DM_ParType, DM_ParClass, Param_Value, Modifier, Change_Dt )
Values
  ( NEXTVAL('S_Param'), 'AUTO_DELIVERYNR_PREFIX', 'S', 'C', 'DEL/TIN/99/', 'INGDB', 'now'::datetime );

Insert Into T_Param
  ( Param_ID, Param_Name, DM_ParType, DM_ParClass, Param_Value, Modifier, Change_Dt )
Values
  ( NEXTVAL('S_Param'), 'AUTO_DELIVERYNR_SUFIX', 'S', 'C', '/ING', 'INGDB', 'now'::datetime );

commit;

/* PROMPT *****[ Ending L_Param.sql ]***** */
