/* Script Name : L_Msg.sql.
   Author      : Manoj Doshi.
   Description : Inserting initial data into Message Table.
*/

PROMPT *****[ Starting L_Msg.sql ]*****

Insert Into T_Msg 
  ( Msg_ID, Fk_Lang_ID, Msg_Desc, Modifier, Change_Dt )
Values
  ( 1, 1, 'You are in first record.', 'ORDADM', 'now'::datetime );

Insert Into T_Msg 
  ( Msg_ID, Fk_Lang_ID, Msg_Desc, Modifier, Change_Dt )
Values
  ( 2, 1, 'You are in last record.', 'ORDADM', 'now'::datetime );

Insert Into T_Msg 
  ( Msg_ID, Fk_Lang_ID, Msg_Desc, Modifier, Change_Dt )
Values
  ( 3, 1, 'The record(s) are inserted successfully.', 'ORDADM', 'now'::datetime );

Insert Into T_Msg 
  ( Msg_ID, Fk_Lang_ID, Msg_Desc, Modifier, Change_Dt )
Values
  ( 4, 1, 'The record(s) are deleted successfully.', 'ORDADM', 'now'::datetime );

Insert Into T_Msg 
  ( Msg_ID, Fk_Lang_ID, Msg_Desc, Modifier, Change_Dt )
Values
  ( 5, 1, 'The record(s) are updated successfully.', 'ORDADM', 'now'::datetime );

Insert Into T_Msg 
  ( Msg_ID, Fk_Lang_ID, Msg_Desc, Modifier, Change_Dt )
Values
  ( 6, 1, 'Error : The record(s) are not inserted.', 'ORDADM', 'now'::datetime );

Insert Into T_Msg 
  ( Msg_ID, Fk_Lang_ID, Msg_Desc, Modifier, Change_Dt )
Values
  ( 7, 1, 'Error : The record(s) are not deleted.', 'ORDADM', 'now'::datetime );

Insert Into T_Msg 
  ( Msg_ID, Fk_Lang_ID, Msg_Desc, Modifier, Change_Dt )
Values
  ( 8, 1, 'Error : The record(s) are not updated.', 'ORDADM', 'now'::datetime );

Insert Into T_Msg 
  ( Msg_ID, Fk_Lang_ID, Msg_Desc, Modifier, Change_Dt )
Values
  ( 9, 1, 'Please enter the values for...', 'ORDADM', 'now'::datetime );

Insert Into T_Msg 
  ( Msg_ID, Fk_Lang_ID, Msg_Desc, Modifier, Change_Dt )
Values
  ( 10, 1, 'The data will be saved !Are you sure ?', 'ORDADM', 'now'::datetime );

Insert Into T_Msg 
  ( Msg_ID, Fk_Lang_ID, Msg_Desc, Modifier, Change_Dt )
Values
  ( 11, 1, 'The record(s) will be deleted !.Are you sure ?', 'ORDADM', 'now'::datetime );

Insert Into T_Msg 
  ( Msg_ID, Fk_Lang_ID, Msg_Desc, Modifier, Change_Dt )
Values
  ( 12, 1, 'This is test message.', 'ORDADM', 'now'::datetime );

Insert Into T_Msg 
  ( Msg_ID, Fk_Lang_ID, Msg_Desc, Modifier, Change_Dt )
Values
  ( 13, 1, 'Please enter the value for Item Name.', 'ORDADM', 'now'::datetime );

Insert Into T_Msg 
  ( Msg_ID, Fk_Lang_ID, Msg_Desc, Modifier, Change_Dt )
Values
  ( 14, 1, 'Please enter the Unit Price for Item in Row No.', 'ORDADM', 'now'::datetime );

Insert Into T_Msg 
  ( Msg_ID, Fk_Lang_ID, Msg_Desc, Modifier, Change_Dt )
Values
  ( 15, 1, 'Do you want to continue ?', 'ORDADM', 'now'::datetime );

Insert Into T_Msg 
  ( Msg_ID, Fk_Lang_ID, Msg_Desc, Modifier, Change_Dt )
Values
  ( 16, 1, 'Please select the Client Name.', 'ORDADM', 'now'::datetime );

Insert Into T_Msg 
  ( Msg_ID, Fk_Lang_ID, Msg_Desc, Modifier, Change_Dt )
Values
  ( 17, 1, 'Can not save the blank form !', 'ORDADM', 'now'::datetime );

Insert Into T_Msg 
  ( Msg_ID, Fk_Lang_ID, Msg_Desc, Modifier, Change_Dt )
Values
  ( 18, 1, 'in Row No', 'ORDADM', 'now'::datetime );

Insert Into T_Msg 
  ( Msg_ID, Fk_Lang_ID, Msg_Desc, Modifier, Change_Dt )
Values
  ( 19, 1, 'Please enter unique value in Sequence No. !', 'ORDADM', 'now'::datetime );

Insert Into T_Msg 
  ( Msg_ID, Fk_Lang_ID, Msg_Desc, Modifier, Change_Dt )
Values
  ( 20, 1, 'Please enter unique value for Attribute !', 'ORDADM', 'now'::datetime );

Insert Into T_Msg 
  ( Msg_ID, Fk_Lang_ID, Msg_Desc, Modifier, Change_Dt )
Values
  ( 21, 1, 'Please enter unique value for Attribute Description !', 'ORDADM', 'now'::datetime );

Insert Into T_Msg 
  ( Msg_ID, Fk_Lang_ID, Msg_Desc, Modifier, Change_Dt )
Values
  ( 22, 1, 'You are successfully logged into Equipe.', 'ORDADM', 'now'::datetime );

Insert Into T_Msg 
  ( Msg_ID, Fk_Lang_ID, Msg_Desc, Modifier, Change_Dt )
Values
  ( 23, 1, 'Illegal Entry | Please re-enter valid Username/Password !', 'ORDADM', 'now'::datetime );

Insert Into T_Msg 
  ( Msg_ID, Fk_Lang_ID, Msg_Desc, Modifier, Change_Dt )
Values
  ( 24, 1, 'Please enter a valid number !', 'ORDADM', 'now'::datetime );

Insert Into T_Msg 
  ( Msg_ID, Fk_Lang_ID, Msg_Desc, Modifier, Change_Dt )
Values
  ( 25, 1, 'character is not allowed.', 'ORDADM', 'now'::datetime );

Insert Into T_Msg 
  ( Msg_ID, Fk_Lang_ID, Msg_Desc, Modifier, Change_Dt )
Values
  ( 26, 1, 'Please select the Group Name !', 'ORDADM', 'now'::datetime );

Insert Into T_Msg 
  ( Msg_ID, Fk_Lang_ID, Msg_Desc, Modifier, Change_Dt )
Values
  ( 27, 1, 'Please select the User Name !', 'ORDADM', 'now'::datetime );

Insert Into T_Msg 
  ( Msg_ID, Fk_Lang_ID, Msg_Desc, Modifier, Change_Dt )
Values
  ( 28, 1, 'Please select the Form Name !', 'ORDADM', 'now'::datetime );

Insert Into T_Msg 
  ( Msg_ID, Fk_Lang_ID, Msg_Desc, Modifier, Change_Dt )
Values
  ( 29, 1, 'Please enter a valid User Name !', 'ORDADM', 'now'::datetime );

Insert Into T_Msg 
  ( Msg_ID, Fk_Lang_ID, Msg_Desc, Modifier, Change_Dt )
Values
  ( 30, 1, 'Please enter a valid Password !', 'ORDADM', 'now'::datetime );

Insert Into T_Msg 
  ( Msg_ID, Fk_Lang_ID, Msg_Desc, Modifier, Change_Dt )
Values
  ( 31, 1, 'New Password and Confirm Password must be same !', 'ORDADM', 'now'::datetime );

Insert Into T_Msg 
  ( Msg_ID, Fk_Lang_ID, Msg_Desc, Modifier, Change_Dt )
Values
  ( 32, 1, 'Please select a Shopping Cart Name !', 'ORDADM', 'now'::datetime );

Insert Into T_Msg 
  ( Msg_ID, Fk_Lang_ID, Msg_Desc, Modifier, Change_Dt )
Values
  ( 33, 1, 'Please select an Order Template Name !', 'ORDADM', 'now'::datetime );

Insert Into T_Msg 
  ( Msg_ID, Fk_Lang_ID, Msg_Desc, Modifier, Change_Dt )
Values
  ( 34, 1, 'Please enter unique value for Position No. !', 'ORDADM', 'now'::datetime );

Insert Into T_Msg 
  ( Msg_ID, Fk_Lang_ID, Msg_Desc, Modifier, Change_Dt )
Values
  ( 35, 1, 'Please enter unique value for Item Name !', 'ORDADM', 'now'::datetime );

Insert Into T_Msg 
  ( Msg_ID, Fk_Lang_ID, Msg_Desc, Modifier, Change_Dt )
Values
  ( 36, 1, 'is already blank, Please enter data.', 'ORDADM', 'now'::datetime );

Insert Into T_Msg 
  ( Msg_ID, Fk_Lang_ID, Msg_Desc, Modifier, Change_Dt )
Values
  ( 37, 1, 'Do you want to set the current Order Status to OPEN ?', 'ORDADM', 'now'::datetime );

Insert Into T_Msg 
  ( Msg_ID, Fk_Lang_ID, Msg_Desc, Modifier, Change_Dt )
Values
  ( 38, 1, 'Please enter the Order No. !', 'ORDADM', 'now'::datetime );

Insert Into T_Msg 
  ( Msg_ID, Fk_Lang_ID, Msg_Desc, Modifier, Change_Dt )
Values
  ( 39, 1, 'Please enter unique value for Order No. !', 'ORDADM', 'now'::datetime );

Insert Into T_Msg 
  ( Msg_ID, Fk_Lang_ID, Msg_Desc, Modifier, Change_Dt )
Values
  ( 40, 1, 'Note...Order No', 'ORDADM', 'now'::datetime );

Insert Into T_Msg 
  ( Msg_ID, Fk_Lang_ID, Msg_Desc, Modifier, Change_Dt )
Values
  ( 41, 1, 'Note...Status of Order No', 'ORDADM', 'now'::datetime );

Insert Into T_Msg 
  ( Msg_ID, Fk_Lang_ID, Msg_Desc, Modifier, Change_Dt )
Values
  ( 42, 1, 'is CLOSED.', 'ORDADM', 'now'::datetime );

Insert Into T_Msg 
  ( Msg_ID, Fk_Lang_ID, Msg_Desc, Modifier, Change_Dt )
Values
  ( 43, 1, 'does not belong to Client :', 'ORDADM', 'now'::datetime );

Insert Into T_Msg 
  ( Msg_ID, Fk_Lang_ID, Msg_Desc, Modifier, Change_Dt )
Values
  ( 44, 1, 'Delivery No. already exists !', 'ORDADM', 'now'::datetime );

Insert Into T_Msg 
  ( Msg_ID, Fk_Lang_ID, Msg_Desc, Modifier, Change_Dt )
Values
  ( 45, 1, 'Order No. already exists !', 'ORDADM', 'now'::datetime );

Insert Into T_Msg 
  ( Msg_ID, Fk_Lang_ID, Msg_Desc, Modifier, Change_Dt )
Values
  ( 46, 1, 'Branch Name already exists !', 'ORDADM', 'now'::datetime );

Insert Into T_Msg 
  ( Msg_ID, Fk_Lang_ID, Msg_Desc, Modifier, Change_Dt )
Values
  ( 47, 1, 'Client Name already exists !', 'ORDADM', 'now'::datetime );

Insert Into T_Msg 
  ( Msg_ID, Fk_Lang_ID, Msg_Desc, Modifier, Change_Dt )
Values
  ( 48, 1, 'Client Code already exists !', 'ORDADM', 'now'::datetime );

Insert Into T_Msg 
  ( Msg_ID, Fk_Lang_ID, Msg_Desc, Modifier, Change_Dt )
Values
  ( 49, 1, 'Employee Name already exists !', 'ORDADM', 'now'::datetime );

Insert Into T_Msg 
  ( Msg_ID, Fk_Lang_ID, Msg_Desc, Modifier, Change_Dt )
Values
  ( 50, 1, 'You are successfully logged out from Equipe !', 'ORDADM', 'now'::datetime );

Insert Into T_Msg 
  ( Msg_ID, Fk_Lang_ID, Msg_Desc, Modifier, Change_Dt )
Values
  ( 51, 1, ' Group Name already exists ! ', 'ORDADM', 'now'::datetime );

Insert Into T_Msg 
  ( Msg_ID, Fk_Lang_ID, Msg_Desc, Modifier, Change_Dt )
Values
  ( 52, 1, ' Item Name already exists ! ', 'ORDADM', 'now'::datetime );

Insert Into T_Msg 
  ( Msg_ID, Fk_Lang_ID, Msg_Desc, Modifier, Change_Dt )
Values
  ( 53, 1, ' Item Class name already exists ! ', 'ORDADM', 'now'::datetime );

Insert Into T_Msg 
  ( Msg_ID, Fk_Lang_ID, Msg_Desc, Modifier, Change_Dt )
Values
  ( 54, 1, ' ItemGroup Name already exists ! ', 'ORDADM', 'now'::datetime );

Insert Into T_Msg 
  ( Msg_ID, Fk_Lang_ID, Msg_Desc, Modifier, Change_Dt )
Values
  ( 55, 1, ' ItemPack Name already exists ! ', 'ORDADM', 'now'::datetime );

Insert Into T_Msg 
  ( Msg_ID, Fk_Lang_ID, Msg_Desc, Modifier, Change_Dt )
Values
  ( 56, 1, ' Combination of Message ID and Language must be unique ! ', 'ORDADM', 'now'::datetime );

Insert Into T_Msg 
  ( Msg_ID, Fk_Lang_ID, Msg_Desc, Modifier, Change_Dt )
Values
  ( 57, 1, ' User Name already exists ! ', 'ORDADM', 'now'::datetime );

Insert Into T_Msg 
  ( Msg_ID, Fk_Lang_ID, Msg_Desc, Modifier, Change_Dt )
Values
  ( 58, 1, ' Record Security Name already exists ! ', 'ORDADM', 'now'::datetime );

Insert Into T_Msg 
  ( Msg_ID, Fk_Lang_ID, Msg_Desc, Modifier, Change_Dt )
Values
  ( 59, 1, ' Param Name already exists ! ', 'ORDADM', 'now'::datetime );

Insert Into T_Msg 
  ( Msg_ID, Fk_Lang_ID, Msg_Desc, Modifier, Change_Dt )
Values
  ( 60, 1, ' Shopping Cart Name already exists ! ', 'ORDADM', 'now'::datetime );

Insert Into T_Msg 
  ( Msg_ID, Fk_Lang_ID, Msg_Desc, Modifier, Change_Dt )
Values
  ( 61, 1, ' Template Name already exists ! ', 'ORDADM', 'now'::datetime );

Insert Into T_Msg 
  ( Msg_ID, Fk_Lang_ID, Msg_Desc, Modifier, Change_Dt )
Values
  ( 62, 1, ' Check the Deletion checkboxes to mark records for deletion !', 'ORDADM', 'now'::datetime );

Insert Into T_Msg 
  ( Msg_ID, Fk_Lang_ID, Msg_Desc, Modifier, Change_Dt )
Values
  ( 63, 1, ' Check the Print checkboxed to mark records to Print !', 'ORDADM', 'now'::datetime );

Insert Into T_Msg 
  ( Msg_ID, Fk_Lang_ID, Msg_Desc, Modifier, Change_Dt )
Values
  ( 64, 1, 'Deletion of Kernel Control Parameters is not allowed !', 'ORDADM', 'now'::datetime );

Insert Into T_Msg 
  ( Msg_ID, Fk_Lang_ID, Msg_Desc, Modifier, Change_Dt )
Values
  ( 65, 1, 'Please donot select the Shopping Cart !', 'ORDADM', 'now'::datetime );

Insert Into T_Msg 
  ( Msg_ID, Fk_Lang_ID, Msg_Desc, Modifier, Change_Dt )
Values
  ( 66, 1, 'Please donot select the Order Template Name !', 'ORDADM', 'now'::datetime );

Insert Into T_Msg 
  ( Msg_ID, Fk_Lang_ID, Msg_Desc, Modifier, Change_Dt )
Values
  ( 101, 1, 'Click here to update current record !', 'ORDADM', 'now'::datetime );

Insert Into T_Msg 
  ( Msg_ID, Fk_Lang_ID, Msg_Desc, Modifier, Change_Dt )
Values
  ( 102, 1, 'Click here to delete selected records !', 'ORDADM', 'now'::datetime );

Insert Into T_Msg 
  ( Msg_ID, Fk_Lang_ID, Msg_Desc, Modifier, Change_Dt )
Values
  ( 103, 1, 'Click here to add new record !', 'ORDADM', 'now'::datetime );

Insert Into T_Msg 
  ( Msg_ID, Fk_Lang_ID, Msg_Desc, Modifier, Change_Dt )
Values
  ( 104, 1, 'Click here to save current record !', 'ORDADM', 'now'::datetime );

Insert Into T_Msg 
  ( Msg_ID, Fk_Lang_ID, Msg_Desc, Modifier, Change_Dt )
Values
  ( 105, 1, 'Click here to assign Clients for Item !', 'ORDADM', 'now'::datetime );

Insert Into T_Msg 
  ( Msg_ID, Fk_Lang_ID, Msg_Desc, Modifier, Change_Dt )
Values
  ( 106, 1, 'Click here to Assign Items to Client !', 'ORDADM', 'now'::datetime );

Insert Into T_Msg 
  ( Msg_ID, Fk_Lang_ID, Msg_Desc, Modifier, Change_Dt )
Values
  ( 107, 1, 'Click here to create Delivery for Orders !', 'ORDADM', 'now'::datetime );

Insert Into T_Msg 
  ( Msg_ID, Fk_Lang_ID, Msg_Desc, Modifier, Change_Dt )
Values
  ( 108, 1, 'Click here to create Order from predefined Template !', 'ORDADM', 'now'::datetime );

Insert Into T_Msg 
  ( Msg_ID, Fk_Lang_ID, Msg_Desc, Modifier, Change_Dt )
Values
  ( 109, 1, 'Click here to create new Template from an existing Order !', 'ORDADM', 'now'::datetime );

Insert Into T_Msg 
  ( Msg_ID, Fk_Lang_ID, Msg_Desc, Modifier, Change_Dt )
Values
  ( 110, 1, 'Click here to create new Template from an existing Template !', 'ORDADM', 'now'::datetime );

Insert Into T_Msg 
  ( Msg_ID, Fk_Lang_ID, Msg_Desc, Modifier, Change_Dt )
Values
  ( 111, 1, 'Click here to select Orders for Delivery !', 'ORDADM', 'now'::datetime );

Insert Into T_Msg 
  ( Msg_ID, Fk_Lang_ID, Msg_Desc, Modifier, Change_Dt )
Values
  ( 112, 1, 'Click here to select Items for Ordering !', 'ORDADM', 'now'::datetime );

Insert Into T_Msg 
  ( Msg_ID, Fk_Lang_ID, Msg_Desc, Modifier, Change_Dt )
Values
  ( 113, 1, 'Click here to assign Item Rates !', 'ORDADM', 'now'::datetime );

Insert Into T_Msg 
  ( Msg_ID, Fk_Lang_ID, Msg_Desc, Modifier, Change_Dt )
Values
  ( 114, 1, 'Click here to Update/Delete ItemRates !', 'ORDADM', 'now'::datetime );

Insert Into T_Msg 
  ( Msg_ID, Fk_Lang_ID, Msg_Desc, Modifier, Change_Dt )
Values
  ( 115, 1, 'Click here to add Address !', 'ORDADM', 'now'::datetime );

Insert Into T_Msg 
  ( Msg_ID, Fk_Lang_ID, Msg_Desc, Modifier, Change_Dt )
Values
  ( 116, 1, 'Click here to Update/Delete Addresses !', 'ORDADM', 'now'::datetime );

Insert Into T_Msg 
  ( Msg_ID, Fk_Lang_ID, Msg_Desc, Modifier, Change_Dt )
Values
  ( 117, 1, 'Click here to assign Users to a Group !', 'ORDADM', 'now'::datetime );

Insert Into T_Msg 
  ( Msg_ID, Fk_Lang_ID, Msg_Desc, Modifier, Change_Dt )
Values
  ( 118, 1, 'Click here to assign Groups to a User !', 'ORDADM', 'now'::datetime );

Insert Into T_Msg 
  ( Msg_ID, Fk_Lang_ID, Msg_Desc, Modifier, Change_Dt )
Values
  ( 119, 1, 'Click here to mark a Draft Order to Open !', 'ORDADM', 'now'::datetime );

Insert Into T_Msg 
  ( Msg_ID, Fk_Lang_ID, Msg_Desc, Modifier, Change_Dt )
Values
  ( 120, 1, 'Click here to assign Employee Functions !', 'ORDADM', 'now'::datetime );

Insert Into T_Msg 
  ( Msg_ID, Fk_Lang_ID, Msg_Desc, Modifier, Change_Dt )
Values
  ( 121, 1, 'Click here to get information about current form.', 'ORDADM', 'now'::datetime );

Insert Into T_Msg 
  ( Msg_ID, Fk_Lang_ID, Msg_Desc, Modifier, Change_Dt )
Values
  ( 122, 1, 'Click here to get Help on using current form.', 'ORDADM', 'now'::datetime );

Insert Into T_Msg 
  ( Msg_ID, Fk_Lang_ID, Msg_Desc, Modifier, Change_Dt )
Values
  ( 123, 1, 'Click here to get System Help.', 'ORDADM', 'now'::datetime );

Insert Into T_Msg 
  ( Msg_ID, Fk_Lang_ID, Msg_Desc, Modifier, Change_Dt )
Values
  ( 124, 1, 'Click here to select Items for Shopping Cart.', 'ORDADM', 'now'::datetime );

Insert Into T_Msg 
  ( Msg_ID, Fk_Lang_ID, Msg_Desc, Modifier, Change_Dt )
Values
  ( 125, 1, 'Click here to save current and add a new record !', 'ORDADM', 'now'::datetime );

Insert Into T_Msg 
  ( Msg_ID, Fk_Lang_ID, Msg_Desc, Modifier, Change_Dt )
Values
  ( 126, 1, 'Click here to query the records !', 'ORDADM', 'now'::datetime );

Insert Into T_Msg 
  ( Msg_ID, Fk_Lang_ID, Msg_Desc, Modifier, Change_Dt )
Values
  ( 127, 1, 'Click here to query the List.', 'ORDADM', 'now'::datetime );

Insert Into T_Msg 
  ( Msg_ID, Fk_Lang_ID, Msg_Desc, Modifier, Change_Dt )
Values
  ( 128, 1, 'Click here to view next batch of records !', 'ORDADM', 'now'::datetime );

Insert Into T_Msg 
  ( Msg_ID, Fk_Lang_ID, Msg_Desc, Modifier, Change_Dt )
Values
  ( 129, 1, 'Click here to view previous batch of records !', 'ORDADM', 'now'::datetime );

Insert Into T_Msg 
  ( Msg_ID, Fk_Lang_ID, Msg_Desc, Modifier, Change_Dt )
Values
  ( 130, 1, 'Click here to assign Record Security Privileges !', 'ORDADM', 'now'::datetime );

Insert Into T_Msg 
  ( Msg_ID, Fk_Lang_ID, Msg_Desc, Modifier, Change_Dt )
Values
  ( 131, 1, 'Click here to update current record !', 'ORDADM', 'now'::datetime );

Insert Into T_Msg 
  ( Msg_ID, Fk_Lang_ID, Msg_Desc, Modifier, Change_Dt )
Values
  ( 132, 1, 'Click here to insert more records !', 'ORDADM', 'now'::datetime );

Insert Into T_Msg 
  ( Msg_ID, Fk_Lang_ID, Msg_Desc, Modifier, Change_Dt )
Values
  ( 133, 1, 'Click here to create new Template Details !', 'ORDADM', 'now'::datetime );

Insert Into T_Msg 
  ( Msg_ID, Fk_Lang_ID, Msg_Desc, Modifier, Change_Dt )
Values
  ( 134, 1, 'Click here to Delete/Update Template Details !', 'ORDADM', 'now'::datetime );

Insert Into T_Msg 
  ( Msg_ID, Fk_Lang_ID, Msg_Desc, Modifier, Change_Dt )
Values
  ( 135, 1, 'Click here to Define User RelationShips !', 'ORDADM', 'now'::datetime );

Insert Into T_Msg 
  ( Msg_ID, Fk_Lang_ID, Msg_Desc, Modifier, Change_Dt )
Values
  ( 136, 1, 'Click here to view Scheme Preview !', 'ORDADM', 'now'::datetime );

Insert Into T_Msg 
  ( Msg_ID, Fk_Lang_ID, Msg_Desc, Modifier, Change_Dt )
Values
  ( 137, 1, 'Click here to create User-Item relationship !', 'ORDADM', 'now'::datetime );

Insert Into T_Msg 
  ( Msg_ID, Fk_Lang_ID, Msg_Desc, Modifier, Change_Dt )
Values
  ( 138, 1, 'Please enter the date in DD.MM.YYYY format only !', 'ORDADM', 'now'::datetime );

Insert Into T_Msg 
  ( Msg_ID, Fk_Lang_ID, Msg_Desc, Modifier, Change_Dt )
Values
  ( 139, 1, 'Click here for System Help', 'ORDADM', 'now'::datetime );

Insert Into T_Msg 
  ( Msg_ID, Fk_Lang_ID, Msg_Desc, Modifier, Change_Dt )
Values
  ( 140, 1, 'The current record will be cleared !  Are you sure ?', 'ORDADM', 'now'::datetime );

Commit;

PROMPT *****[ Ending L_Msg.sql ]*****
