/* Script Name : L_Domain.sql.
   Author      : Manoj Doshi.
   Description : Inserting initial data into Domain Table. 
*/

/* PROMPT *****[ Starting L_Domain.sql ]***** */

/* Prompt Creating domain attribute values for Client Type  */

Insert Into T_Domain
  ( Domain, Domain_Name, Sequence_Nr, Attrib, Attrib_Desc, FK_Lang_ID, Modifier, Change_Dt )
Values
  ( 'CLNTYPE', 'Client Type', 1, 'I', 'Internal Client', 1, 'INGDB', 'now'::datetime );

Insert Into T_Domain
  ( Domain, Domain_Name, Sequence_Nr, Attrib, Attrib_Desc, FK_Lang_ID, Modifier, Change_Dt )
Values
  ( 'CLNTYPE', 'Client Type', 2, 'S', 'Distributor', 1, 'INGDB', 'now'::datetime );

Insert Into T_Domain
  ( Domain, Domain_Name, Sequence_Nr, Attrib, Attrib_Desc, FK_Lang_ID, Modifier, Change_Dt )
Values
  ( 'CLNTYPE', 'Client Type', 3, 'D', 'Dealer', 1, 'INGDB', 'now'::datetime );

Insert Into T_Domain
  ( Domain, Domain_Name, Sequence_Nr, Attrib, Attrib_Desc, FK_Lang_ID, Modifier, Change_Dt )
Values
  ( 'CLNTYPE', 'Client Type', 4, 'A', 'Agent', 1, 'INGDB', 'now'::datetime );

Insert Into T_Domain
  ( Domain, Domain_Name, Sequence_Nr, Attrib, Attrib_Desc, FK_Lang_ID, Modifier, Change_Dt )
Values
  ( 'CLNTYPE', 'Client Type', 5, 'W', 'Warehouse', 1, 'INGDB', 'now'::datetime );

Insert Into T_Domain
  ( Domain, Domain_Name, Sequence_Nr, Attrib, Attrib_Desc, FK_Lang_ID, Modifier, Change_Dt )
Values
  ( 'CLNTYPE', 'Client Type', 6, 'C', 'Consumer', 1, 'INGDB', 'now'::datetime );

Insert Into T_Domain
  ( Domain, Domain_Name, Sequence_Nr, Attrib, Attrib_Desc, FK_Lang_ID, Modifier, Change_Dt )
Values
  ( 'CLNTYPE', 'Client Type', 7, 'T', 'Transporter', 1, 'INGDB', 'now'::datetime );

Insert Into T_Domain
  ( Domain, Domain_Name, Sequence_Nr, Attrib, Attrib_Desc, FK_Lang_ID, Modifier, Change_Dt )
Values
  ( 'CLNTYPE', 'Client Type', 8, 'P', 'Supplier', 1, 'INGDB', 'now'::datetime );

commit;

/* Prompt Creating domain attribute values for Address Type */

Insert Into T_Domain
  ( Domain, Domain_Name, Sequence_Nr, Attrib, Attrib_Desc, FK_Lang_ID, Modifier, Change_Dt )
Values
  ( 'ADDTYPE', 'Address Type', 1, 'H', 'Head Office', 1, 'INGDB', 'now'::datetime );

Insert Into T_Domain
  ( Domain, Domain_Name, Sequence_Nr, Attrib, Attrib_Desc, FK_Lang_ID, Modifier, Change_Dt )
Values
  ( 'ADDTYPE', 'Address Type', 2, 'B', 'Branch Office', 1, 'INGDB', 'now'::datetime );

Insert Into T_Domain
  ( Domain, Domain_Name, Sequence_Nr, Attrib, Attrib_Desc, FK_Lang_ID, Modifier, Change_Dt )
Values
  ( 'ADDTYPE', 'Address Type', 3, 'F', 'Factory', 1, 'INGDB', 'now'::datetime );

Insert Into T_Domain
  ( Domain, Domain_Name, Sequence_Nr, Attrib, Attrib_Desc, FK_Lang_ID, Modifier, Change_Dt )
Values
  ( 'ADDTYPE', 'Address Type', 4, 'W', 'Warehouse', 1, 'INGDB', 'now'::datetime );

Insert Into T_Domain
  ( Domain, Domain_Name, Sequence_Nr, Attrib, Attrib_Desc, FK_Lang_ID, Modifier, Change_Dt )
Values
  ( 'ADDTYPE', 'Address Type', 5, 'P', 'Private', 1, 'INGDB', 'now'::datetime );

commit;

/* Prompt Creating domain attribute values for Order Status */

/* Order status can be Draft->Open->OpenReceived->InProcess->Shipped->Received->Closed. */
/* The status should have stages from B to Z. Draft should be status A.
'A' means open and 'Z' means closed. The whole idea of creating such range/stage
is to give clear-cut client settable statuses. Even intermediate status can be 
defined and set by various departments so that correct picture is always available. 
It would be a good idea to give enuf spaces in between two statuses while defining 
so that additions r possible in future. */

Insert Into T_Domain
  ( Domain, Domain_Name, Sequence_Nr, Attrib, Attrib_Desc, FK_Lang_ID, Modifier, Change_Dt )
Values
  ( 'ORDSTAT', 'Order Status', 1, 'A', 'Draft', 1, 'INGDB', 'now'::datetime );

Insert Into T_Domain
  ( Domain, Domain_Name, Sequence_Nr, Attrib, Attrib_Desc, FK_Lang_ID, Modifier, Change_Dt )
Values
  ( 'ORDSTAT', 'Order Status', 2, 'D', 'Open', 1, 'INGDB', 'now'::datetime );

Insert Into T_Domain
  ( Domain, Domain_Name, Sequence_Nr, Attrib, Attrib_Desc, FK_Lang_ID, Modifier, Change_Dt )
Values
  ( 'ORDSTAT', 'Order Status', 3, 'G', 'OpenReceived', 1, 'INGDB', 'now'::datetime );

Insert Into T_Domain
  ( Domain, Domain_Name, Sequence_Nr, Attrib, Attrib_Desc, FK_Lang_ID, Modifier, Change_Dt )
Values
  ( 'ORDSTAT', 'Order Status', 4, 'J', 'InProcess', 1, 'INGDB', 'now'::datetime );

Insert Into T_Domain
  ( Domain, Domain_Name, Sequence_Nr, Attrib, Attrib_Desc, FK_Lang_ID, Modifier, Change_Dt )
Values
  ( 'ORDSTAT', 'Order Status', 5, 'R', 'Shipped', 1, 'INGDB', 'now'::datetime );

Insert Into T_Domain
  ( Domain, Domain_Name, Sequence_Nr, Attrib, Attrib_Desc, FK_Lang_ID, Modifier, Change_Dt )
Values
  ( 'ORDSTAT', 'Order Status', 6, 'U', 'Received', 1, 'INGDB', 'now'::datetime );

Insert Into T_Domain
  ( Domain, Domain_Name, Sequence_Nr, Attrib, Attrib_Desc, FK_Lang_ID, Modifier, Change_Dt )
Values
  ( 'ORDSTAT', 'Order Status', 7, 'Z', 'Closed', 1, 'INGDB', 'now'::datetime );

commit;

/* Prompt Creating domain attribute values for Delivery Status */

Insert Into T_Domain
  ( Domain, Domain_Name, Sequence_Nr, Attrib, Attrib_Desc, FK_Lang_ID, Modifier, Change_Dt )
Values
  ( 'DELSTAT', 'Delivery Status', 1, 'A', 'InProcess', 1, 'INGDB', 'now'::datetime );

Insert Into T_Domain
  ( Domain, Domain_Name, Sequence_Nr, Attrib, Attrib_Desc, FK_Lang_ID, Modifier, Change_Dt )
Values
  ( 'DELSTAT', 'Delivery Status', 2, 'D', 'Shipped', 1, 'INGDB', 'now'::datetime );

Insert Into T_Domain
  ( Domain, Domain_Name, Sequence_Nr, Attrib, Attrib_Desc, FK_Lang_ID, Modifier, Change_Dt )
Values
  ( 'DELSTAT', 'Delivery Status', 3, 'G', 'Received', 1, 'INGDB', 'now'::datetime );

Insert Into T_Domain
  ( Domain, Domain_Name, Sequence_Nr, Attrib, Attrib_Desc, FK_Lang_ID, Modifier, Change_Dt )
Values
  ( 'DELSTAT', 'Delivery Status', 4, 'Z', 'Closed', 1, 'INGDB', 'now'::datetime );


commit;

/* Prompt Creating domain attribute values for Delivery Status */

Insert Into T_Domain
  ( Domain, Domain_Name, Sequence_Nr, Attrib, Attrib_Desc, FK_Lang_ID, Modifier, Change_Dt )
Values
  ( 'SHIPMODE', 'Shipping Mode', 1, 'R', 'Road Transport', 1, 'INGDB', 'now'::datetime );

Insert Into T_Domain
  ( Domain, Domain_Name, Sequence_Nr, Attrib, Attrib_Desc, FK_Lang_ID, Modifier, Change_Dt )
Values
  ( 'SHIPMODE', 'Shipping Mode', 2, 'A', 'Air Transport', 1, 'INGDB', 'now'::datetime );

Insert Into T_Domain
  ( Domain, Domain_Name, Sequence_Nr, Attrib, Attrib_Desc, FK_Lang_ID, Modifier, Change_Dt )
Values
  ( 'SHIPMODE', 'Shipping Mode', 3, 'C', 'Courier', 1, 'INGDB', 'now'::datetime );

Insert Into T_Domain
  ( Domain, Domain_Name, Sequence_Nr, Attrib, Attrib_Desc, FK_Lang_ID, Modifier, Change_Dt )
Values
  ( 'SHIPMODE', 'Shipping Mode', 4, 'W', 'Ocean Liner', 1, 'INGDB', 'now'::datetime );

commit;

/* Prompt Creating domain attribute values for Unit Types */

Insert Into T_Domain
  ( Domain, Domain_Name, Sequence_Nr, Attrib, Attrib_Desc, FK_Lang_ID, Modifier, Change_Dt )
Values
  ( 'UNITTYPE', 'Unit Type', 1, 'Z', 'no.s', 1, 'INGDB', 'now'::datetime );

Insert Into T_Domain
  ( Domain, Domain_Name, Sequence_Nr, Attrib, Attrib_Desc, FK_Lang_ID, Modifier, Change_Dt )
Values
  ( 'UNITTYPE', 'Unit Type', 2, 'A', 'Kgs', 1, 'INGDB', 'now'::datetime );

Insert Into T_Domain
  ( Domain, Domain_Name, Sequence_Nr, Attrib, Attrib_Desc, FK_Lang_ID, Modifier, Change_Dt )
Values
  ( 'UNITTYPE', 'Unit Type', 3, 'B', 'Gms', 1, 'INGDB', 'now'::datetime );

Insert Into T_Domain
  ( Domain, Domain_Name, Sequence_Nr, Attrib, Attrib_Desc, FK_Lang_ID, Modifier, Change_Dt )
Values
  ( 'UNITTYPE', 'Unit Type', 4, 'C', 'Tons', 1, 'INGDB', 'now'::datetime );

Insert Into T_Domain
  ( Domain, Domain_Name, Sequence_Nr, Attrib, Attrib_Desc, FK_Lang_ID, Modifier, Change_Dt )
Values
  ( 'UNITTYPE', 'Unit Type', 5, 'D', 'Quintals', 1, 'INGDB', 'now'::datetime );

Insert Into T_Domain
  ( Domain, Domain_Name, Sequence_Nr, Attrib, Attrib_Desc, FK_Lang_ID, Modifier, Change_Dt )
Values
  ( 'UNITTYPE', 'Unit Type', 6, 'E', 'Litres', 1, 'INGDB', 'now'::datetime );

Insert Into T_Domain
  ( Domain, Domain_Name, Sequence_Nr, Attrib, Attrib_Desc, FK_Lang_ID, Modifier, Change_Dt )
Values
  ( 'UNITTYPE', 'Unit Type', 7, 'F', 'MiliLitres', 1, 'INGDB', 'now'::datetime );

Insert Into T_Domain
  ( Domain, Domain_Name, Sequence_Nr, Attrib, Attrib_Desc, FK_Lang_ID, Modifier, Change_Dt )
Values
  ( 'UNITTYPE', 'Unit Type', 8, 'G', 'KiloLitres', 1, 'INGDB', 'now'::datetime );

Insert Into T_Domain
  ( Domain, Domain_Name, Sequence_Nr, Attrib, Attrib_Desc, FK_Lang_ID, Modifier, Change_Dt )
Values
  ( 'UNITTYPE', 'Unit Type', 9, 'H', 'Meters', 1, 'INGDB', 'now'::datetime );

Insert Into T_Domain
  ( Domain, Domain_Name, Sequence_Nr, Attrib, Attrib_Desc, FK_Lang_ID, Modifier, Change_Dt )
Values
  ( 'UNITTYPE', 'Unit Type', 10, 'I', 'cms', 1, 'INGDB', 'now'::datetime );

Insert Into T_Domain
  ( Domain, Domain_Name, Sequence_Nr, Attrib, Attrib_Desc, FK_Lang_ID, Modifier, Change_Dt )
Values
  ( 'UNITTYPE', 'Unit Type', 11, 'J', 'mms', 1, 'INGDB', 'now'::datetime );

Insert Into T_Domain
  ( Domain, Domain_Name, Sequence_Nr, Attrib, Attrib_Desc, FK_Lang_ID, Modifier, Change_Dt )
Values
  ( 'UNITTYPE', 'Unit Type', 12, 'K', 'KMs', 1, 'INGDB', 'now'::datetime );

commit;

/* Prompt Creating domain attribute values for Employee Function Types */

Insert Into T_Domain
  ( Domain, Domain_Name, Sequence_Nr, Attrib, Attrib_Desc, FK_Lang_ID, Modifier, Change_Dt )
Values
  ( 'FUNCTYPE', 'Function Type', 1, 'A', 'Order Administration', 1, 'INGDB', 'now'::datetime );

Insert Into T_Domain
  ( Domain, Domain_Name, Sequence_Nr, Attrib, Attrib_Desc, FK_Lang_ID, Modifier, Change_Dt )
Values
  ( 'FUNCTYPE', 'Function Type', 2, 'B', 'Place Orders', 1, 'INGDB', 'now'::datetime );

Insert Into T_Domain
  ( Domain, Domain_Name, Sequence_Nr, Attrib, Attrib_Desc, FK_Lang_ID, Modifier, Change_Dt )
Values
  ( 'FUNCTYPE', 'Function Type', 3, 'C', 'Receive Orders', 1, 'INGDB', 'now'::datetime );

Insert Into T_Domain
  ( Domain, Domain_Name, Sequence_Nr, Attrib, Attrib_Desc, FK_Lang_ID, Modifier, Change_Dt )
Values
  ( 'FUNCTYPE', 'Function Type', 4, 'D', 'Deliver Orders', 1, 'INGDB', 'now'::datetime );

Insert Into T_Domain
  ( Domain, Domain_Name, Sequence_Nr, Attrib, Attrib_Desc, FK_Lang_ID, Modifier, Change_Dt )
Values
  ( 'FUNCTYPE', 'Function Type', 5, 'E', 'Delivery Administration', 1, 'INGDB', 'now'::datetime );


commit;

/* Prompt Creating domain attribute values for Parameter Types */

Insert Into T_Domain
  ( Domain, Domain_Name, Sequence_Nr, Attrib, Attrib_Desc, FK_Lang_ID, Modifier, Change_Dt )
Values
  ( 'PARTYPE', 'Parameter Type', 1, 'N', 'Numberic', 1, 'INGDB', 'now'::datetime );

Insert Into T_Domain
  ( Domain, Domain_Name, Sequence_Nr, Attrib, Attrib_Desc, FK_Lang_ID, Modifier, Change_Dt )
Values
  ( 'PARTYPE', 'Parameter Type', 2, 'C', 'Character', 1, 'INGDB', 'now'::datetime );

Insert Into T_Domain
  ( Domain, Domain_Name, Sequence_Nr, Attrib, Attrib_Desc, FK_Lang_ID, Modifier, Change_Dt )
Values
  ( 'PARTYPE', 'Parameter Type', 3, 'S', 'String', 1, 'INGDB', 'now'::datetime );

Insert Into T_Domain
  ( Domain, Domain_Name, Sequence_Nr, Attrib, Attrib_Desc, FK_Lang_ID, Modifier, Change_Dt )
Values
  ( 'PARTYPE', 'Parameter Type', 4, 'B', 'Boolean', 1, 'INGDB', 'now'::datetime );

Insert Into T_Domain
  ( Domain, Domain_Name, Sequence_Nr, Attrib, Attrib_Desc, FK_Lang_ID, Modifier, Change_Dt )
Values
  ( 'PARTYPE', 'Parameter Type', 5, 'D', 'Date', 1, 'INGDB', 'now'::datetime );

commit;

/* Prompt Creating domain attribute values for Parameter Class */

Insert Into T_Domain
  ( Domain, Domain_Name, Sequence_Nr, Attrib, Attrib_Desc, FK_Lang_ID, Modifier, Change_Dt )
Values
  ( 'PARCLASS', 'Parameter Class', 1, 'A', 'Kernel Control', 1, 'INGDB', 'now'::datetime );

Insert Into T_Domain
  ( Domain, Domain_Name, Sequence_Nr, Attrib, Attrib_Desc, FK_Lang_ID, Modifier, Change_Dt )
Values
  ( 'PARCLASS', 'Parameter Class', 2, 'B', 'Client Control', 1, 'INGDB', 'now'::datetime );

Insert Into T_Domain
  ( Domain, Domain_Name, Sequence_Nr, Attrib, Attrib_Desc, FK_Lang_ID, Modifier, Change_Dt )
Values
  ( 'PARCLASS', 'Parameter Class', 3, 'C', 'User Definable Parameter', 1, 'INGDB', 'now'::datetime );

commit;

/* Prompt Creating domain attribute values for Object Type */

Insert Into T_Domain
  ( Domain, Domain_Name, Sequence_Nr, Attrib, Attrib_Desc, FK_Lang_ID, Modifier, Change_Dt )
Values
  ( 'OBJTYPE', 'Object Type', 1, 'A', 'Label', 1, 'INGDB', 'now'::datetime );

Insert Into T_Domain
  ( Domain, Domain_Name, Sequence_Nr, Attrib, Attrib_Desc, FK_Lang_ID, Modifier, Change_Dt )
Values
  ( 'OBJTYPE', 'Object Type', 2, 'B', 'Text Item', 1, 'INGDB', 'now'::datetime );

Insert Into T_Domain
  ( Domain, Domain_Name, Sequence_Nr, Attrib, Attrib_Desc, FK_Lang_ID, Modifier, Change_Dt )
Values
  ( 'OBJTYPE', 'Object Type', 3, 'C', 'List Box', 1, 'INGDB', 'now'::datetime );

Insert Into T_Domain
  ( Domain, Domain_Name, Sequence_Nr, Attrib, Attrib_Desc, FK_Lang_ID, Modifier, Change_Dt )
Values
  ( 'OBJTYPE', 'Object Type', 11, 'K', 'Button', 1, 'INGDB', 'now'::datetime );

Insert Into T_Domain
  ( Domain, Domain_Name, Sequence_Nr, Attrib, Attrib_Desc, FK_Lang_ID, Modifier, Change_Dt )
Values
  ( 'OBJTYPE', 'Object Type', 10, 'J', 'TextArea', 1, 'INGDB', 'now'::datetime );

Commit;

/* Prompt Creating domain attribute values for Operation Mode */

Insert Into T_Domain
  ( Domain, Domain_Name, Sequence_Nr, Attrib, Attrib_Desc, FK_Lang_ID, Modifier, Change_Dt )
Values
  ( 'OPMODE', 'Operation Mode', 1, 'N', 'Normal', 1, 'INGDB', 'now'::datetime );

Insert Into T_Domain
  ( Domain, Domain_Name, Sequence_Nr, Attrib, Attrib_Desc, FK_Lang_ID, Modifier, Change_Dt )
Values
  ( 'OPMODE', 'Operation Mode', 2, 'Q', 'Query', 1, 'INGDB', 'now'::datetime );

Commit;

/* Prompt Creating domain attribute values for Security Level */

Insert Into T_Domain
  ( Domain, Domain_Name, Sequence_Nr, Attrib, Attrib_Desc, FK_Lang_ID, Modifier, Change_Dt )
Values
  ( 'SECLEVEL', 'Security Level', 1, 'S', 'System', 1, 'INGDB', 'now'::datetime );

Insert Into T_Domain
  ( Domain, Domain_Name, Sequence_Nr, Attrib, Attrib_Desc, FK_Lang_ID, Modifier, Change_Dt )
Values
  ( 'SECLEVEL', 'Security Level', 2, 'G', 'Group', 1, 'INGDB', 'now'::datetime );

Insert Into T_Domain
  ( Domain, Domain_Name, Sequence_Nr, Attrib, Attrib_Desc, FK_Lang_ID, Modifier, Change_Dt )
Values
  ( 'SECLEVEL', 'Security Level', 3, 'U', 'User', 1, 'INGDB', 'now'::datetime );

Commit;

/* Prompt Creating domain attribute values for Preferences Color */

Insert Into T_Domain
  ( Domain, Domain_Name, Sequence_Nr, Attrib, Attrib_Desc, FK_Lang_ID, Modifier, Change_Dt )
Values
  ( 'FONTCOLOR', 'Font Color', 1, 'R', 'Red', 1, 'INGDB', 'now'::datetime );

Insert Into T_Domain
  ( Domain, Domain_Name, Sequence_Nr, Attrib, Attrib_Desc, FK_Lang_ID, Modifier, Change_Dt )
Values
  ( 'FONTCOLOR', 'Font Color', 2, 'B', 'Blue', 1, 'INGDB', 'now'::datetime );

Insert Into T_Domain
  ( Domain, Domain_Name, Sequence_Nr, Attrib, Attrib_Desc, FK_Lang_ID, Modifier, Change_Dt )
Values
  ( 'FONTCOLOR', 'Font Color', 3, 'G', 'Green', 1, 'INGDB', 'now'::datetime );

Insert Into T_Domain
  ( Domain, Domain_Name, Sequence_Nr, Attrib, Attrib_Desc, FK_Lang_ID, Modifier, Change_Dt )
Values
  ( 'FONTCOLOR', 'Font Color', 4, 'C', 'Cyan', 1, 'INGDB', 'now'::datetime );

Insert Into T_Domain
  ( Domain, Domain_Name, Sequence_Nr, Attrib, Attrib_Desc, FK_Lang_ID, Modifier, Change_Dt )
Values
  ( 'FONTCOLOR', 'Font Color', 5, 'K', 'Black', 1, 'INGDB', 'now'::datetime );

Insert Into T_Domain
  ( Domain, Domain_Name, Sequence_Nr, Attrib, Attrib_Desc, FK_Lang_ID, Modifier, Change_Dt )
Values
  ( 'FONTCOLOR', 'Font Color', 6, 'W', 'White', 1, 'INGDB', 'now'::datetime );

Commit;

/* Prompt Creating domain attribute values for Preferences Font Face */

Insert Into T_Domain
  ( Domain, Domain_Name, Sequence_Nr, Attrib, Attrib_Desc, FK_Lang_ID, Modifier, Change_Dt )
Values
  ( 'FONTFACE', 'Font Face', 1, 'A', 'Times New Roman', 1, 'INGDB', 'now'::datetime );

Insert Into T_Domain
  ( Domain, Domain_Name, Sequence_Nr, Attrib, Attrib_Desc, FK_Lang_ID, Modifier, Change_Dt )
Values
  ( 'FONTFACE', 'Font Face', 2, 'B', 'Arial', 1, 'INGDB', 'now'::datetime );

Insert Into T_Domain
  ( Domain, Domain_Name, Sequence_Nr, Attrib, Attrib_Desc, FK_Lang_ID, Modifier, Change_Dt )
Values
  ( 'FONTFACE', 'Font Face', 3, 'C', 'MS Sans Serif', 1, 'INGDB', 'now'::datetime );

Insert Into T_Domain
  ( Domain, Domain_Name, Sequence_Nr, Attrib, Attrib_Desc, FK_Lang_ID, Modifier, Change_Dt )
Values
  ( 'FONTFACE', 'Font Face', 4, 'D', 'Tahoma', 1, 'INGDB', 'now'::datetime );

Commit;

/* Prompt Creating domain attribute values for Preferences Font Size */

Insert Into T_Domain
  ( Domain, Domain_Name, Sequence_Nr, Attrib, Attrib_Desc, FK_Lang_ID, Modifier, Change_Dt )
Values
  ( 'FONTSIZE', 'Font Size', 1, 'A', '1', 1, 'INGDB', 'now'::datetime );

Insert Into T_Domain
  ( Domain, Domain_Name, Sequence_Nr, Attrib, Attrib_Desc, FK_Lang_ID, Modifier, Change_Dt )
Values
  ( 'FONTSIZE', 'Font Size', 2, 'B', '2', 1, 'INGDB', 'now'::datetime );

Insert Into T_Domain
  ( Domain, Domain_Name, Sequence_Nr, Attrib, Attrib_Desc, FK_Lang_ID, Modifier, Change_Dt )
Values
  ( 'FONTSIZE', 'Font Size', 3, 'C', '3', 1, 'INGDB', 'now'::datetime );

Insert Into T_Domain
  ( Domain, Domain_Name, Sequence_Nr, Attrib, Attrib_Desc, FK_Lang_ID, Modifier, Change_Dt )
Values
  ( 'FONTSIZE', 'Font Size', 4, 'D', '4', 1, 'INGDB', 'now'::datetime );

Insert Into T_Domain
  ( Domain, Domain_Name, Sequence_Nr, Attrib, Attrib_Desc, FK_Lang_ID, Modifier, Change_Dt )
Values
  ( 'FONTSIZE', 'Font Size', 5, 'E', '5', 1, 'INGDB', 'now'::datetime );

Commit;

/* PROMPT *****[ Ending L_Domain.sql ]***** */
