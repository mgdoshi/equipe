/* Script Name : L_Scheme.sql.
   Author      : Manoj Doshi.
   Description : Inserting initial data into Scheme Table. 
*/

/* PROMPT *****[ Starting L_Scheme.sql ]***** */

Insert Into T_Scheme
  ( Scheme_ID, Scheme_Name, Scheme_Desc )
Values
  ( 0, 'DEFAULT', 'Default Scheme' );

Prompt Creating Scheme attribute values for Client Type 

Insert Into T_SchemeRef
  ( Fk_Scheme_ID, DM_ObjType, DM_OpMode, Prop1, Prop2, Prop3 )
Values
  ( 0, 'A', 'N', 'SIZE="3"', 'FACE="Arial"', 'COLOR="Black"' );

Insert Into T_SchemeRef
  ( Fk_Scheme_ID, DM_ObjType, DM_OpMode, Prop1, Prop2, Prop3 )
Values
  ( 0, 'B', 'N', 'SIZE="3"', 'FACE="Arial"', 'COLOR="Black"' );

Insert Into T_SchemeRef
  ( Fk_Scheme_ID, DM_ObjType, DM_OpMode, Prop1, Prop2, Prop3 )
Values
  ( 0, 'C', 'N', 'SIZE="3"', 'FACE="Arial"', 'COLOR="Black"' );

Insert Into T_SchemeRef
  ( Fk_Scheme_ID, DM_ObjType, DM_OpMode, Prop1, Prop2, Prop3 )
Values
  ( 0, 'J', 'N', 'SIZE="3"', 'FACE="Arial"', 'COLOR="Black"' );

Insert Into T_SchemeRef
  ( Fk_Scheme_ID, DM_ObjType, DM_OpMode, Prop1, Prop2, Prop3 )
Values
  ( 0, 'K', 'N', 'SIZE="3"', 'FACE="Arial"', 'COLOR="Black"' );

commit;

/* PROMPT *****[ Ending L_Scheme.sql ]***** */
