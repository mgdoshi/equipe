/* Script Name : L_Lang.sql.
   Author      : Manoj Doshi.
   Description : Inserting initial data into Language Table.
*/

/* PROMPT *****[ Starting L_Lang.sql ]***** */

Insert Into T_Lang 
  ( Lang_ID, Lang_name, Lang_Desc, Modifier, Change_Dt )
Values
  ( 1, 'ENG', 'English', 'INGDB', date('now'::datetime) );

Insert Into T_Lang 
  ( Lang_ID, Lang_name, Lang_Desc, Modifier, Change_Dt )
Values
  ( 2, 'HIN', 'Hindi', 'INGDB', 'now'::datetime );

Commit;

/* PROMPT *****[ Ending L_Lang.sql ]***** */
