/* Script Name : L_Secure.sql.
   Author      : Manoj Doshi.
*/

/* PROMPT *****[ Starting L_Secure.sql ]***** */

/*
   Description : Inserting initial data into Client Table. Only one client record is
                 entered 'IN' signifying Internal. This differentiates always other
                 users from Internal Users.
*/

Insert Into T_Client
  ( Client_ID, Client_Code, DM_ClnType, Client_Name, Client_Desc, Modifier, Change_Dt )
Values
  ( 1, 'IN', 'I', 'INTERNAL', 'Internal Company Code.', 'INGDB', 'now'::datetime );

commit;

/* Description : Inserting initial data into Employee Table. Only one employee record is
                 entered 0 signifying Admin Employee.
*/

Insert Into T_Employee
  ( Employee_ID, Employee_Name, Employee_Desc, FK_Branch_ID, Designation, Modifier, Change_Dt )
Values
  ( 0, 'ADMIN', 'Administration', Null, Null, 'INGDB', 'now'::datetime );

commit;

/* Description : Inserting initial data into RecSec Table. Only one recsec record is
                 entered 0 signifying default record security. This recsec owner has
                 all the rights in the system. There is no need for assigning priviledges
                 to this recsec owner for other recsecs.
*/

Insert Into T_RecSec
  ( RecSec_id, RecSec_name, RecSec_desc, Modifier, Change_Dt )
Values
  ( 0, 'ADMIN', 'Default Admin Owner', 'INGDB', 'now'::datetime );

commit;

/* Description : Inserting initial data into Group Table. Only one Group record is
                 entered signifying Admin.
*/

Insert Into T_Group
  ( Group_ID, Group_Name, Group_Desc, Modifier, Change_Dt )
Values
  ( 0, 'ADMIN', 'System Administration Group.', 'INGDB', 'now'::datetime );

commit;

/* Description : Inserting initial data into User Table. Only one User record is
                 entered signifying Admin. The Password is changed after logging in
                 for the first time.
*/

Insert Into T_User
  ( User_ID, User_Name, User_Pass, User_Desc, FK_Lang_ID, FK_Client_ID, FK_RecSec_ID, FK_Employee_ID, Modifier, Change_Dt )
Values
  ( 0, 'ADMIN', 'drobsag', 'System Administration User', 1, 1, 0, 0, 'INGDB', 'now'::datetime );

commit;

/* PROMPT *****[ Ending L_Secure.sql ]***** */
