/* Script Name : L_Help.sql.
   Author      : Manoj Doshi
   Description : Inserting initial data into Help Reference Table.
*/
  
Insert Into T_Help
  ( Help_ID, Parent_ID, Caption, URL)
Values
  ( 211, 103, 'Branch', '/ordhtm/Help/help211.html');

Insert Into T_Help
  ( Help_ID, Parent_ID, Caption, URL)
Values
 ( 212, 103, 'Cost Centre', '/ordhtm/Help/help212.html');

Insert Into T_Help
  ( Help_ID, Parent_ID, Caption, URL)
Values
  ( 213, 103, 'Item Related Options', '*');

Insert Into T_Help
  ( Help_ID, Parent_ID, Caption, URL)
Values
  ( 320, 213, 'Item Class', '/ordhtm/Help/help320.html');

Insert Into T_Help
  ( Help_ID, Parent_ID, Caption, URL)
Values
  ( 321, 213, 'Item Pack', '/ordhtm/Help/help321.html');

Insert Into T_Help
  ( Help_ID, Parent_ID, Caption, URL)
Values
  ( 322, 213, 'Item Group', '/ordhtm/Help/help322.html');

Insert Into T_Help
  ( Help_ID, Parent_ID, Caption, URL)
Values
  ( 323, 213, 'Item', '/ordhtm/Help/help323.html');

Insert Into T_Help
  ( Help_ID, Parent_ID, Caption, URL)
Values
  ( 324, 213, 'ClientItem', '/ordhtm/Help/help324.html');

Insert Into T_Help
  ( Help_ID, Parent_ID, Caption, URL)
Values
  ( 325, 213, 'Item Rate', '/ordhtm/Help/help325.html');

Insert Into T_Help
  ( Help_ID, Parent_ID, Caption, URL)
Values
  ( 326, 213, 'ClientItem Rate', '/ordhtm/Help/help326.html');

Insert Into T_Help
  ( Help_ID, Parent_ID, Caption, URL)
Values
  ( 214, 103, 'Address', '/ordhtm/Help/help214.html');

Insert Into T_Help
  ( Help_ID, Parent_ID, Caption, URL)
Values
  ( 215, 103, 'Order Administration', '/ordhtm/Help/help215.html');

Insert Into T_Help
  ( Help_ID, Parent_ID, Caption, URL)
Values
  ( 216, 103, 'User Relationships', '/ordhtm/Help/help216.html');

Insert Into T_Help
  ( Help_ID, Parent_ID, Caption, URL)
Values
  ( 104, 2, 'Transaction', '*');

Insert Into T_Help
  ( Help_ID, Parent_ID, Caption, URL)
Values
  ( 217, 104, 'Order Entry', '*');

Insert Into T_Help
  ( Help_ID, Parent_ID, Caption, URL)
Values
  ( 327, 217, 'Manual/Shopping Cart', '/ordhtm/Help/help327.html');

Insert Into T_Help
  ( Help_ID, Parent_ID, Caption, URL)
Values
  ( 328, 217, 'Using Template', '/ordhtm/Help/help328.html');

Insert Into T_Help
  ( Help_ID, Parent_ID, Caption, URL)
Values
  ( 218, 104, 'Order Maintenance', '/ordhtm/Help/help218.html');

Insert Into T_Help
  ( Help_ID, Parent_ID, Caption, URL)
Values
  ( 219, 104, 'Change Order Status', '/ordhtm/Help/help219.html');

Insert Into T_Help
  ( Help_ID, Parent_ID, Caption, URL)
Values
  ( 220, 104, 'Delivery Entry', '/ordhtm/Help/help220.html');

Insert Into T_Help
  ( Help_ID, Parent_ID, Caption, URL)
Values
  ( 221, 104, 'Delivery Maintenance', '/ordhtm/Help/help221.html');

Insert Into T_Help
  ( Help_ID, Parent_ID, Caption, URL)
Values
  ( 105, 2, 'Special Task', '*');

Insert Into T_Help
  ( Help_ID, Parent_ID, Caption, URL)
Values
  ( 222, 105, 'Preferences', '/ordhtm/Help/help222.html');

Insert Into T_Help
  ( Help_ID, Parent_ID, Caption, URL)
Values
  ( 223, 105, 'Define Order Template', '/ordhtm/Help/help223.html');

Insert Into T_Help
  ( Help_ID, Parent_ID, Caption, URL)
Values
  ( 224, 105, 'Shopping-Cart Configuration', '/ordhtm/Help/help224.html');

Insert Into T_Help
  ( Help_ID, Parent_ID, Caption, URL)
Values
  ( 225, 105, 'Report', '*');

Insert Into T_Help
  ( Help_ID, Parent_ID, Caption, URL)
Values
  ( 329, 225, 'Order Report', '/ordhtm/Help/help329.html');

Insert Into T_Help
  ( Help_ID, Parent_ID, Caption, URL)
Values
  ( 330, 225, 'Client Wise Order Report', '/ordhtm/Help/help330.html');

Insert Into T_Help
  ( Help_ID, Parent_ID, Caption, URL)
Values
  ( 331, 225, 'Pending Order Report', '/ordhtm/Help/help331.html');

Insert Into T_Help
  ( Help_ID, Parent_ID, Caption, URL)
Values
  ( 332, 225, 'Delivery Report', '/ordhtm/Help/help332.html');

Insert Into T_Help
  ( Help_ID, Parent_ID, Caption, URL)
Values
  ( 333, 225, 'Security Report', '/ordhtm/Help/help333.html');

Insert Into T_Help
  ( Help_ID, Parent_ID, Caption, URL)
Values
  ( 226, 105, 'Data Export', '/ordhtm/Help/help226.html');

Insert Into T_Help
  ( Help_ID, Parent_ID, Caption, URL)
Values
  ( 106, 2, 'Others', '*');

Insert Into T_Help
  ( Help_ID, Parent_ID, Caption, URL)
Values
  ( 227, 106, 'News Room', '/ordhtm/Help/help227.html');

Insert Into T_Help
  ( Help_ID, Parent_ID, Caption, URL)
Values
  ( 210, 103, 'Client', '/ordhtm/Help/help210.html');

Insert Into T_Help
  ( Help_ID, Parent_ID, Caption, URL)
Values
  ( 1, 0, 'Using the system', '*');

Insert Into T_Help
  ( Help_ID, Parent_ID, Caption, URL)
Values
  ( 2, 0, 'Contents', '*');

Insert Into T_Help
  ( Help_ID, Parent_ID, Caption, URL)
Values
  ( 3, 1, 'Login/Logout', '/ordhtm/Help/help003.html');

Insert Into T_Help
  ( Help_ID, Parent_ID, Caption, URL)
Values
  ( 4, 1, 'Menu Options', '/ordhtm/Help/help004.html');

Insert Into T_Help
  ( Help_ID, Parent_ID, Caption, URL)
Values
  ( 5, 1, 'Global Functionality', '/ordhtm/Help/help005.html');

Insert Into T_Help
  ( Help_ID, Parent_ID, Caption, URL)
Values
  ( 101, 2, 'System Options', '*');

Insert Into T_Help
  ( Help_ID, Parent_ID, Caption, URL)
Values
  ( 201, 101, 'Logout', '/ordhtm/Help/help201.html');

Insert Into T_Help
  ( Help_ID, Parent_ID, Caption, URL)
Values
  ( 202, 101, 'Change Password', '/ordhtm/Help/help202.html');

Insert Into T_Help
  ( Help_ID, Parent_ID, Caption, URL)
Values
  ( 102, 2, 'Administration Options', '*');

Insert Into T_Help
  ( Help_ID, Parent_ID, Caption, URL)
Values
  ( 203, 102, 'Security Options', '*');

Insert Into T_Help
  ( Help_ID, Parent_ID, Caption, URL)
Values
  ( 204, 102, 'Parameter', '/ordhtm/Help/help204.html');

Insert Into T_Help
  ( Help_ID, Parent_ID, Caption, URL)
Values
  ( 205, 102, 'Message', '/ordhtm/Help/help205.html');

Insert Into T_Help
  ( Help_ID, Parent_ID, Caption, URL)
Values
  ( 206, 102, 'Configuration', '/ordhtm/Help/help206.html');

Insert Into T_Help
  ( Help_ID, Parent_ID, Caption, URL)
Values
  ( 207, 102, 'News Data', '/ordhtm/Help/help207.html');

Insert Into T_Help
  ( Help_ID, Parent_ID, Caption, URL)
Values
  ( 301, 203, 'User', '/ordhtm/Help/help301.html');

Insert Into T_Help
  ( Help_ID, Parent_ID, Caption, URL)
Values
  ( 302, 203, 'Group', '/ordhtm/Help/help302.html');

Insert Into T_Help
  ( Help_ID, Parent_ID, Caption, URL)
Values
  ( 303, 203, 'Rights Control', '*');

Insert Into T_Help
  ( Help_ID, Parent_ID, Caption, URL)
Values
  ( 401, 303, 'Menu', '/ordhtm/Help/help401.html');

Insert Into T_Help
  ( Help_ID, Parent_ID, Caption, URL)
Values
  ( 402, 303, 'Object', '/ordhtm/Help/help402.html');

Insert Into T_Help
  ( Help_ID, Parent_ID, Caption, URL)
Values
  ( 304, 203, 'Record Security', '/ordhtm/Help/help304.html');

Insert Into T_Help
  ( Help_ID, Parent_ID, Caption, URL)
Values
  ( 103, 2, 'Standard Data', '*');

Insert Into T_Help
  ( Help_ID, Parent_ID, Caption, URL)
Values
  ( 208, 103, 'Domain', '*');

Insert Into T_Help
  ( Help_ID, Parent_ID, Caption, URL)
Values
  ( 305, 208, 'Address Type', '/ordhtm/Help/help305.html');

Insert Into T_Help
  ( Help_ID, Parent_ID, Caption, URL)
Values
  ( 306, 208, 'Client Type', '/ordhtm/Help/help306.html');

Insert Into T_Help
  ( Help_ID, Parent_ID, Caption, URL)
Values
  ( 307, 208, 'Delivery Status', '/ordhtm/Help/help307.html');

Insert Into T_Help
  ( Help_ID, Parent_ID, Caption, URL)
Values
  ( 308, 208, 'Function Type', '/ordhtm/Help/help308.html');

Insert Into T_Help
  ( Help_ID, Parent_ID, Caption, URL)
Values
  ( 309, 208, 'Object Type', '/ordhtm/Help/help309.html');

Insert Into T_Help
  ( Help_ID, Parent_ID, Caption, URL)
Values
  ( 310, 208, 'Operation Mode', '/ordhtm/Help/help310.html');

Insert Into T_Help
  ( Help_ID, Parent_ID, Caption, URL)
Values
  ( 311, 208, 'Order Status', '/ordhtm/Help/help311.html');

Insert Into T_Help
  ( Help_ID, Parent_ID, Caption, URL)
Values
  ( 312, 208, 'Parameter Class', '/ordhtm/Help/help312.html');

Insert Into T_Help
  ( Help_ID, Parent_ID, Caption, URL)
Values
  ( 0, -1, '*', '*');

Insert Into T_Help
  ( Help_ID, Parent_ID, Caption, URL)
Values
  ( 313, 208, 'Parameter Type', '/ordhtm/Help/help313.html');

Insert Into T_Help
  ( Help_ID, Parent_ID, Caption, URL)
Values
  ( 314, 208, 'Security Level', '/ordhtm/Help/help314.html');

Insert Into T_Help
  ( Help_ID, Parent_ID, Caption, URL)
Values
  ( 315, 208, 'Shipment Type', '/ordhtm/Help/help315.html');

Insert Into T_Help
  ( Help_ID, Parent_ID, Caption, URL)
Values
  ( 316, 208, 'Unit', '/ordhtm/Help/help316.html');

Insert Into T_Help
  ( Help_ID, Parent_ID, Caption, URL)
Values
  ( 317, 208, 'Font Color', '/ordhtm/Help/help317.html');

Insert Into T_Help
  ( Help_ID, Parent_ID, Caption, URL)
Values
  ( 318, 208, 'Font Face', '/ordhtm/Help/help318.html');

Insert Into T_Help
  ( Help_ID, Parent_ID, Caption, URL)
Values
  ( 319, 208, 'Font Size', '/ordhtm/Help/help319.html');

Insert Into T_Help
  ( Help_ID, Parent_ID, Caption, URL)
Values
  ( 209, 103, 'Employee', '/ordhtm/Help/help209.html');

Insert Into T_Help
  ( Help_ID, Parent_ID, Caption, URL)
Values
  ( 228, 106, 'Yours Query/Suggestion/Feedback/Comment', '/ordhtm/Help/help228.html');

Insert Into T_Help
  ( Help_ID, Parent_ID, Caption, URL)
Values
  ( 229, 106, 'Download Help Manual', '/ordhtm/Help/help229.html');

Insert Into T_Help
  ( Help_ID, Parent_ID, Caption, URL)
Values
  ( 230, 106, 'Help', '/ordhtm/Help/help230.html');

Insert Into T_Help
  ( Help_ID, Parent_ID, Caption, URL)
Values
  ( 231, 106, 'About', '/ordhtm/Help/help231.html');
