/* Script Name : L_ObjectSecurityRef.sql.
   Author      : Manoj Doshi.
   Description : Object Security Reference.
*/

/* PROMPT *****[ Starting L_RecSec.sql ]***** */

/*
	K Button
	A Label
	C List Box
	B Text Item
	J TextArea
*/

/* Order Form  */

DELETE FROM T_ObjSecRef
WHERE  ObjParent_Name = 'TR_ORDER';

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'TR_ORDER', 'Insert', 'Insert Order Entry', 'K' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'TR_ORDER', 'Update', 'Update Order Entry', 'K' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'TR_ORDER', 'Delete', 'Delete Order Entry', 'K' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'TR_ORDER', 'Query', 'Query Order Details', 'K' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'TR_ORDER', 'OrdFromTempl', 'Order From Templates', 'K' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'TR_ORDER', 'OrdForTempl', 'Show Order For Template', 'K' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'TR_ORDER', 'OrdForTempl', 'Show Order For Template', 'K' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'TR_ORDER', 'ChnOrdStat', 'Show Order Status Draft To Open', 'K' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'TR_ORDER', 'cDM_OrdStat', 'Order Status List Box', 'C' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'TR_ORDER', 'nShpCartID', 'Shopping Cart List Box', 'C' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'TR_ORDER', 'vOrder_No', 'Order Num Edit Box', 'B' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'TR_ORDER', 'dOrder_Dt', 'Order Date Edit Box', 'B' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'TR_ORDER', 'dExpDel_Dt', 'Exp Del date Edit Box', 'B' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'TR_ORDER', 'nBillAdd_ID', 'Billing Addr List Box', 'C' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'TR_ORDER', 'nShipAdd_ID', 'Shipping Addr List Box', 'C' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'TR_ORDER', 'dDt1', 'Cust Date1 Edit Box', 'B' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'TR_ORDER', 'dDt2', 'Cust Date2 Edit Box', 'B' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'TR_ORDER', 'dDt3', 'Cust Date3 Edit Box', 'B' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'TR_ORDER', 'nCharge1', 'Cust Charge1 Edit Box', 'B' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'TR_ORDER', 'nCharge2', 'Cust Charge2 Edit Box', 'B' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'TR_ORDER', 'nCharge3', 'Cust Charge3 Edit Box', 'B' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'TR_ORDER', 'nCharge4', 'Cust Charge4 Edit Box', 'B' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'TR_ORDER', 'nNum1', 'Cust Num1 Edit Box', 'B' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'TR_ORDER', 'nNum2', 'Cust Num2 Edit Box', 'B' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'TR_ORDER', 'nNum3', 'Cust Num3 Edit Box', 'B' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'TR_ORDER', 'nNum4', 'Cust Num4 Edit Box', 'B' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'TR_ORDER', 'nNum5', 'Cust Num5 Edit Box', 'B' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'TR_ORDER', 'vText1', 'Cust Text1 Edit Box', 'B' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'TR_ORDER', 'vText2', 'Cust Text2 Edit Box', 'B' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'TR_ORDER', 'vText3', 'Cust Text3 Edit Box', 'B' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'TR_ORDER', 'vText4', 'Cust Text4 Edit Box', 'B' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'TR_ORDER', 'vText5', 'Cust Text5 Edit Box', 'B' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'TR_ORDER', 'vRemarks1', 'Cust Remarks1 Edit Box', 'B' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'TR_ORDER', 'vRemarks2', 'Cust Remarks2 Edit Box', 'B' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'TR_ORDER', 'vRemarks3', 'Cust Remarks3 Edit Box', 'B' );

/* Order Details Form  */

DELETE FROM T_ObjSecRef
WHERE  ObjParent_Name = 'TR_ORDDTLS';

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'TR_ORDDTLS', 'Insert', 'Insert Order Details', 'K' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'TR_ORDDTLS', 'Update', 'Update Order Details', 'K' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'TR_ORDDTLS', 'Delete', 'Delete Order Details', 'K' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'TR_ORDDTLS', 'ShowItems', 'Show Items List', 'K' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'TR_ORDDTLS', 'nPos_No', 'Position No', 'B' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'TR_ORDDTLS', 'nFk_Item_ID', 'Item Names', 'C' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'TR_ORDDTLS', 'nFk_ItemPack_ID', 'Item Pack Names', 'C' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'TR_ORDDTLS', 'nQuantity', 'Quantity', 'B' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'TR_ORDDTLS', 'cDM_UnitType', 'Item Unit Type', 'C' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'TR_ORDDTLS', 'nUnitPrice', 'Item Unit Price', 'B' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'TR_ORDDTLS', 'vText1', 'Cust Text1', 'B' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'TR_ORDDTLS', 'vText2', 'Cust Text2', 'B' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'TR_ORDDTLS', 'vText3', 'Cust Text3', 'B' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'TR_ORDDTLS', 'vText4', 'Cust Text4', 'B' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'TR_ORDDTLS', 'vText5', 'Cust Text5', 'B' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'TR_ORDDTLS', 'nNum1', 'Cust Num1', 'B' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'TR_ORDDTLS', 'nNum2', 'Cust Num2', 'B' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'TR_ORDDTLS', 'nNum3', 'Cust Num3', 'B' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'TR_ORDDTLS', 'nNum4', 'Cust Num4', 'B' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'TR_ORDDTLS', 'nNum5', 'Cust Num5', 'B' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'TR_ORDDTLS', 'vRemarks1', 'Cust Remarks1', 'B' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'TR_ORDDTLS', 'vRemarks2', 'Cust Remarks2', 'B' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'TR_ORDDTLS', 'vRemarks3', 'Cust Remarks3', 'B' );

/* Delivery Form  */

DELETE FROM T_ObjSecRef
WHERE  ObjParent_Name = 'TR_DELIVERY';

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'TR_DELIVERY', 'ClientSave', 'Client Entry', 'K' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'TR_DELIVERY', 'ShowOrderWin', 'Show Order Window', 'K' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'TR_DELIVERY', 'Insert', 'Insert Delivery Entry', 'K' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'TR_DELIVERY', 'Update', 'Update Delivery Entry', 'K' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'TR_DELIVERY', 'Delete', 'Delete Delivery Entry', 'K' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'TR_DELIVERY', 'Query', 'Query Delivery Entry', 'K' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'TR_DELIVERY', 'cDMDelStat', 'Delivery Status', 'C' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'TR_DELIVERY', 'cDMShipMode', 'Shipping Mode', 'C' );
	
Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'TR_DELIVERY', 'cDMDelStat', 'Delivery Status', 'C' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'TR_DELIVERY', 'nShipFromAddID', 'Shipping From Address', 'C' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'TR_DELIVERY', 'nShipToAddID', 'Shipping To Address', 'C' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'TR_DELIVERY', 'nTransAddID', 'Trans Address', 'C' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'TR_DELIVERY', 'vDeliveryNo', 'Delivery Number', 'B' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'TR_DELIVERY', 'vDeliveryDt', 'Delivery Date', 'B' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'TR_DELIVERY', 'vRefNo', 'Reference Number', 'B' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'TR_DELIVERY', 'dDt1', 'Custom Date1', 'B' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'TR_DELIVERY', 'dDt2', 'Custom Date2', 'B' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'TR_DELIVERY', 'dDt3', 'Custom Date3', 'B' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'TR_DELIVERY', 'nNum1', 'Custom Number1', 'B' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'TR_DELIVERY', 'nNum2', 'Custom Number2', 'B' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'TR_DELIVERY', 'nNum3', 'Custom Number3', 'B' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'TR_DELIVERY', 'nNum4', 'Custom Number4', 'B' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'TR_DELIVERY', 'nNum5', 'Custom Number5', 'B' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'TR_DELIVERY', 'vText1', 'Custom Text1', 'B' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'TR_DELIVERY', 'vText2', 'Custom Text2', 'B' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'TR_DELIVERY', 'vText3', 'Custom Text3', 'B' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'TR_DELIVERY', 'vText4', 'Custom Text4', 'B' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'TR_DELIVERY', 'vText5', 'Custom Text5', 'B' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'TR_DELIVERY', 'vRemark1', 'Custom Remark1', 'B' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'TR_DELIVERY', 'vRemark2', 'Custom Remark2', 'B' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'TR_DELIVERY', 'vRemark3', 'Custom Remark3', 'B' );

/* Delivery Details Form  */

DELETE FROM T_ObjSecRef
WHERE  ObjParent_Name = 'TR_DELVDTLS';

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'TR_DELVDTLS', 'Insert', 'Insert Delivery Details', 'K' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'TR_DELVDTLS', 'Update', 'Update Delivery Details', 'K' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'TR_DELVDTLS', 'Delete', 'Delete Delivery Details', 'K' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'TR_DELVDTLS', 'nPos_No', 'Position No', 'B' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'TR_DELVDTLS', 'nFk_Item_ID', 'Item Names', 'C' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'TR_DELVDTLS', 'nFk_ItemPack_ID', 'Item Pack Names', 'C' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'TR_DELVDTLS', 'nQuantity', 'Quantity', 'B' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'TR_DELVDTLS', 'cDM_UnitType', 'Item Unit Type', 'C' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'TR_DELVDTLS', 'vBatchNo', 'Batch Number', 'B' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'TR_DELVDTLS', 'vText1', 'Cust Text1', 'B' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'TR_DELVDTLS', 'vText2', 'Cust Text2', 'B' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'TR_DELVDTLS', 'vText3', 'Cust Text3', 'B' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'TR_DELVDTLS', 'vText4', 'Cust Text4', 'B' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'TR_DELVDTLS', 'vText5', 'Cust Text5', 'B' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'TR_DELVDTLS', 'nNum1', 'Cust Num1', 'B' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'TR_DELVDTLS', 'nNum2', 'Cust Num2', 'B' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'TR_DELVDTLS', 'nNum3', 'Cust Num3', 'B' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'TR_DELVDTLS', 'nNum4', 'Cust Num4', 'B' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'TR_DELVDTLS', 'nNum5', 'Cust Num5', 'B' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'TR_DELVDTLS', 'dDt1', 'Cust Date1', 'B' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'TR_DELVDTLS', 'dDt2', 'Cust Date2', 'B' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'TR_DELVDTLS', 'dDt3', 'Cust Date3', 'B' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'TR_DELVDTLS', 'vRemarks1', 'Cust Remarks1', 'B' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'TR_DELVDTLS', 'vRemarks2', 'Cust Remarks2', 'B' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'TR_DELVDTLS', 'vRemarks3', 'Cust Remarks3', 'B' );

/* Shopping Cart Form  */

DELETE FROM T_ObjSecRef
WHERE  ObjParent_Name = 'TR_SHOPCART';

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'TR_SHOPCART', 'New', 'Create New Shopping Cart', 'K' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'TR_SHOPCART', 'Insert', 'Insert Shopping Cart', 'K' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'TR_SHOPCART', 'Update', 'Update Shopping Cart', 'K' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'TR_SHOPCART', 'Delete', 'Delete Shopping Cart', 'K' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'TR_SHOPCART', 'vCartDef_Name', 'Shopping Cart Name', 'B' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'TR_SHOPCART', 'vItem_Name', 'Item Name', 'B' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'TR_SHOPCART', 'vItem_Desc', 'Item Desc', 'B' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'TR_SHOPCART', 'nFk_ItemClass_ID', 'Item Class Name', 'C' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'TR_SHOPCART', 'nFk_ItemGroup_ID', 'Item Group Name', 'C' );

/* Order Template Form  */

DELETE FROM T_ObjSecRef
WHERE  ObjParent_Name = 'TR_TEMPLATE';

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'TR_TEMPLATE', 'New', 'Create New Order Template', 'K' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'TR_TEMPLATE', 'Insert', 'Insert Order Template', 'K' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'TR_TEMPLATE', 'Update', 'Update Order Template', 'K' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'TR_TEMPLATE', 'Delete', 'Delete Order Template', 'K' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'TR_TEMPLATE', 'Copy', 'Copy Order Template', 'K' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'TR_TEMPLATE', 'Create', 'Create Order From Template', 'K' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'TR_TEMPLATE', 'vTemplate_Name', 'Order Template Name', 'B' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'TR_TEMPLATE', 'vTemplate_Desc', 'Order Template Description', 'B' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'TR_TEMPLATE', 'nBillAdd_ID', 'Billing Addr List Box', 'C' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'TR_TEMPLATE', 'nShipAdd_ID', 'Shipping Addr List Box', 'C' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'TR_TEMPLATE', 'vRemarks1', 'Cust Remarks1 Edit Box', 'B' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'TR_TEMPLATE', 'vRemarks2', 'Cust Remarks2 Edit Box', 'B' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'TR_TEMPLATE', 'vRemarks3', 'Cust Remarks3 Edit Box', 'B' );

/* Order Template Details Form  */

DELETE FROM T_ObjSecRef
WHERE  ObjParent_Name = 'TR_TEMPLATEDTLS';

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'TR_TEMPLATEDTLS', 'Insert', 'Insert Order Template Details', 'K' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'TR_TEMPLATEDTLS', 'More', 'Insert More Template Details', 'K' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'TR_TEMPLATEDTLS', 'Update', 'Update Order Details', 'K' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'TR_TEMPLATEDTLS', 'nPos_Nr', 'Position No', 'B' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'TR_TEMPLATEDTLS', 'nFk_Item_ID', 'Item Names', 'C' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'TR_TEMPLATEDTLS', 'nFk_ItemPack_ID', 'Item Pack Names', 'C' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'TR_TEMPLATEDTLS', 'cDM_UnitType', 'Item Unit Type', 'C' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'TR_TEMPLATEDTLS', 'nUnitPrice', 'Item Unit Price', 'B' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'TR_TEMPLATEDTLS', 'vRemarks1', 'Cust Remarks1', 'B' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'TR_TEMPLATEDTLS', 'vRemarks2', 'Cust Remarks2', 'B' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'TR_TEMPLATEDTLS', 'vRemarks3', 'Cust Remarks3', 'B' );

/* Item Pack Form  */

DELETE FROM T_ObjSecRef
WHERE  ObjParent_Name = 'ST_ITEMPACK';

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'ST_ITEMPACK', 'Insert', 'Insert ItemPack', 'K' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'ST_ITEMPACK', 'SaveInsert', ' Save ItemPack And Create New ItemPack', 'K' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'ST_ITEMPACK', 'Update', 'Update ItemPack', 'K' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'ST_ITEMPACK', 'Delete', 'Delete ItemPack', 'K' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'ST_ITEMPACK', 'vItemPack_Name', 'Item Package Name', 'B' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'ST_ITEMPACK', 'vItemPack_Desc', 'Item Package Desc', 'B' );

/* Item Group Form  */

DELETE FROM T_ObjSecRef
WHERE  ObjParent_Name = 'ST_ITEMGROUP';

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'ST_ITEMGROUP', 'Insert', 'Insert ItemGroup', 'K' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'ST_ITEMGROUP', 'SaveInsert', ' Save ItemGroup And Create New ItemGroup', 'K' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'ST_ITEMGROUP', 'Update', 'Update ItemGroup', 'K' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'ST_ITEMGROUP', 'Delete', 'Delete ItemGroup', 'K' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'ST_ITEMGROUP', 'vItemGroup_Name', 'Item Group Name', 'B' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'ST_ITEMGROUP', 'vItemGroup_Desc', 'Item Group Desc', 'B' );

/* Item Class Form  */

DELETE FROM T_ObjSecRef
WHERE  ObjParent_Name = 'ST_ITEMCLASS';

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'ST_ITEMCLASS', 'Insert', 'Insert ItemClass', 'K' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'ST_ITEMCLASS', 'SaveInsert', ' Save ItemClass And Create New ItemClass', 'K' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'ST_ITEMCLASS', 'Update', 'Update ItemClass', 'K' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'ST_ITEMCLASS', 'Delete', 'Delete ItemClass', 'K' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'ST_ITEMCLASS', 'vItemClass_Name', 'Item Class Name', 'B' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'ST_ITEMCLASS', 'vItemClass_Desc', 'Item Class Desc', 'B' );

/* Address Form  */

DELETE FROM T_ObjSecRef
WHERE  ObjParent_Name = 'ST_ADDRESS';

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'ST_ADDRESS', 'SaveInsert', 'Save Address And Create New Address', 'K' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'ST_ADDRESS', 'Insert', 'Insert Address', 'K' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'ST_ADDRESS', 'Update', 'Update Address', 'K' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'ST_ADDRESS', 'Delete', 'Delete Address', 'K' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'ST_ADDRESS', 'Query', 'Query Address', 'K' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'ST_ADDRESS', 'cDM_AddType', 'Address Type', 'C' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'ST_ADDRESS', 'vAddress1', 'Address1', 'B' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'ST_ADDRESS', 'vAddress2', 'Address2', 'B' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'ST_ADDRESS', 'vAddress3', 'Address3', 'B' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'ST_ADDRESS', 'vAddress4', 'Address4', 'B' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'ST_ADDRESS', 'vCity', 'City', 'B' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'ST_ADDRESS', 'vState', 'State', 'B' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'ST_ADDRESS', 'vPin', 'Pin Code', 'B' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'ST_ADDRESS', 'vTelNr', 'Telephone Number', 'B' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'ST_ADDRESS', 'vFaxNr', 'Fax Number', 'B' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'ST_ADDRESS', 'vTelexNr', 'Telex Number', 'B' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'ST_ADDRESS', 'vMailID', 'Mail ID', 'B' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'ST_ADDRESS', 'vContactPerson', 'Contact Person', 'B' );

/* Branch Form  */

DELETE FROM T_ObjSecRef
WHERE  ObjParent_Name = 'ST_BRANCH';

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'ST_BRANCH', 'SaveInsert', 'Save Branch And Create New Branch', 'K' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'ST_BRANCH', 'Insert', 'Insert Branch', 'K' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'ST_BRANCH', 'Update', 'Update Branch', 'K' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'ST_BRANCH', 'Delete', 'Delete Branch', 'K' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'ST_BRANCH', 'NewAddr', 'Insert Branch Address', 'K' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'ST_BRANCH', 'UpdDelAddr', 'Update/Delete Branch Address', 'K' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'ST_BRANCH', 'vBranch_Name', 'Branch Name', 'B' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'ST_BRANCH', 'vBranch_Desc', 'Branch Description', 'B' );

/* Client Form  */

DELETE FROM T_ObjSecRef
WHERE  ObjParent_Name = 'ST_CLIENT';

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'ST_CLIENT', 'SaveInsert', 'Save Client And Create New Client', 'K' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'ST_CLIENT', 'Insert', 'Insert Client', 'K' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'ST_CLIENT', 'Update', 'Update Client', 'K' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'ST_CLIENT', 'Delete', 'Delete Client', 'K' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'ST_CLIENT', 'NewAddr', 'Insert Client Address', 'K' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'ST_CLIENT', 'UpdDelAddr', 'Update/Delete Client Address', 'K' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'ST_CLIENT', 'vClient_Code', 'Client Code', 'B' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'ST_CLIENT', 'vClient_Type', 'Client Type', 'C' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'ST_CLIENT', 'vClient_Name', 'Client Name', 'B' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'ST_CLIENT', 'vClient_Desc', 'Client Description', 'B' );

/* Employee Form  */

DELETE FROM T_ObjSecRef
WHERE  ObjParent_Name = 'ST_EMPLOYEE';

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'ST_EMPLOYEE', 'SaveInsert', 'Save Employee And Create New Employee', 'K' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'ST_EMPLOYEE', 'Assign', 'Assign Employee Function', 'K' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'ST_EMPLOYEE', 'Insert', 'Insert Employee', 'K' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'ST_EMPLOYEE', 'Update', 'Update Employee', 'K' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'ST_EMPLOYEE', 'Delete', 'Delete Employee', 'K' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'ST_EMPLOYEE', 'NewAddr', 'Insert Employee Address', 'K' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'ST_EMPLOYEE', 'UpdDelAddr', 'Update/Delete Employee Address', 'K' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'ST_EMPLOYEE', 'vEmployee_Name', 'Employee Name', 'B' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'ST_EMPLOYEE', 'vEmployee_Desc', 'Employee Description', 'B' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'ST_EMPLOYEE', 'nFk_Branch_ID', 'Branch Name', 'C' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'ST_EMPLOYEE', 'vDesignation', 'Designation', 'B' );

/* Item Rate Form */

DELETE FROM T_ObjSecRef
WHERE  ObjParent_Name = 'ST_ITEMRATE';

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'ST_ITEMRATE', 'Insert', 'Insert Item Rate', 'K' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'ST_ITEMRATE', 'Update', 'Update Item Rate', 'K' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'ST_ITEMRATE', 'Delete', 'Delete Item Rate', 'K' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'ST_ITEMRATE', 'Query', 'Query Item Rate', 'K' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'ST_ITEMRATE', 'nFk_Item_ID', 'Item Name List', 'C' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'ST_ITEMRATE', 'dFrom_Dt', 'From Date', 'B' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'ST_ITEMRATE', 'dTo_Dt', 'To Date', 'B' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'ST_ITEMRATE', 'nMinQty', 'Minimum Quantity', 'B' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'ST_ITEMRATE', 'nMaxQty', 'Maximum Quantity', 'B' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'ST_ITEMRATE', 'nUnitPrice', 'Unit Price', 'B' );

/* Item Form */

DELETE FROM T_ObjSecRef
WHERE  ObjParent_Name = 'ST_ITEM';

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'ST_ITEM', 'SaveInsert', 'Save Item And Create New Item', 'K' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'ST_ITEM', 'Insert', 'Insert Item', 'K' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'ST_ITEM', 'Update', 'Update Item', 'K' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'ST_ITEM', 'Delete', 'Delete Item', 'K' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'ST_ITEM', 'Query', 'Query Item Details', 'K' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'ST_ITEM', 'AssignRate', 'Assign Item Rate', 'K' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'ST_ITEM', 'UpdDelRate', 'Update/Delete Item Rate', 'K' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'ST_ITEM', 'AssignCln', 'Assign Clients to Item', 'K' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'ST_ITEM', 'AssignUsr', 'Assign Users to Item', 'K' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'ST_ITEM', 'vItem_Name', 'Item Name', 'B' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'ST_ITEM', 'vItem_Desc', 'Item Desc', 'B' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'ST_ITEM', 'vItem_Rem1', 'Remark 1', 'B' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'ST_ITEM', 'vItem_Rem2', 'Remark 2', 'B' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'ST_ITEM', 'vItem_Rem3', 'Remark 3', 'B' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'ST_ITEM', 'vItem_Rem4', 'Remark 4', 'B' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'ST_ITEM', 'cDM_UnitType', 'Unit Type', 'C' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'ST_ITEM', 'nFk_ItemClass_ID', 'Item Class', 'C' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'ST_ITEM', 'nFk_ItemGroup_ID', 'Item Group', 'C' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'ST_ITEM', 'nFk_CostCentre_ID', 'Cost Centre', 'C' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'ST_ITEM', 'vSplInstruct', 'Spl Instruction', 'J' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'ST_ITEM', 'nMinOrdQty', 'Min Ord Qty', 'B' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'ST_ITEM', 'nMaxOrdQty', 'Max Ord Qty', 'B' );

/* Client Item Rate Form */

DELETE FROM T_ObjSecRef
WHERE  ObjParent_Name = 'ST_CLIENTITEMRATE';

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'ST_CLIENTITEMRATE', 'Insert', 'Insert Client Item Rate', 'K' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'ST_CLIENTITEMRATE', 'Update', 'Update Client Item Rate', 'K' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'ST_CLIENTITEMRATE', 'Delete', 'Delete Client Item Rate', 'K' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'ST_CLIENTITEMRATE', 'Query', 'Query Client Item Rate', 'K' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'ST_CLIENTITEMRATE', 'nFk_ClientItem_ID', 'Client Item Name List', 'C' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'ST_CLIENTITEMRATE', 'dFrom_Dt', 'From Date', 'B' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'ST_CLIENTITEMRATE', 'dTo_Dt', 'To Date', 'B' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'ST_CLIENTITEMRATE', 'nMinQty', 'Minimum Quantity', 'B' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'ST_CLIENTITEMRATE', 'nMaxQty', 'Maximum Quantity', 'B' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'ST_CLIENTITEMRATE', 'nUnitPrice', 'Unit Price', 'B' );

/* Client Item Form */

DELETE FROM T_ObjSecRef
WHERE  ObjParent_Name = 'ST_CLIENTITEM';

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'ST_CLIENTITEM', 'Show', 'Show Client - Items', 'K' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'ST_CLIENTITEMRATE', 'Save', 'Save Client - Items', 'K' );

/* User RelationShip Form */

DELETE FROM T_ObjSecRef
WHERE  ObjParent_Name = 'ST_USERREL';

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'ST_USERREL', 'Define', 'Define User RelationShip', 'K' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'ST_USERREL', 'Save', 'Save User RelationShip', 'K' );

/* Record Security Form  */

DELETE FROM T_ObjSecRef
WHERE  ObjParent_Name = 'SY_RECSEC';

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'SY_RECSEC', 'SaveInsert', 'Save Record Security And Create New RecSec', 'K' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'SY_RECSEC', 'Insert', 'Insert Record Secuirty', 'K' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'SY_RECSEC', 'Update', 'Update Record Secuirty', 'K' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'SY_RECSEC', 'Delete', 'Delete Record Secuirty', 'K' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'SY_RECSEC', 'Assign', 'Assign Record Security Priviledge', 'K' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'SY_RECSEC', 'vRecSec_Name', 'Record Secuirty Name', 'B' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'SY_RECSEC', 'vRecSec_Desc', 'Record Secuirty Description', 'B' );


/* Group Form  */

DELETE FROM T_ObjSecRef
WHERE  ObjParent_Name = 'SY_GROUP';

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'SY_GROUP', 'SaveInsert', 'Save Group And Create New Group', 'K' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'SY_GROUP', 'Insert', 'Insert Group', 'K' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'SY_GROUP', 'Update', 'Update Group', 'K' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'SY_GROUP', 'Delete', 'Delete Group', 'K' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'SY_GROUP', 'Assign', 'Assign Users', 'K' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'SY_GROUP', 'vGroup_Name', 'Group Name', 'B' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'SY_GROUP', 'vGroup_Desc', 'Group Description', 'B' );

/* User Form  */

DELETE FROM T_ObjSecRef
WHERE  ObjParent_Name = 'SY_USER';

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'SY_USER', 'SaveInsert', 'Save User And Create New User', 'K' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'SY_USER', 'Insert', 'Insert User', 'K' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'SY_USER', 'Update', 'Update User', 'K' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'SY_USER', 'Delete', 'Delete User', 'K' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'SY_USER', 'Assign', 'Assign Groups', 'K' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'SY_USER', 'vUser_Name', 'User Name', 'B' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'SY_USER', 'vUser_Pass', 'User Password', 'B' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'SY_USER', 'vUser_ConfPass', 'Confirm Password', 'B' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'SY_USER', 'vUser_Desc', 'User Description', 'B' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'SY_USER', 'nFk_Lang_ID', 'Language Name', 'C' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'SY_USER', 'nFk_Client_ID', 'Client Name', 'C' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'SY_USER', 'nFk_RecSec_ID', 'Record Security Name', 'C' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'SY_USER', 'nFk_Employee_ID', 'Employee Name', 'C' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'SY_USER', 'nFk_Scheme_ID', 'Scheme Name', 'C' );

/* Message Form  */

DELETE FROM T_ObjSecRef
WHERE  ObjParent_Name = 'SY_MSG';

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'SY_MSG', 'SaveInsert', 'Save Message And Create New Message', 'K' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'SY_MSG', 'Insert', 'Insert Message', 'K' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'SY_MSG', 'Update', 'Update Message', 'K' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'SY_MSG', 'Delete', 'Delete Message', 'K' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'SY_MSG', 'Query', 'Query Message Details', 'K' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'SY_MSG', 'nMsg_ID', 'Message ID', 'B' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'SY_MSG', 'nFk_Lang_ID', 'Language Name', 'C' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'SY_MSG', 'vMsg_Desc', 'Message Description', 'B' );

/* News Form  */

DELETE FROM T_ObjSecRef
WHERE  ObjParent_Name = 'SY_NEWS';

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'SY_NEWS', 'SaveInsert', 'Save News And Create New News', 'K' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'SY_NEWS', 'Insert', 'Insert News', 'K' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'SY_NEWS', 'Update', 'Update News', 'K' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'SY_NEWS', 'Delete', 'Delete News', 'K' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'SY_NEWS', 'Next', 'Next Records', 'K' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'SY_NEWS', 'Prev', 'Previous Records', 'K' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'SY_NEWS', 'vCaption', 'Caption', 'B' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'SY_NEWS', 'dNews_Date', 'News Date', 'B' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'SY_NEWS', 'vMatter', 'Matter', 'J' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'SY_NEWS', 'vOriginator', 'Originator', 'J' );

/* Parameter Form  */

DELETE FROM T_ObjSecRef
WHERE  ObjParent_Name = 'SY_PARAM';

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'SY_PARAM', 'SaveInsert', 'Save Parameter And Create New Parameter', 'K' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'SY_PARAM', 'Insert', 'Insert Parameter', 'K' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'SY_PARAM', 'Update', 'Update Parameter', 'K' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'SY_PARAM', 'Delete', 'Delete Parameter', 'K' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'SY_PARAM', 'cDMGroup', 'Parameter Class', 'C' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'SY_PARAM', 'cDMType', 'Parameter Type', 'C' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'SY_PARAM', 'vName', 'Parameter Name', 'B' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'SY_PARAM', 'vValue', 'Parameter Value', 'B' );

/* Configuration Form  */

DELETE FROM T_ObjSecRef
WHERE  ObjParent_Name = 'SY_CONFIG';

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'SY_CONFIG', 'SaveInsert', 'Save Config And Create New Config', 'K' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'SY_CONFIG', 'Insert', 'Insert Configuration', 'K' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'SY_CONFIG', 'Update', 'Update Configuration', 'K' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'SY_CONFIG', 'Delete', 'Delete Configuration', 'K' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'SY_CONFIG', 'Query', 'Query Configuration Details', 'K' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'SY_CONFIG', 'vParent_Obj', 'Parent Object', 'B' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'SY_CONFIG', 'nFk_Lang_ID', 'Language Name', 'C' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'SY_CONFIG', 'vObj_Name', 'Object Name', 'B' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'SY_CONFIG', 'vObj_Property', 'Object Property', 'B' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'SY_CONFIG', 'vProperty_Value', 'Property Value', 'B' );

/* Domain Form  */

DELETE FROM T_ObjSecRef
WHERE  ObjParent_Name = 'SY_DOMAIN';

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'SY_DOMAIN', 'Insert', 'Add New Attributes', 'K' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'SY_DOMAIN', 'Save', 'Save Attributes', 'K' );

/* Object Security Form  */

DELETE FROM T_ObjSecRef
WHERE  ObjParent_Name = 'SY_OBJSEC';

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'SY_OBJSEC', 'Insert', 'Insert Object Security', 'K' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'SY_OBJSEC', 'New', 'Create New Object Security', 'K' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'SY_OBJSEC', 'Update', 'Update Object Security', 'K' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'SY_OBJSEC', 'Delete', 'Delete Object Security', 'K' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'SY_OBJSEC', 'Query', 'Query Object Security Details', 'K' );

/* Menu Security Form  */

DELETE FROM T_ObjSecRef
WHERE  ObjParent_Name = 'SY_MENUSEC';

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'SY_MENUSEC', 'Insert', 'Create New Menu Security', 'K' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'SY_MENUSEC', 'Save', 'Save Menu Security', 'K' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'SY_MENUSEC', 'Query', 'Menu Security Form Information', 'K' );

/* Cost Centre Form  */

DELETE FROM T_ObjSecRef
WHERE  ObjParent_Name = 'ST_COSTCENTRE';

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'ST_COSTCENTRE', 'Insert', 'Insert CostCentre', 'K' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'ST_COSTCENTRE', 'SaveInsert', ' Save CostCentre And Create New CostCentre', 'K' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'ST_COSTCENTRE', 'Update', 'Update CostCentre', 'K' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'ST_COSTCENTRE', 'Delete', 'Delete CostCentre', 'K' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'ST_COSTCENTRE', 'vCostCentre_Name', 'CostCentre Name', 'B' );

Insert Into T_ObjSecRef( ObjParent_Name, Obj_Name, Obj_Desc, DM_ObjType )
  Values( 'ST_COSTCENTRE', 'vCostCentre_Desc', 'CostCentre Desc', 'B' );

commit;

/* PROMPT *****[ Ending L_RecSec.sql ]***** */
