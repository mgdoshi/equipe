/* Script Name : DropSeqs.sql
   Author      : Manoj Doshi.
   Description : Script to drop all the Sequences.
*/

/* PROMPT *****[ Starting DropSeqs.sql ]***** */

DROP SEQUENCE S_Address;
DROP SEQUENCE S_AddressRef;
DROP SEQUENCE S_Audit;
DROP SEQUENCE S_Branch;
DROP SEQUENCE S_CartDef;
DROP SEQUENCE S_Client;
DROP SEQUENCE S_ClientItem;
DROP SEQUENCE S_ClientItemRate;
DROP SEQUENCE S_Config;
DROP SEQUENCE S_CostCentre;
DROP SEQUENCE S_Delivery;
DROP SEQUENCE S_DeliveryDtls;
DROP SEQUENCE S_DataLog;
DROP SEQUENCE S_Employee;
DROP SEQUENCE S_Group;
DROP SEQUENCE S_Help;
DROP SEQUENCE S_Item;
DROP SEQUENCE S_ItemClass;
DROP SEQUENCE S_ItemGroup;
DROP SEQUENCE S_ItemPack;
DROP SEQUENCE S_ItemRate;
DROP SEQUENCE S_Lang;
DROP SEQUENCE S_MenuSec;
DROP SEQUENCE S_News;
DROP SEQUENCE S_ObjSec;
DROP SEQUENCE S_Order;
DROP SEQUENCE S_OrderDtls;
DROP SEQUENCE S_Param;
DROP SEQUENCE S_RecSec;
DROP SEQUENCE S_Scheme;
DROP SEQUENCE S_Template;
DROP SEQUENCE S_TemplateDtls;
DROP SEQUENCE S_Trans;
DROP SEQUENCE S_User;
DROP SEQUENCE S_UserGroup;
DROP SEQUENCE S_Userparam;

/* PROMPT*****[ Ending DropSeqs.sql ]***** */
