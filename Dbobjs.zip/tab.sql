Drop Table T_Addressref;

CREATE TABLE T_AddressRef
  ( AddressRef_id   Integer NOT NULL,
    RefType         VarChar(30) NOT NULL,
    FK_Address_ID   Integer NOT NULL,
    Ref_ID          Integer NOT NULL,
    Default_Flag    Char(1),
    Modifier        VarChar(30),
    Change_Dt       DateTime,
    CONSTRAINT AddressRef_PK PRIMARY KEY ( AddressRef_ID ),
    FOREIGN KEY ( FK_Address_ID ) REFERENCES  T_Address ( Address_ID ) ON DELETE CASCADE
  );
