/* Script Name : AllIdxs.sql
   Author      : Manoj Doshi.
   Description : Script to create all indexes of the tables.
*/

/* PROMPT *****[ Creating All Indexes ]***** */

Create Unique Index AddressRef_UKX1 on 
  T_AddressRef ( RefType, FK_Address_ID, Ref_ID ) ;

Create Unique Index Branch_UKX1 on 
  T_Branch ( Branch_Name ); 

Create Unique Index CartDef_UKX1 on 
  T_CartDef ( CartDef_Name ) ;

Create Unique Index Client_UKX1 on 
  T_Client ( Client_Name ); 

Create Unique Index Client_UKX2 on 
  T_Client ( Client_Code ); 

Create Unique Index ClientItem_UKX1 on 
  T_ClientItem ( FK_Client_ID, FK_Item_ID ) ;

Create Index ClientItemRate_IDX1 on 
  T_ClientItemRate ( FK_ClientItem_ID ); 

Create Unique Index Config_UKX1 on
  T_Config ( Parent_Obj, Obj_Name, FK_Lang_ID, Obj_Property );

Create Unique Index CostCentre_UKX1 on 
  T_CostCentre ( CostCentre_Name ); 

Create Unique Index Delivery_UKX1 on 
  T_Delivery ( Delivery_Nr ); 

Create Unique Index DeliveryDtls_UKX1 on 
  T_DeliveryDtls ( FK_Delivery_ID, Pos_Nr ) ;

Create Unique Index OrderDelivery_UKX0 on 
  T_OrderDelivery ( FK_Order_ID, FK_Delivery_ID ) ;

Create Index OrderDelivery_IDX1 on 
  T_OrderDelivery ( FK_Delivery_ID, FK_Order_ID ) ;

Create Unique Index Domain_UKX0 on 
  T_Domain ( Domain, FK_Lang_ID, Sequence_Nr, Attrib ) ;

Create Unique Index Domain_IDX1 on 
  T_Domain ( Domain, FK_Lang_ID, Attrib ) ;

Create Unique Index Domain_IDX2 on 
  T_Domain ( Domain, FK_Lang_ID, Attrib_Desc ) ;

Create Index EmployeeFunc_IDX1 on 
  T_EmployeeFunc ( FK_Employee_ID, DM_FuncType ) ;

Create Unique Index Employee_UKX1 on 
  T_Employee ( Employee_Name ) ;

Create Unique Index Group_UKX1 on 
  T_Group ( Group_Name ); 

Create Unique Index Item_UKX1 on 
  T_Item ( Item_Name ); 

Create Unique Index ItemClass_UKX1 on 
  T_ItemClass ( ItemClass_Name ) ;

Create Unique Index ItemGroup_UKX1 on 
  T_ItemGroup ( ItemGroup_Name ); 

Create Unique Index ItemPack_UKX1 on 
  T_ItemPack ( ItemPack_Name ); 

Create Index ItemRate_IDX1 on 
  T_ItemRate ( FK_Item_ID ); 

Create Unique Index Lang_UKX1 on 
  T_Lang ( Lang_Name ); 

Create Unique Index MenuSec_IDX1 on
  T_MenuSec ( Menu_Name, DM_SecLevel, Ref_ID );

Create Index ObjSec_IDX1 on
  T_ObjSec ( ObjParent_Name, Obj_Name, DM_SecLevel, Ref_ID );

Create Unique Index Order_UKX1 on 
  T_Order ( Order_Nr ); 

Create Unique Index OrderDtls_UKX1 on 
  T_OrderDtls ( FK_Order_ID, Pos_Nr ) ;

Create Unique Index Param_UKX1 on 
  T_Param ( Param_Name ); 

Create Unique Index RecSec_UKX1 on 
  T_RecSec ( RecSec_Name ) ;

Create Unique Index Scheme_UKX1 on 
  T_Scheme ( Scheme_Name ); 

Create  Index SchemeRef_IDX1 on 
  T_SchemeRef ( FK_Scheme_ID, DM_ObjType, DM_OpMode ) ;

Create Unique Index ScriptSource_UKX0 on 
  T_ScriptSource ( Script_Name, Line_Nr ); 

Create Unique Index Template_UKX1 on 
  T_Template ( Template_Name ); 

Create Unique Index TemplateDtls_UKX1 on 
  T_TemplateDtls ( FK_Template_ID, Pos_Nr ) ;

Create Unique Index User_UKX1 on 
  T_User ( User_Name ); 

Create Unique Index UserGroup_UKX1 on 
  T_UserGroup ( FK_Group_ID, FK_User_ID ) ;

Create Index UserGroup_IDX1 on 
  T_UserGroup ( FK_user_ID, FK_Group_ID ); 

Create Unique Index UserParam_UKX1 on 
  T_UserParam ( FK_User_ID, UserParam_Name ) ;
