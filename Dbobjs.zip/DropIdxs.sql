/* Script Name : DropIdxs.sql
   Author      : Manoj Doshi.
   Description : Script to drop all indexes of the tables.
*/

/* PROMPT *****[ Dropping All Indexes ]***** */

Drop Index AddressRef_UKX1;
Drop Index Branch_UKX1;
Drop Index CartDef_UKX1;
Drop Index Client_UKX1;
Drop Index Client_UKX2;
Drop Index ClientItem_UKX1;
Drop Index ClientItemRate_IDX1;
Drop Index Config_UKX1;
Drop Index CostCentre_UKX1;
Drop Index Delivery_UKX1;
Drop Index DeliveryDtls_UKX1;
Drop Index OrderDelivery_UKX0;
Drop Index OrderDelivery_IDX1;
Drop Index Domain_UKX0;
Drop Index Domain_IDX1;
Drop Index Domain_IDX2;
Drop Index EmployeeFunc_IDX1;
Drop Index Employee_UKX1;
Drop Index Group_UKX1;
Drop Index Item_UKX1;
Drop Index ItemClass_UKX1;
Drop Index ItemGroup_UKX1;
Drop Index ItemPack_UKX1;
Drop Index ItemRate_IDX1;
Drop Index Lang_UKX1;
Drop Index MenuSec_IDX1;
Drop Index ObjSec_IDX1;
Drop Index Order_UKX1;
Drop Index OrderDtls_UKX1;
Drop Index Param_UKX1;
Drop Index RecSec_UKX1;
Drop Index Scheme_UKX1;
Drop  Index SchemeRef_IDX1;
Drop Index ScriptSource_UKX0;
Drop Index Template_UKX1;
Drop Index TemplateDtls_UKX1;
Drop Index User_UKX1;
Drop Index UserGroup_UKX1;
Drop Index UserGroup_IDX1;
Drop Index UserParam_UKX1;

/* PROMPT *****[ Dropping All Indexes Ends ]***** */
