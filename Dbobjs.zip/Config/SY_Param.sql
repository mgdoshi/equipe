/* Script Name : SY_PARAM.sql.
   Author      : Manoj Doshi : Ingenium Computing Private Ltd, on 25th July 1999.
   Description : Config Details for Param Form
*/

PROMPT *****[ Starting SY_PARAM.sql ]*****

DELETE FROM T_Config
WHERE  Parent_Obj = 'SY_PARAM'
AND    Fk_Lang_ID = 1;

		/* Form Name */

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'SY_PARAM', 1, 'WD_TABLE', 'LABEL', 'Parameter / T' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'SY_PARAM', 1, 'WD_FORM_INSERT', 'LABEL', 'Parameter / I' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'SY_PARAM', 1, 'WD_FORM_UPDATE', 'LABEL', 'Parameter / U' );

		/* Buttons */

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'SY_PARAM', 1, 'BL_PARAM.BU_NEW', 'LABEL', 'Create New Parameter' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'SY_PARAM', 1, 'BL_PARAM.BU_UPDATE', 'LABEL', 'Update Parameter' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
 ( NEXTVAL('S_Config'), 'SY_PARAM', 1, 'BL_PARAM.BU_DELETE', 'LABEL', 'Delete Parameter' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'SY_PARAM', 1, 'BL_PARAM.BU_SAVE', 'LABEL', 'Save Parameter' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'SY_PARAM', 1, 'BL_PARAM.BU_SAVE1', 'LABEL', 'Save Parameter And Create New Parameter' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'SY_PARAM', 1, 'BL_PARAM.BU_FORMHELP', 'LABEL', 'Parameter Form Information' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'SY_PARAM', 1, 'BL_PARAM.BU_HELP', 'LABEL', 'Parameter Form Help' );

		/* Fields */

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'SY_PARAM', 1, 'BL_LABEL.B_PARAM_DM_PARCLASS', 'VALUE', 'Parameter Class' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'SY_PARAM', 1, 'BL_LABEL.B_PARAM_DM_PARTYPE', 'VALUE', 'Parameter Type' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'SY_PARAM', 1, 'BL_LABEL.B_PARAM_PARAM_NAME', 'VALUE', 'Parameter Name' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'SY_PARAM', 1, 'BL_LABEL.B_PARAM_PARAM_VALUE', 'VALUE', 'Parameter Value' );

commit;

PROMPT *****[ Ending SY_PARAM.sql ]*****
