/* Script Name : SY_GROUP.sql.
   Author      : Manoj Doshi : Ingenium Computing Private Ltd, on 25th July 1999.
   Description : Config Details for Group Form
*/

PROMPT *****[ Starting SY_GROUP.sql ]*****

DELETE FROM T_Config
WHERE  Parent_Obj = 'SY_GROUP'
AND    Fk_Lang_ID = 1;

		/* Form Name */

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'SY_GROUP', 1, 'WD_TABLE', 'LABEL', 'Group / T' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'SY_GROUP', 1, 'WD_FORM_INSERT', 'LABEL', 'Group / I' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'SY_GROUP', 1, 'WD_FORM_UPDATE', 'LABEL', 'Group / U' );

		/* Buttons */

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'SY_GROUP', 1, 'BL_GROUP.BU_NEW', 'LABEL', 'Create New Group' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'SY_GROUP', 1, 'BL_GROUP.BU_UPDATE', 'LABEL', 'Update Group' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
 ( NEXTVAL('S_Config'), 'SY_GROUP', 1, 'BL_GROUP.BU_DELETE', 'LABEL', 'Delete Group' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'SY_GROUP', 1, 'BL_GROUP.BU_SAVE', 'LABEL', 'Save Group' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'SY_GROUP', 1, 'BL_GROUP.BU_SAVE1', 'LABEL', 'Save Group And Create New Group' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'SY_GROUP', 1, 'BL_GROUP.BU_ASSIGN', 'LABEL', 'Assign Users' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'SY_GROUP', 1, 'BL_GROUP.BU_FORMHELP', 'LABEL', 'Group Form Information' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'SY_GROUP', 1, 'BL_GROUP.BU_HELP', 'LABEL', 'Group Form Help' );

		/* Fields */

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'SY_GROUP', 1, 'BL_LABEL.B_GROUP_GROUP_NAME', 'VALUE', 'Group Name' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'SY_GROUP', 1, 'BL_LABEL.B_GROUP_GROUP_DESC', 'VALUE', 'Description' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'SY_GROUP', 1, 'BL_LABEL.B_GROUP_ASSIGN', 'VALUE', 'Assign' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'),'SY_GROUP',1, 'BL_LABEL.B_GROUP_DEASSIGN', 'VALUE', 'DeAssign' );
 
commit;

PROMPT *****[ Ending SY_GROUP.sql ]*****
