/* Script Name : ST_COSTCENTRE.sql.
   Author      : Manoj Doshi : Ingenium Computing Private Ltd, on 23th July 1999.
   Description : Config Details for CostCentre Form
*/

PROMPT *****[ Starting ST_COSTCENTRE.sql ]*****

DELETE FROM T_Config
WHERE  Parent_Obj = 'ST_COSTCENTRE'
AND    Fk_Lang_ID = 1;

		/* Form Name */

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'ST_COSTCENTRE', 1, 'WD_TABLE', 'LABEL', 'CostCentre / T' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'ST_COSTCENTRE', 1, 'WD_FORM_INSERT', 'LABEL', 'CostCentre / I' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'ST_COSTCENTRE', 1, 'WD_FORM_UPDATE', 'LABEL', 'CostCentre / U' );

		/* Buttons */

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'ST_COSTCENTRE', 1, 'BL_COSTCENTRE.BU_NEW', 'LABEL', 'Create New CostCentre' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'ST_COSTCENTRE', 1, 'BL_COSTCENTRE.BU_UPDATE', 'LABEL', 'Update CostCentre' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
 ( NEXTVAL('S_Config'), 'ST_COSTCENTRE', 1, 'BL_COSTCENTRE.BU_DELETE', 'LABEL', 'Delete CostCentre' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'ST_COSTCENTRE', 1, 'BL_COSTCENTRE.BU_SAVE', 'LABEL', 'Save CostCentre' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'ST_COSTCENTRE', 1, 'BL_COSTCENTRE.BU_SAVE1', 'LABEL', 'Save CostCentre And Create New CostCentre' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'ST_COSTCENTRE', 1, 'BL_COSTCENTRE.BU_FORMHELP', 'LABEL', 'CostCentre Form Information' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'ST_COSTCENTRE', 1, 'BL_COSTCENTRE.BU_HELP', 'LABEL', 'CostCentre Form Help' );

		/* Fields */

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'ST_COSTCENTRE', 1, 'BL_LABEL.B_COSTCENTRE_COSTCENTRE_NAME', 'VALUE', 'CostCentre Name' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'ST_COSTCENTRE', 1, 'BL_LABEL.B_COSTCENTRE_COSTCENTRE_DESC', 'VALUE', 'Description' );

commit;

PROMPT *****[ Ending ST_COSTCENTRE.sql ]*****
