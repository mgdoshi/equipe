/* Script Name : SY_USER.sql.
   Author      : Manoj Doshi : Ingenium Computing Private Ltd, on 25th July 1999.
   Description : Config Details for User Form
*/

PROMPT *****[ Starting SY_USER.sql ]*****

DELETE FROM T_Config
WHERE  Parent_Obj = 'SY_USER'
AND    Fk_Lang_ID = 1;

		/* Form Name */

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'SY_USER', 1, 'WD_LOGIN', 'LABEL', 'Login Form' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'SY_USER', 1, 'WD_LOGOUT', 'LABEL', 'Logout Form' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'SY_USER', 1, 'WD_TABLE', 'LABEL', 'User / T' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'SY_USER', 1, 'WD_FORM_INSERT', 'LABEL', 'User / I' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'SY_USER', 1, 'WD_FORM_UPDATE', 'LABEL', 'User / U' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'SY_USER', 1, 'WD_FORM_UPD_PASSWD', 'LABEL', 'Change Password / U' );

		/* Buttons */

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'SY_USER', 1, 'BL_USER.BU_NEW', 'LABEL', 'Create New User' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'SY_USER', 1, 'BL_USER.BU_UPDATE', 'LABEL', 'Update User' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
 ( NEXTVAL('S_Config'), 'SY_USER', 1, 'BL_USER.BU_DELETE', 'LABEL', 'Delete User' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'SY_USER', 1, 'BL_USER.BU_SAVE', 'LABEL', 'Save User' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'SY_USER', 1, 'BL_USER.BU_SAVE1', 'LABEL', 'Save User And Create New User' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'SY_USER', 1, 'BL_USER.BU_ASSIGN', 'LABEL', 'Assign Groups' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'SY_USER', 1, 'BL_USER.BU_CHANGE_PASSWD', 'LABEL', 'Change Old Password' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'SY_USER', 1, 'BL_USER.BU_FORMHELP', 'LABEL', 'User Form Information' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'SY_USER', 1, 'BL_USER.BU_HELP', 'LABEL', 'User Form Help' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'SY_USER', 1, 'BL_USER.BU_HELP1', 'LABEL', 'Change Password Form Help' );

		/* Fields */

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'SY_USER', 1, 'BL_LABEL.B_USER_LOGIN', 'VALUE', 'Login to Order Tracking System' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'SY_USER', 1, 'BL_LABEL.B_USER_USER_NAME', 'VALUE', 'User Name' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'SY_USER', 1, 'BL_LABEL.B_USER_USER_PASS', 'VALUE', 'User Password' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'SY_USER', 1, 'BL_LABEL.B_USER_CONFIRM_PASSWD', 'VALUE', 'Confirm PassWord' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'SY_USER', 1, 'BL_LABEL.B_USER_USER_DESC', 'VALUE', 'Description' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'SY_USER', 1, 'BL_LABEL.B_USER_FK_LANG_ID', 'VALUE', 'Language' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'SY_USER', 1, 'BL_LABEL.B_USER_FK_CLIENT_ID', 'VALUE', 'Client Name' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'SY_USER', 1, 'BL_LABEL.B_USER_FK_RECSEC_ID', 'VALUE', 'RecSec Name' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'SY_USER', 1, 'BL_LABEL.B_USER_FK_EMPLOYEE_ID', 'VALUE', 'Employee Name' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'SY_USER', 1, 'BL_LABEL.B_USER_FK_SCHEME_ID', 'VALUE', 'Scheme Name' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'SY_USER', 1, 'BL_LABEL.B_USER_ASSIGN', 'VALUE', 'Assign' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'SY_USER', 1, 'BL_LABEL.B_USER_DEASSIGN', 'VALUE', 'DeAssign' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'SY_USER', 1, 'BL_LABEL.B_USER_OLD_PASSWORD', 'VALUE', 'Old Password' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'SY_USER', 1, 'BL_LABEL.B_USER_NEW_PASSWORD', 'VALUE', 'New Password' );


commit;

PROMPT *****[ Ending SY_USER.sql ]*****
