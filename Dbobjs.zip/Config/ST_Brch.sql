/* Script Name : ST_BRANCH.sql.
   Author      : Manoj Doshi : Ingenium Computing Private Ltd, on 23th July 1999.
   Description : Config Details for Branch Form
*/

PROMPT *****[ Starting ST_Branch.sql ]*****

DELETE FROM T_Config
WHERE  Parent_Obj = 'ST_BRANCH'
AND    Fk_Lang_ID = 1;

		/* Form Name */

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'ST_BRANCH', 1, 'WD_TABLE', 'LABEL', 'Branch / T' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'ST_BRANCH', 1, 'WD_FORM_INSERT', 'LABEL', 'Branch / I' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'ST_BRANCH', 1, 'WD_FORM_UPDATE', 'LABEL', 'Branch / U' );

		/* Buttons */

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'ST_BRANCH', 1, 'BL_BRANCH.BU_NEW', 'LABEL', 'Create New Branch' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'ST_BRANCH', 1, 'BL_BRANCH.BU_UPDATE', 'LABEL', 'Update Branch' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'ST_BRANCH', 1, 'BL_BRANCH.BU_DELETE', 'LABEL', 'Delete Branch' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'ST_BRANCH', 1, 'BL_BRANCH.BU_SAVE', 'LABEL', 'Save Branch' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'ST_BRANCH', 1, 'BL_BRANCH.BU_SAVE1', 'LABEL', 'Save Branch And Create New Branch' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'ST_BRANCH', 1, 'BL_BRANCH.BU_INS_ADDRESS', 'LABEL', 'Create New Address' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'ST_BRANCH', 1, 'BL_BRANCH.BU_UPD_ADDRESS', 'LABEL', 'Update/Delete Address' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'ST_BRANCH', 1, 'BL_BRANCH.BU_FORMHELP', 'LABEL', 'Branch Form Information' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'ST_BRANCH', 1, 'BL_BRANCH.BU_HELP', 'LABEL', 'Branch Form Help' );

		/* Fields */

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'ST_BRANCH', 1, 'BL_LABEL.B_BRANCH_BRANCH_NAME', 'VALUE', 'Branch Name' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'ST_BRANCH', 1, 'BL_LABEL.B_BRANCH_BRANCH_DESC', 'VALUE', 'Description ' );

commit;

PROMPT *****[ Ending ST_BRANCH.sql ]*****
