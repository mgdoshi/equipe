/* Script Name : SY_CONFIG.sql.
   Author      : Manoj Doshi : Ingenium Computing Private Ltd, on 25th July 1999.
   Description : Config Details for Config Form
*/

PROMPT *****[ Starting SY_CONFIG.sql ]*****

DELETE FROM T_Config
WHERE  Parent_Obj = 'SY_CONFIG'
AND    Fk_Lang_ID = 1;

		/* Form Name */

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'SY_CONFIG', 1, 'WD_QUERY', 'LABEL', 'Config / Q' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'SY_CONFIG', 1, 'WD_TABLE', 'LABEL', 'Config / T' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'SY_CONFIG', 1, 'WD_FORM_INSERT', 'LABEL', 'Config / I' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'SY_CONFIG', 1, 'WD_FORM_UPDATE', 'LABEL', 'Config / U' );

		/* Buttons */

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'SY_CONFIG', 1, 'BL_CONFIG.BU_QUERY', 'LABEL', 'Query Config Details' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'SY_CONFIG', 1, 'BL_CONFIG.BU_NEW', 'LABEL', 'Create New Config' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'SY_CONFIG', 1, 'BL_CONFIG.BU_UPDATE', 'LABEL', 'Update Config' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
 ( NEXTVAL('S_Config'), 'SY_CONFIG', 1, 'BL_CONFIG.BU_DELETE', 'LABEL', 'Delete Config' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'SY_CONFIG', 1, 'BL_CONFIG.BU_SAVE', 'LABEL', 'Save Config' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'SY_CONFIG', 1, 'BL_CONFIG.BU_SAVE1', 'LABEL', 'Save Config And Create New Config' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'SY_CONFIG', 1, 'BL_CONFIG.BU_FORMHELP', 'LABEL', 'Config Form Information' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'SY_CONFIG', 1, 'BL_CONFIG.BU_HELP', 'LABEL', 'Config Form Help' );

		/* Fields */

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'SY_CONFIG', 1, 'BL_LABEL.B_CONFIG_PARENT_OBJ', 'VALUE', 'Parent Object' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'SY_CONFIG', 1, 'BL_LABEL.B_CONFIG_FK_LANG_ID', 'VALUE', 'Language' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'SY_CONFIG', 1, 'BL_LABEL.B_CONFIG_OBJ_NAME', 'VALUE', 'Object Name' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'SY_CONFIG', 1, 'BL_LABEL.B_CONFIG_OBJ_PROPERTY', 'VALUE', 'Object Property' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'SY_CONFIG', 1, 'BL_LABEL.B_CONFIG_PROPERTY_VALUE', 'VALUE', 'Property Value' );

commit;

PROMPT *****[ Ending SY_CONFIG.sql ]*****
