/* Script Name : SY_RECSEC.sql.
   Author      : Manoj Doshi : Ingenium Computing Private Ltd, on 25th July 1999.
   Description : Config Details for RecSec Form
*/

PROMPT *****[ Starting SY_RECSEC.sql ]*****

DELETE FROM T_Config
WHERE  Parent_Obj = 'SY_RECSEC'
AND    Fk_Lang_ID = 1;

		/* Form Name */

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'SY_RECSEC', 1, 'WD_TABLE', 'LABEL', 'Record Security / T' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'SY_RECSEC', 1, 'WD_FORM_INSERT', 'LABEL', 'Record Security / I' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'SY_RECSEC', 1, 'WD_FORM_UPDATE', 'LABEL', 'Record Security / U' );

		/* Buttons */

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'SY_RECSEC', 1, 'BL_RECSEC.BU_NEW', 'LABEL', 'Create New Record Security' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'SY_RECSEC', 1, 'BL_RECSEC.BU_UPDATE', 'LABEL', 'Update Record Security' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
 ( NEXTVAL('S_Config'), 'SY_RECSEC', 1, 'BL_RECSEC.BU_DELETE', 'LABEL', 'Delete Record Security' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'SY_RECSEC', 1, 'BL_RECSEC.BU_SAVE', 'LABEL', 'Save Record Security' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'SY_RECSEC', 1, 'BL_RECSEC.BU_SAVE1', 'LABEL', 'Save Record Security And Create New RecSec' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'SY_RECSEC', 1, 'BL_RECSEC.BU_ASSIGN', 'LABEL', 'Assign Record Security Priviledge' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'SY_RECSEC', 1, 'BL_RECSEC.BU_FORMHELP', 'LABEL', 'Record Security Form Information' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'SY_RECSEC', 1, 'BL_RECSEC.BU_HELP', 'LABEL', 'Record Security Form Help' );

		/* Fields */

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'SY_RECSEC', 1, 'BL_LABEL.B_RECSEC_RECSEC_NAME', 'VALUE', 'Record Security Name' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'SY_RECSEC', 1, 'BL_LABEL.B_RECSEC_RECSEC_DESC', 'VALUE', 'Description' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'SY_RECSEC', 1, 'BL_LABEL.B_RECSEC_CHECK', 'VALUE', 'Check' );

commit;

PROMPT *****[ Ending SY_RECSEC.sql ]*****
