/* Script Name : SY_MSG.sql.
   Author      : Manoj Doshi : Ingenium Computing Private Ltd, on 25th July 1999.
   Description : Config Details for Message Form
*/

PROMPT *****[ Starting SY_MSG.sql ]*****

DELETE FROM T_Config
WHERE  Parent_Obj = 'SY_MSG'
AND    Fk_Lang_ID = 1;

		/* Form Name */

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'SY_MSG', 1, 'WD_QUERY', 'LABEL', 'Message / Q' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'SY_MSG', 1, 'WD_TABLE', 'LABEL', 'Message / T' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'SY_MSG', 1, 'WD_FORM_INSERT', 'LABEL', 'Message / I' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'SY_MSG', 1, 'WD_FORM_UPDATE', 'LABEL', 'Message / U' );

		/* Buttons */

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'SY_MSG', 1, 'BL_MESSAGE.BU_QUERY', 'LABEL', 'Query Message Details' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'SY_MSG', 1, 'BL_MESSAGE.BU_NEW', 'LABEL', 'Create New Message' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'SY_MSG', 1, 'BL_MESSAGE.BU_UPDATE', 'LABEL', 'Update Message' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
 ( NEXTVAL('S_Config'), 'SY_MSG', 1, 'BL_MESSAGE.BU_DELETE', 'LABEL', 'Delete Message' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'SY_MSG', 1, 'BL_MESSAGE.BU_SAVE', 'LABEL', 'Save Message' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'SY_MSG', 1, 'BL_MESSAGE.BU_SAVE1', 'LABEL', 'Save Message And Create New Message' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'SY_MSG', 1, 'BL_MESSAGE.BU_FORMHELP', 'LABEL', 'Message Form Information' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'SY_MSG', 1, 'BL_MESSAGE.BU_HELP', 'LABEL', 'Message Form Help' );

		/* Fields */

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'SY_MSG', 1, 'BL_LABEL.B_MESSAGE_MSG_NO_FROM', 'VALUE', 'Msg No From' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'SY_MSG', 1, 'BL_LABEL.B_MESSAGE_MSG_NO_TO', 'VALUE', 'Msg No To' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'SY_MSG', 1, 'BL_LABEL.B_MESSAGE_LANG', 'VALUE', 'Language' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'SY_MSG', 1, 'BL_LABEL.B_MESSAGE_MSG_ID', 'VALUE', 'Msg ID' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'SY_MSG', 1, 'BL_LABEL.B_MESSAGE_DESCRIPTION', 'VALUE', 'Description' );

commit;

PROMPT *****[ Ending SY_MSG.sql ]*****
