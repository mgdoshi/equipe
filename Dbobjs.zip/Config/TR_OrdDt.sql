/* Script Name : TR_OrderDetails.sql.
   Author      : Manoj Doshi : Ingenium Computing Private Ltd, on 10th July 1999.
   Description : Config Details for Order Details Form
*/

PROMPT *****[ Starting TR_Order.sql ]*****

DELETE FROM T_Config
WHERE  Parent_Obj = 'TR_ORDDTLS'
AND    Fk_Lang_ID = 1;

		/* Form Name */

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Property_Value, Obj_Property )
Values
  ( NEXTVAL('S_Config'), 'TR_ORDDTLS', 1, 'WD_ORDERDTLS', 'Order Details', 'LABEL' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Property_Value, Obj_Property )
Values
  ( NEXTVAL('S_Config'), 'TR_ORDDTLS', 1, 'WD_TABLE', 'Order Details / T', 'LABEL' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Property_Value, Obj_Property )
Values
  ( NEXTVAL('S_Config'), 'TR_ORDDTLS', 1, 'WD_FORM_INSERT', 'Order Details / I', 'LABEL' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Property_Value, Obj_Property )
Values
  ( NEXTVAL('S_Config'), 'TR_ORDDTLS', 1, 'WD_FORM_UPDATE', 'Order Details / U', 'LABEL' );

		/* Buttons */

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'TR_ORDDTLS', 1, 'BL_ORDERDTLS.BU_SAVE', 'LABEL', 'Save Order Details' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'TR_ORDDTLS', 1, 'BL_ORDERDTLS.BU_SHOWITEMS', 'LABEL', 'Show Shopping Cart List' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'TR_ORDDTLS', 1, 'BL_ORDERDTLS.BU_NEW', 'LABEL', 'Create New Order Details' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'TR_ORDDTLS', 1, 'BL_ORDERDTLS.BU_DELETE', 'LABEL', 'Delete Order Details' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'TR_ORDDTLS', 1, 'BL_ORDERDTLS.BU_UPDATE', 'LABEL', 'Update Order Details' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'TR_ORDDTLS', 1, 'BL_ORDERDTLS.BU_FORMHELP', 'LABEL', 'Order Details Form Information' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'TR_ORDDTLS', 1, 'BL_ORDERDTLS.BU_HELP', 'LABEL', 'Order Details Form Help' );

		/* Fields */

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Property_Value, Obj_Property )
Values
  ( NEXTVAL('S_Config'), 'TR_ORDDTLS', 1, 'BL_LABEL.B_ORDERDTLS_POS_NR', 'Pos No', 'LABEL' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Property_Value, Obj_Property )
Values
  ( NEXTVAL('S_Config'), 'TR_ORDDTLS', 1, 'BL_LABEL.B_ORDERDTLS_FK_ITEM_ID', 'Item', 'LABEL' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Property_Value, Obj_Property )
Values
  ( NEXTVAL('S_Config'), 'TR_ORDDTLS', 1, 'BL_LABEL.B_ORDERDTLS_FK_ITEMPACK_ID', 'Item Pack', 'LABEL' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Property_Value, Obj_Property )
Values
  ( NEXTVAL('S_Config'), 'TR_ORDDTLS', 1, 'BL_LABEL.B_ORDERDTLS_QUANTITY', 'Quantity', 'LABEL' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Property_Value, Obj_Property )
Values
  ( NEXTVAL('S_Config'), 'TR_ORDDTLS', 1, 'BL_LABEL.B_ORDERDTLS_DM_UNITTYPE', 'Unit Type', 'LABEL' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Property_Value, Obj_Property )
Values
  ( NEXTVAL('S_Config'), 'TR_ORDDTLS', 1, 'BL_LABEL.B_ORDERDTLS_UNITPRICE', 'Unit Price', 'LABEL' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Property_Value, Obj_Property )
Values
  ( NEXTVAL('S_Config'), 'TR_ORDDTLS', 1, 'BL_LABEL.B_ORDERDTLS_TEXT1', 'Custom Text1', 'LABEL' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Property_Value, Obj_Property )
Values
  ( NEXTVAL('S_Config'), 'TR_ORDDTLS', 1, 'BL_LABEL.B_ORDERDTLS_TEXT2', 'Custom Text2', 'LABEL' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Property_Value, Obj_Property )
Values
  ( NEXTVAL('S_Config'), 'TR_ORDDTLS', 1, 'BL_LABEL.B_ORDERDTLS_TEXT3', 'Custom Text3', 'LABEL' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Property_Value, Obj_Property )
Values
  ( NEXTVAL('S_Config'), 'TR_ORDDTLS', 1, 'BL_LABEL.B_ORDERDTLS_TEXT4', 'Custom Text4', 'LABEL' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Property_Value, Obj_Property )
Values
  ( NEXTVAL('S_Config'), 'TR_ORDDTLS', 1, 'BL_LABEL.B_ORDERDTLS_TEXT5', 'Custom Text5', 'LABEL' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Property_Value, Obj_Property )
Values
  ( NEXTVAL('S_Config'), 'TR_ORDDTLS', 1, 'BL_LABEL.B_ORDERDTLS_NUM1', 'Custom Num1', 'LABEL' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Property_Value, Obj_Property )
Values
  ( NEXTVAL('S_Config'), 'TR_ORDDTLS', 1, 'BL_LABEL.B_ORDERDTLS_NUM2', 'Custom Num2', 'LABEL' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Property_Value, Obj_Property )
Values
  ( NEXTVAL('S_Config'), 'TR_ORDDTLS', 1, 'BL_LABEL.B_ORDERDTLS_NUM3', 'Custom Num3', 'LABEL' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Property_Value, Obj_Property )
Values
  ( NEXTVAL('S_Config'), 'TR_ORDDTLS', 1, 'BL_LABEL.B_ORDERDTLS_NUM4', 'Custom Num4', 'LABEL' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Property_Value, Obj_Property )
Values
  ( NEXTVAL('S_Config'), 'TR_ORDDTLS', 1, 'BL_LABEL.B_ORDERDTLS_NUM5', 'Custom Num5', 'LABEL' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Property_Value, Obj_Property )
Values
  ( NEXTVAL('S_Config'), 'TR_ORDDTLS', 1, 'BL_LABEL.B_ORDERDTLS_REM1', 'Custom Rem1', 'LABEL' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Property_Value, Obj_Property )
Values
  ( NEXTVAL('S_Config'), 'TR_ORDDTLS', 1, 'BL_LABEL.B_ORDERDTLS_REM2', 'Custom Rem2', 'LABEL' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Property_Value, Obj_Property )
Values
  ( NEXTVAL('S_Config'), 'TR_ORDDTLS', 1, 'BL_LABEL.B_ORDERDTLS_REM3', 'Custom Rem3', 'LABEL' );

commit;

PROMPT *****[ Ending TR_OrderDetails.sql ]*****
