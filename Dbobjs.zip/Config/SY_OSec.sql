/* Script Name : SY_OBJSEC.sql.
   Author      : Manoj Doshi : Ingenium Computing Private Ltd, on 25th July 1999.
   Description : Config Details for ObjSec Form
*/

PROMPT *****[ Starting SY_OBJSEC.sql ]*****

DELETE FROM T_Config
WHERE  Parent_Obj = 'SY_OBJSEC'
AND    Fk_Lang_ID = 1;

		/* Form Name */

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'SY_OBJSEC', 1, 'WD_TABLE', 'LABEL', 'Object Security / T' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'SY_OBJSEC', 1, 'WD_FORM_DEFINE', 'LABEL', 'Object Security / D' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'SY_OBJSEC', 1, 'WD_FORM_INSERT', 'LABEL', 'Object Security / I' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'SY_OBJSEC', 1, 'WD_FORM_UPDATE', 'LABEL', 'Object Security / U' );

		/* Buttons */

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'SY_OBJSEC', 1, 'BL_OBJSEC.BU_QUERY', 'LABEL', 'Query Object Security Details' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'SY_OBJSEC', 1, 'BL_OBJSEC.BU_INSERT', 'LABEL', 'Insert Object Security' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'SY_OBJSEC', 1, 'BL_OBJSEC.BU_NEW', 'LABEL', 'Create New Object Security' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'SY_OBJSEC', 1, 'BL_OBJSEC.BU_UPDATE', 'LABEL', 'Update Object Security' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'SY_OBJSEC', 1, 'BL_OBJSEC.BU_DELETE', 'LABEL', 'Delete Object Security' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'SY_OBJSEC', 1, 'BL_OBJSEC.BU_FORMHELP', 'LABEL', 'Object Security Form Information' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'SY_OBJSEC', 1, 'BL_OBJSEC.BU_HELP', 'LABEL', 'Object Security Form Help' );

		/* Fields */

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'SY_OBJSEC', 1, 'BL_LABEL.B_OBJSEC_OBJPARENTNAME', 'VALUE', 'Parent Object' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'SY_OBJSEC', 1, 'BL_LABEL.B_OBJSEC_DM_OBJTYPE', 'VALUE', 'Object Type' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'SY_OBJSEC', 1, 'BL_LABEL.B_OBJSEC_OBJNAME', 'VALUE', 'Object Name' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'SY_OBJSEC', 1, 'BL_LABEL.B_OBJSEC_OBJDESC', 'VALUE', 'Object Desc' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'SY_OBJSEC', 1, 'BL_LABEL.B_OBJSEC_DISPLAY', 'VALUE', 'Display' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'SY_OBJSEC', 1, 'BL_LABEL.B_OBJSEC_INSERT', 'VALUE', 'Insert' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'SY_OBJSEC', 1, 'BL_LABEL.B_OBJSEC_UPDATE', 'VALUE', 'Update' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'SY_OBJSEC', 1, 'BL_LABEL.B_OBJSEC_UPDNULL', 'VALUE', 'UpdNull' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'SY_OBJSEC', 1, 'BL_LABEL.B_OBJSEC_DELETE', 'VALUE', 'Delete' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'SY_OBJSEC', 1, 'BL_LABEL.B_OBJSEC_SYSTEM', 'VALUE', 'System' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'SY_OBJSEC', 1, 'BL_LABEL.B_OBJSEC_GROUP', 'VALUE', 'Group' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'SY_OBJSEC', 1, 'BL_LABEL.B_OBJSEC_USER', 'VALUE', 'User' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'SY_OBJSEC', 1, 'BL_LABEL.B_OBJSEC_SELECT', 'VALUE', 'Select Form Name' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'SY_OBJSEC', 1, 'BL_LABEL.B_OBJSEC_GROUPS', 'VALUE', 'Groups' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'SY_OBJSEC', 1, 'BL_LABEL.B_OBJSEC_USERS', 'VALUE', 'Users' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'SY_OBJSEC', 1, 'BL_LABEL.B_OBJSEC_SEC_LEVEL', 'VALUE', 'Security Level' );

commit;

PROMPT *****[ Ending SY_OBJSEC.sql ]*****
