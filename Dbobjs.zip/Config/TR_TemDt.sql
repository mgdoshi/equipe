/* Script Name : TR_TemplateDetails.sql.
   Author      : Manoj Doshi : Ingenium Computing Private Ltd, on 25th July 1999
   Description : Config Details for Order Template Detials Form 
*/

PROMPT *****[ Starting TR_TEMDT.sql ]*****

DELETE FROM T_Config
WHERE  Parent_Obj = 'TR_TEMPLATEDTLS'
AND    Fk_Lang_ID = 1;

		/* Form Name */

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'TR_TEMPLATEDTLS', 1, 'WD_FORM_INSERT', 'LABEL', 'Order Template Details / I' );

		/* Buttons */

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'TR_TEMPLATEDTLS', 1, 'BL_TEMPLATEDTLS.BU_SAVE', 'LABEL', 'Save Order Template Details' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'TR_TEMPLATEDTLS', 1, 'BL_TEMPLATEDTLS.BU_MORE', 'LABEL', 'Insert More Records' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'TR_TEMPLATEDTLS', 1, 'BL_TEMPLATEDTLS.BU_INSERT', 'LABEL', 'Insert Order Template Details' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'TR_TEMPLATEDTLS', 1, 'BL_TEMPLATEDTLS.BU_UPDATE', 'LABEL', 'Update/Delete Order Template Details' );

		/* Fields */

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Property_Value, Obj_Property )
Values
  ( NEXTVAL('S_Config'), 'TR_TEMPLATEDTLS', 1, 'BL_LABEL.B_TEMPLATEDTLS_POS_NR', 'Pos No', 'LABEL' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Property_Value, Obj_Property )
Values
  ( NEXTVAL('S_Config'), 'TR_TEMPLATEDTLS', 1, 'BL_LABEL.B_TEMPLATEDTLS_FK_ITEM_ID', 'Item Name', 'LABEL' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Property_Value, Obj_Property )
Values
  ( NEXTVAL('S_Config'), 'TR_TEMPLATEDTLS', 1, 'BL_LABEL.B_TEMPLATEDTLS_FK_ITEMPACK_ID', 'Item Pack', 'LABEL' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Property_Value, Obj_Property )
Values
  ( NEXTVAL('S_Config'), 'TR_TEMPLATEDTLS', 1, 'BL_LABEL.B_TEMPLATEDTLS_DM_UNITTYPE', 'Unit Type', 'LABEL' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Property_Value, Obj_Property )
Values
  ( NEXTVAL('S_Config'), 'TR_TEMPLATEDTLS', 1, 'BL_LABEL.B_TEMPLATEDTLS_REM1', 'Cust Remark1', 'LABEL' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Property_Value, Obj_Property )
Values
  ( NEXTVAL('S_Config'), 'TR_TEMPLATEDTLS', 1, 'BL_LABEL.B_TEMPLATEDTLS_REM2', 'Cust Remark2', 'LABEL' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Property_Value, Obj_Property )
Values
  ( NEXTVAL('S_Config'), 'TR_TEMPLATEDTLS', 1, 'BL_LABEL.B_TEMPLATEDTLS_REM3', 'Cust Remark3', 'LABEL' );

commit;

PROMPT *****[ Ending TR_TEMDT.sql ]*****
