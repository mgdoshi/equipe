/* Script Name : ST_CLIENTITEM.sql.
   Author      : Manoj Doshi : Ingenium Computing Private Ltd, on 23th July 1999.
   Description : Config Details for Client Item Form
*/

PROMPT *****[ Starting ST_CLIENTITEM.sql ]*****

DELETE FROM T_Config
WHERE  Parent_Obj = 'ST_CLIENTITEM'
AND    Fk_Lang_ID = 1;

		/* Form Name */

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'ST_CLIENTITEM', 1, 'WD_QUERY', 'LABEL', 'ClientItem / Q' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'ST_CLIENTITEM', 1, 'WD_FORM_INSERT', 'LABEL', 'ClientItem / I' );

		/* Buttons */

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'ST_CLIENTITEM', 1, 'BL_CLIENTITEM.BU_NEW', 'LABEL', 'Show Client-Items' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'ST_CLIENTITEM', 1, 'BL_CLIENTITEM.BU_SAVE', 'LABEL', 'Save Client-Items' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'ST_CLIENTITEM', 1, 'BL_CLIENTITEM.BU_FORMHELP', 'LABEL', 'Client-Items Form Information' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'ST_CLIENTITEM', 1, 'BL_CLIENTITEM.BU_HELP', 'LABEL', 'Client-Items Form Help' );

		/* Fields */

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'ST_CLIENTITEM', 1, 'BL_LABEL.B_CLIENTITEM_FK_CLIENT_ID', 'VALUE', 'Client Name' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'ST_CLIENTITEM', 1, 'BL_LABEL.B_CLIENTITEM_FK_ITEM_ID', 'VALUE', 'Item Name' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'ST_CLIENTITEM', 1, 'BL_LABEL.B_CLIENTITEM_ASSIGN', 'VALUE', 'Assign' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'ST_CLIENTITEM', 1, 'BL_LABEL.B_CLIENTITEM_DEASSIGN', 'VALUE', 'DeAssign' );

commit;

PROMPT *****[ Ending ST_CLIENTITEM.sql ]*****
