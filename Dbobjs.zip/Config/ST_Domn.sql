/* Script Name : ST_DOMAIN.sql.
   Author      : Manoj Doshi : Ingenium Computing Private Ltd, on 23th July 1999.
   Description : Config Details for Domain Form
*/

PROMPT *****[ Starting ST_DOMAIN.sql ]*****

DELETE FROM T_Config
WHERE  Parent_Obj = 'ST_DOMAIN'
AND    Fk_Lang_ID = 1;

		/* Form Name */

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'ST_DOMAIN', 1, 'WD_TABLE', 'LABEL', 'Domain / T' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'ST_DOMAIN', 1, 'WD_FORM_UPDATE', 'LABEL', 'Domain / U' );

		/* Buttons */

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'ST_DOMAIN', 1, 'BL_DOMAIN.BU_NEW', 'LABEL', 'Add/Update Domain' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'ST_DOMAIN', 1, 'BL_DOMAIN.BU_SAVE', 'LABEL', 'Save Domain' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'ST_DOMAIN', 1, 'BL_DOMAIN.BU_FORMHELP', 'LABEL', 'Domain Form Information' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'ST_DOMAIN', 1, 'BL_DOMAIN.BU_HELP', 'LABEL', 'Domain Form Help' );

		/* Fields */

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'ST_DOMAIN', 1, 'BL_LABEL.B_DOMAIN_DOMAIN', 'VALUE', 'Domain' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'ST_DOMAIN', 1, 'BL_LABEL.B_DOMAIN_DOMAIN_NAME', 'VALUE', 'Domain Name' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'ST_DOMAIN', 1, 'BL_LABEL.B_DOMAIN_SEQNO', 'VALUE', 'Seq No' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'ST_DOMAIN', 1, 'BL_LABEL.B_DOMAIN_ATTRIBUTE', 'VALUE', 'Attribute' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'ST_DOMAIN', 1, 'BL_LABEL.B_DOMAIN_ATTRIB_DESC', 'VALUE', 'Attribute Description' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'ST_DOMAIN', 1, 'BL_LABEL.B_DOMAIN_LANGUAGE', 'VALUE', 'Language' );

commit;

PROMPT *****[ Ending ST_DOMAIN.sql ]*****
