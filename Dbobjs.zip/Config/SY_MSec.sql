/* Script Name : SY_MENUSEC.sql.
   Author      : Manoj Doshi : Ingenium Computing Private Ltd, on 25th July 1999.
   Description : Config Details for MenuSec Form
*/

PROMPT *****[ Starting SY_MENUSEC.sql ]*****

DELETE FROM T_Config
WHERE  Parent_Obj = 'SY_MENUSEC'
AND    Fk_Lang_ID = 1;

		/* Form Name */

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'SY_MENUSEC', 1, 'WD_TABLE', 'LABEL', 'MenuSec / T' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'SY_MENUSEC', 1, 'WD_FORM_DEFINE', 'LABEL', 'MenuSec / D' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'SY_MENUSEC', 1, 'WD_FORM_INSERT', 'LABEL', 'MenuSec / U OR I' );

		/* Buttons */

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'SY_MENUSEC', 1, 'BL_MENUSEC.BU_INSERT', 'LABEL', 'Create New Menu Security' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'SY_MENUSEC', 1, 'BL_MENUSEC.BU_NEW', 'LABEL', 'New Menu Security' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'SY_MENUSEC', 1, 'BL_MENUSEC.BU_SAVE', 'LABEL', 'Save Menu Security' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'SY_MENUSEC', 1, 'BL_MENUSEC.BU_FORMHELP', 'LABEL', 'Menu Security Form Information' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'SY_MENUSEC', 1, 'BL_MENUSEC.BU_HELP', 'LABEL', 'Menu Security Form Help' );

		/* Fields */

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'SY_MENUSEC', 1, 'BL_LABEL.B_MENUSEC_SYSTEM', 'VALUE', 'System' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'SY_MENUSEC', 1, 'BL_LABEL.B_MENUSEC_GROUP', 'VALUE', 'Group' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'SY_MENUSEC', 1, 'BL_LABEL.B_MENUSEC_GROUP_NAME', 'VALUE', 'Group Name' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'SY_MENUSEC', 1, 'BL_LABEL.B_MENUSEC_USER', 'VALUE', 'User' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'SY_MENUSEC', 1, 'BL_LABEL.B_MENUSEC_USER_NAME', 'VALUE', 'User Name' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'SY_MENUSEC', 1, 'BL_LABEL.B_MENUSEC_DM_SECLEVEL', 'VALUE', 'Security Level' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'SY_MENUSEC', 1, 'BL_LABEL.B_MENUSEC_REFID', 'VALUE', 'Reference ID' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'SY_MENUSEC', 1, 'BL_LABEL.B_MENUSEC_MEMBER', 'VALUE', 'Members' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'SY_MENUSEC', 1, 'BL_LABEL.B_MENUSEC_MENU_NAME', 'VALUE', 'Menu Name' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'SY_MENUSEC', 1, 'BL_LABEL.B_MENUSEC_ALLOW_FLAG', 'VALUE', 'Allow Flag' );

commit;

PROMPT *****[ Ending SY_MENUSEC.sql ]*****
