/* Script Name : ST_CLIENT.sql.
   Author      : Manoj Doshi : Ingenium Computing Private Ltd, on 23th July 1999.
   Description : Config Details for Client Form
*/

PROMPT *****[ Starting ST_CLIENT.sql ]*****

DELETE FROM T_Config
WHERE  Parent_Obj = 'ST_CLIENT'
AND    Fk_Lang_ID = 1;

		/* Form Name */

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'ST_CLIENT', 1, 'WD_TABLE', 'LABEL', 'Client / T' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'ST_CLIENT', 1, 'WD_FORM_INSERT', 'LABEL', 'Client / I' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'ST_CLIENT', 1, 'WD_FORM_UPDATE', 'LABEL', 'Client / U' );

		/* Buttons */

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'ST_CLIENT', 1, 'BL_CLIENT.BU_NEW', 'LABEL', 'Create New Client' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'ST_CLIENT', 1, 'BL_CLIENT.BU_UPDATE', 'LABEL', 'Update Client' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'ST_CLIENT', 1, 'BL_CLIENT.BU_DELETE', 'LABEL', 'Delete Client' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'ST_CLIENT', 1, 'BL_CLIENT.BU_SAVE', 'LABEL', 'Save Client' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'ST_CLIENT', 1, 'BL_CLIENT.BU_SAVE1', 'LABEL', 'Save Client And Create New Client' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'ST_CLIENT', 1, 'BL_CLIENT.BU_INS_ADDRESS', 'LABEL', 'Create New Address' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'ST_CLIENT', 1, 'BL_CLIENT.BU_UPD_ADDRESS', 'LABEL', 'Update/Delete Address' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'ST_CLIENT', 1, 'BL_CLIENT.BU_FORMHELP', 'LABEL', 'Client Form Information' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'ST_CLIENT', 1, 'BL_CLIENT.BU_HELP', 'LABEL', 'Client Form Help' );

		/* Fields */

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'ST_CLIENT', 1, 'BL_LABEL.B_CLIENT_CLIENT_CODE', 'VALUE', 'Client Code' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'ST_CLIENT', 1, 'BL_LABEL.B_CLIENT_CLIENT_TYPE', 'VALUE', 'Client Type' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'ST_CLIENT', 1, 'BL_LABEL.B_CLIENT_CLIENT_NAME', 'VALUE', 'Client Name' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'ST_CLIENT', 1, 'BL_LABEL.B_CLIENT_CLIENT_DESC', 'VALUE', 'Description ' );

commit;

PROMPT *****[ Ending ST_CLIENT.sql ]*****
