/* Script Name : TR_OrderTemplate.sql.
   Author      : Manoj Doshi : Ingenium Computing Private Ltd, on 26th July 1999.
   Description : Config Details for Order Template Form
*/

PROMPT *****[ Starting TR_Template.sql ]*****

DELETE FROM T_Config
WHERE  Parent_Obj = 'TR_TEMPLATE'
AND    Fk_Lang_ID = 1;

		/* Form Name */

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'TR_TEMPLATE', 1, 'WD_QUERY', 'LABEL', 'Order Template / Q' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'TR_TEMPLATE', 1, 'WD_FORM_INSERT', 'LABEL', 'Order Template / I' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'TR_TEMPLATE', 1, 'WD_FORM_UPDATE', 'LABEL', 'Order Template / U' );

		/* Buttons */

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'TR_TEMPLATE', 1, 'BL_TEMPLATE.BU_SAVE', 'LABEL', 'Save Order Template' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'TR_TEMPLATE', 1, 'BL_TEMPLATE.BU_NEW', 'LABEL', 'Create New Order Template' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'TR_TEMPLATE', 1, 'BL_TEMPLATE.BU_UPDATE', 'LABEL', 'Update Order Template' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'TR_TEMPLATE', 1, 'BL_TEMPLATE.BU_DELETE', 'LABEL', 'Delete Order Template' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'TR_TEMPLATE', 1, 'BL_TEMPLATE.BU_COPY', 'LABEL', 'Copy Template' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'TR_TEMPLATE', 1, 'BL_TEMPLATE.BU_CREATE', 'LABEL', 'Create Order From Template' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'TR_TEMPLATE', 1, 'BL_TEMPLATE.BU_FORMHELP', 'LABEL', 'Template Form Information' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'TR_TEMPLATE', 1, 'BL_TEMPLATE.BU_HELP', 'LABEL', 'Template Form Help' );

		/* Fields */

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Property_Value, Obj_Property )
Values
  ( NEXTVAL('S_Config'), 'TR_TEMPLATE', 1, 'BL_LABEL.B_TEMPLATE_DEFN', 'Select Order Template', 'LABEL' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Property_Value, Obj_Property )
Values
  ( NEXTVAL('S_Config'), 'TR_TEMPLATE', 1, 'BL_LABEL.B_TEMPLATE_TEMPLATE_NAME', 'Order Template Name', 'LABEL' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Property_Value, Obj_Property )
Values
  ( NEXTVAL('S_Config'), 'TR_TEMPLATE', 1, 'BL_LABEL.B_TEMPLATE_TEMPLATE_DESC', 'Order Template Desc', 'LABEL' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Property_Value, Obj_Property )
Values
  ( NEXTVAL('S_Config'), 'TR_TEMPLATE', 1, 'BL_LABEL.B_TEMPLATE_BILLADD_ID', 'Billing Address', 'LABEL' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Property_Value, Obj_Property )
Values
  ( NEXTVAL('S_Config'), 'TR_TEMPLATE', 1, 'BL_LABEL.B_TEMPLATE_SHIPADD_ID', 'Shipping Address', 'LABEL' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Property_Value, Obj_Property )
Values
  ( NEXTVAL('S_Config'), 'TR_TEMPLATE', 1, 'BL_LABEL.B_TEMPLATE_REM1', 'Cust Remark1', 'LABEL' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Property_Value, Obj_Property )
Values
  ( NEXTVAL('S_Config'), 'TR_TEMPLATE', 1, 'BL_LABEL.B_TEMPLATE_REM2', 'Cust Remark2', 'LABEL' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Property_Value, Obj_Property )
Values
  ( NEXTVAL('S_Config'), 'TR_TEMPLATE', 1, 'BL_LABEL.B_TEMPLATE_REM3', 'Cust Remark3', 'LABEL' );

commit;

PROMPT *****[ Ending TR_Template.sql ]*****
