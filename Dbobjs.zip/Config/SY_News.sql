/* Script Name : SY_NEWS.sql.
   Author      : Manoj Doshi : Ingenium Computing Private Ltd, on 25th July 1999.
   Description : Config Details for News Form
*/

PROMPT *****[ Starting SY_NEWS.sql ]*****

DELETE FROM T_Config
WHERE  Parent_Obj = 'SY_NEWS'
AND    Fk_Lang_ID = 1;

		/* Form Name */

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'SY_NEWS', 1, 'WD_TABLE', 'LABEL', 'News / T' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'SY_NEWS', 1, 'WD_FORM_INSERT', 'LABEL', 'News / I' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'SY_NEWS', 1, 'WD_FORM_UPDATE', 'LABEL', 'News / U' );

		/* Buttons */

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'SY_NEWS', 1, 'BL_NEWS.BU_NEW', 'LABEL', 'Create New News' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'SY_NEWS', 1, 'BL_NEWS.BU_NEXT', 'LABEL', 'Next Records' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'SY_NEWS', 1, 'BL_NEWS.BU_PREV', 'LABEL', 'Previous Records' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
 ( NEXTVAL('S_Config'), 'SY_NEWS', 1, 'BL_NEWS.BU_UPDATE', 'LABEL', 'UPDATE News' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
 ( NEXTVAL('S_Config'), 'SY_NEWS', 1, 'BL_NEWS.BU_DELETE', 'LABEL', 'Delete News' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'SY_NEWS', 1, 'BL_NEWS.BU_SAVE', 'LABEL', 'Save News' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'SY_NEWS', 1, 'BL_NEWS.BU_SAVE1', 'LABEL', 'Save News And Create New News' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'SY_NEWS', 1, 'BL_NEWS.BU_FORMHELP', 'LABEL', 'News Form Information' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'SY_NEWS', 1, 'BL_NEWS.BU_HELP', 'LABEL', 'News Form Help' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'SY_NEWS', 1, 'BL_NEWS.BU_HELP1', 'LABEL', 'News Room Form Help' );

		/* Fields */

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'SY_NEWS', 1, 'BL_LABEL.B_NEWS_CAPTION', 'VALUE', 'Caption' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'SY_NEWS', 1, 'BL_LABEL.B_NEWS_NEWS_DATE', 'VALUE', 'Date' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'SY_NEWS', 1, 'BL_LABEL.B_NEWS_MATTER', 'VALUE', 'Matter' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'SY_NEWS', 1, 'BL_LABEL.B_NEWS_ORIGINATOR', 'VALUE', 'Orginator' );

commit;

PROMPT *****[ Ending SY_NEWS.sql ]*****
