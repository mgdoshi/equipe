/* Script Name : TR_Report.sql.
   Author      : Manoj Doshi : Ingenium Computing Private Ltd, on 26th July 1999.
   Description : Config Details for Order Form
*/

PROMPT *****[ Starting TR_REPORT.sql ]*****

DELETE FROM T_Config
WHERE  Parent_Obj = 'TR_REPORT'
AND    Fk_Lang_ID = 1;

		/* Form Name */

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'TR_REPORT', 1, 'WD_QUERY', 'LABEL', 'Client Wise Report / Q' );

		/* Buttons */

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'TR_REPORT', 1, 'BL_REPORT.BU_LIST', 'LABEL', 'Client Wise Report' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'TR_REPORT', 1, 'BL_REPORT.BU_FORMHELP', 'LABEL', 'Client Wise Report Form Information' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'TR_REPORT', 1, 'BL_REPORT.BU_HELP', 'LABEL', 'Client Wise Report Form Help' );

		/* Fields */

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Property_Value, Obj_Property )
Values
  ( NEXTVAL('S_Config'), 'TR_REPORT', 1, 'BL_LABEL.B_REPORT_CLIENT_NAME', 'Client Name', 'LABEL' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Property_Value, Obj_Property )
Values
  ( NEXTVAL('S_Config'), 'TR_REPORT', 1, 'BL_LABEL.B_REPORT_REPORT', 'Report', 'LABEL' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Property_Value, Obj_Property )
Values
  ( NEXTVAL('S_Config'), 'TR_REPORT', 1, 'BL_LABEL.B_REPORT_QUART', 'Quarterly', 'LABEL' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Property_Value, Obj_Property )
Values
  ( NEXTVAL('S_Config'), 'TR_REPORT', 1, 'BL_LABEL.B_REPORT_MONTH', 'Monthly', 'LABEL' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Property_Value, Obj_Property )
Values
  ( NEXTVAL('S_Config'), 'TR_REPORT', 1, 'BL_LABEL.B_REPORT_ITEM_NAME', 'Item Name', 'LABEL' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Property_Value, Obj_Property )
Values
  ( NEXTVAL('S_Config'), 'TR_REPORT', 1, 'BL_LABEL.B_REPORT_ITEM_CLASS', 'Item Class', 'LABEL' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Property_Value, Obj_Property )
Values
  ( NEXTVAL('S_Config'), 'TR_REPORT', 1, 'BL_LABEL.B_REPORT_ITEM_GROUP', 'Item Group', 'LABEL' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Property_Value, Obj_Property )
Values
  ( NEXTVAL('S_Config'), 'TR_REPORT', 1, 'BL_LABEL.B_REPORT_ITEM_COSTCENTRE', 'CostCentre Name', 'LABEL' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Property_Value, Obj_Property )
Values
  ( NEXTVAL('S_Config'), 'TR_REPORT', 1, 'BL_LABEL.B_REPORT_DATE_FROM', 'Date From', 'LABEL' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Property_Value, Obj_Property )
Values
  ( NEXTVAL('S_Config'), 'TR_REPORT', 1, 'BL_LABEL.B_REPORT_DATE_TO', 'Date To', 'LABEL' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Property_Value, Obj_Property )
Values
  ( NEXTVAL('S_Config'), 'TR_REPORT', 1, 'BL_LABEL.B_REPORT_ORDER_STATUS', 'Order Status', 'LABEL' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Property_Value, Obj_Property )
Values
  ( NEXTVAL('S_Config'), 'TR_REPORT', 1, 'BL_LABEL.B_REPORT_CLIENTWISE', 'Report of Client', 'LABEL' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Property_Value, Obj_Property )
Values
  ( NEXTVAL('S_Config'), 'TR_REPORT', 1, 'BL_LABEL.B_REPORT_ITEM', 'Item', 'LABEL' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Property_Value, Obj_Property )
Values
  ( NEXTVAL('S_Config'), 'TR_REPORT', 1, 'BL_LABEL.B_REPORT_UNIT', 'Unit', 'LABEL' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Property_Value, Obj_Property )
Values
  ( NEXTVAL('S_Config'), 'TR_REPORT', 1, 'BL_LABEL.B_REPORT_QUART1', 'JAN-MAR', 'LABEL' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Property_Value, Obj_Property )
Values
  ( NEXTVAL('S_Config'), 'TR_REPORT', 1, 'BL_LABEL.B_REPORT_QUART2', 'APR-JUN', 'LABEL' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Property_Value, Obj_Property )
Values
  ( NEXTVAL('S_Config'), 'TR_REPORT', 1, 'BL_LABEL.B_REPORT_QUART3', 'JUL-SEP', 'LABEL' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Property_Value, Obj_Property )
Values
  ( NEXTVAL('S_Config'), 'TR_REPORT', 1, 'BL_LABEL.B_REPORT_QUART4', 'OCT-DEC', 'LABEL' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Property_Value, Obj_Property )
Values
  ( NEXTVAL('S_Config'), 'TR_REPORT', 1, 'BL_LABEL.B_REPORT_JAN', 'JAN', 'LABEL' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Property_Value, Obj_Property )
Values
  ( NEXTVAL('S_Config'), 'TR_REPORT', 1, 'BL_LABEL.B_REPORT_FEB', 'FEB', 'LABEL' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Property_Value, Obj_Property )
Values
  ( NEXTVAL('S_Config'), 'TR_REPORT', 1, 'BL_LABEL.B_REPORT_MAR', 'MAR', 'LABEL' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Property_Value, Obj_Property )
Values
  ( NEXTVAL('S_Config'), 'TR_REPORT', 1, 'BL_LABEL.B_REPORT_APR', 'APR', 'LABEL' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Property_Value, Obj_Property )
Values
  ( NEXTVAL('S_Config'), 'TR_REPORT', 1, 'BL_LABEL.B_REPORT_MAY', 'MAY', 'LABEL' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Property_Value, Obj_Property )
Values
  ( NEXTVAL('S_Config'), 'TR_REPORT', 1, 'BL_LABEL.B_REPORT_JUN', 'JUN', 'LABEL' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Property_Value, Obj_Property )
Values
  ( NEXTVAL('S_Config'), 'TR_REPORT', 1, 'BL_LABEL.B_REPORT_JUL', 'JUL', 'LABEL' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Property_Value, Obj_Property )
Values
  ( NEXTVAL('S_Config'), 'TR_REPORT', 1, 'BL_LABEL.B_REPORT_AUG', 'AUG', 'LABEL' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Property_Value, Obj_Property )
Values
  ( NEXTVAL('S_Config'), 'TR_REPORT', 1, 'BL_LABEL.B_REPORT_SEP', 'SEP', 'LABEL' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Property_Value, Obj_Property )
Values
  ( NEXTVAL('S_Config'), 'TR_REPORT', 1, 'BL_LABEL.B_REPORT_OCT', 'OCT', 'LABEL' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Property_Value, Obj_Property )
Values
  ( NEXTVAL('S_Config'), 'TR_REPORT', 1, 'BL_LABEL.B_REPORT_NOV', 'NOV', 'LABEL' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Property_Value, Obj_Property )
Values
  ( NEXTVAL('S_Config'), 'TR_REPORT', 1, 'BL_LABEL.B_REPORT_DEC', 'DEC', 'LABEL' );

commit;

PROMPT *****[ Ending TR_ORDER.sql ]*****
