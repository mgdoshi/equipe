/* Script Name : TR_OrderDetails.sql.
   Author      : Manoj Doshi : Ingenium Computing Private Ltd, on 10th July 1999.
   Description : Config Details for Order Form
*/

PROMPT *****[ Starting TR_Order.sql ]*****

DELETE FROM T_Config
WHERE  Parent_Obj = 'TR_ORDER'
AND    Fk_Lang_ID = 1;

		/* Form Name */

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'TR_ORDER', 1, 'WD_ORDER', 'LABEL', 'Order Entry' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'TR_ORDER', 1, 'WD_QUERY', 'LABEL', 'Order / Q' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'TR_ORDER', 1, 'WD_TABLE', 'LABEL', 'Order / T' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'TR_ORDER', 1, 'WD_FORM_QUERY', 'LABEL', 'Order Report / Q' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'TR_ORDER', 1, 'WD_FORM_TABLE', 'LABEL', 'Order Report/ T' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'TR_ORDER', 1, 'WD_FORM_LIST', 'LABEL', 'Order List' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'TR_ORDER', 1, 'WD_FORM_DETAILS', 'LABEL', 'Order Details' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'TR_ORDER', 1, 'WD_FORM_QUERY1', 'LABEL', 'Pending Order Report / Q' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'TR_ORDER', 1, 'WD_FORM_TABLE1', 'LABEL', 'Pending Order Report/ T' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'TR_ORDER', 1, 'WD_FORM_LIST1', 'LABEL', 'Pending Order List' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'TR_ORDER', 1, 'WD_FORM_DETAILS1', 'LABEL', 'Pending Order Details' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'TR_ORDER', 1, 'WD_FORM_QUERY2', 'LABEL', 'Change Order Status / Q' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'TR_ORDER', 1, 'WD_FORM_TABLE2', 'LABEL', 'Change Order Status / T' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'TR_ORDER', 1, 'WD_FORM_LIST2', 'LABEL', 'Change Order Status List' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'TR_ORDER', 1, 'WD_FORM_DETAILS2', 'LABEL', 'Change Order Status Details' );

		/* Buttons */

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'TR_ORDER', 1, 'BL_ORDER.BU_SAVE', 'LABEL', 'Save Order Entry' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'TR_ORDER', 1, 'BL_ORDER.BU_ORDFROMTEMPL', 'LABEL', 'Order From Template' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'TR_ORDER', 1, 'BL_ORDER.BU_ORDFORTEMPL', 'LABEL', 'Show Order Form' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'TR_ORDER', 1, 'BL_ORDER.BU_QUERY', 'LABEL', 'Order Query Details' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'TR_ORDER', 1, 'BL_ORDER.BU_DELETE', 'LABEL', 'Delete Order' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'TR_ORDER', 1, 'BL_ORDER.BU_QUERY_LIST', 'LABEL', 'Show Order Report List' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'TR_ORDER', 1, 'BL_ORDER.BU_QUERY_REPORT', 'LABEL', 'Show Order Report Table' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'TR_ORDER', 1, 'BL_ORDER.BU_QUERY_LIST1', 'LABEL', 'Show Pending Order Report List' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'TR_ORDER', 1, 'BL_ORDER.BU_QUERY_REPORT1', 'LABEL', 'Show Pending Order Report Table' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'TR_ORDER', 1, 'BL_ORDER.BU_QUERY_STATUS', 'LABEL', 'Show Change Order Status List' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'TR_ORDER', 1, 'BL_ORDER.BU_QUERY_REPORT2', 'LABEL', 'Show Change Order Status Table' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'TR_ORDER', 1, 'BL_ORDER.BU_FORMHELP', 'LABEL', 'Order Form Information' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'TR_ORDER', 1, 'BL_ORDER.BU_HELP', 'LABEL', 'Order Form Help' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'TR_ORDER', 1, 'BL_ORDREP.BU_FORMHELP', 'LABEL', 'Order Report Form Information' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'TR_ORDER', 1, 'BL_ORDREP.BU_HELP', 'LABEL', 'Order Report Form Help' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'TR_ORDER', 1, 'BL_PENDREP.BU_FORMHELP', 'LABEL', 'Pending Order Report Form Information' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'TR_ORDER', 1, 'BL_PENDREP.BU_HELP', 'LABEL', 'Pending Order Report Form Help' );

		/* Fields */

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Property_Value, Obj_Property )
Values
  ( NEXTVAL('S_Config'), 'TR_ORDER', 1, 'BL_LABEL.B_ORDER_DM_ORDSTAT', 'Order Status', 'LABEL' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Property_Value, Obj_Property )
Values
  ( NEXTVAL('S_Config'), 'TR_ORDER', 1, 'BL_LABEL.B_ORDER_SHOPCART', 'Select Shopping Cart', 'LABEL' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Property_Value, Obj_Property )
Values
  ( NEXTVAL('S_Config'), 'TR_ORDER', 1, 'BL_LABEL.B_ORDER_ORDER_ID', 'Order ID', 'LABEL' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Property_Value, Obj_Property )
Values
  ( NEXTVAL('S_Config'), 'TR_ORDER', 1, 'BL_LABEL.B_ORDER_ORDER_NR', 'Order No', 'LABEL' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Property_Value, Obj_Property )
Values
  ( NEXTVAL('S_Config'), 'TR_ORDER', 1, 'BL_LABEL.B_ORDER_ORDER_DT', 'Order Date', 'LABEL' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Property_Value, Obj_Property )
Values
  ( NEXTVAL('S_Config'), 'TR_ORDER', 1, 'BL_LABEL.B_ORDER_EXPDEL_DT', 'Exp Del Date', 'LABEL' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Property_Value, Obj_Property )
Values
  ( NEXTVAL('S_Config'), 'TR_ORDER', 1, 'BL_LABEL.B_ORDER_BILLADD_ID', 'Billing Addr', 'LABEL' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Property_Value, Obj_Property )
Values
  ( NEXTVAL('S_Config'), 'TR_ORDER', 1, 'BL_LABEL.B_ORDER_SHIPADD_ID', 'Shipping Addr', 'LABEL' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Property_Value, Obj_Property )
Values
  ( NEXTVAL('S_Config'), 'TR_ORDER', 1, 'BL_LABEL.B_ORDER_DT1', 'Custom Date1', 'LABEL' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Property_Value, Obj_Property )
Values
  ( NEXTVAL('S_Config'), 'TR_ORDER', 1, 'BL_LABEL.B_ORDER_DT2', 'Custom Date2', 'LABEL' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Property_Value, Obj_Property )
Values
  ( NEXTVAL('S_Config'), 'TR_ORDER', 1, 'BL_LABEL.B_ORDER_DT3', 'Custom Date3', 'LABEL' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Property_Value, Obj_Property )
Values
  ( NEXTVAL('S_Config'), 'TR_ORDER', 1, 'BL_LABEL.B_ORDER_CHARGE1', 'Custom Charge1', 'LABEL' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Property_Value, Obj_Property )
Values
  ( NEXTVAL('S_Config'), 'TR_ORDER', 1, 'BL_LABEL.B_ORDER_CHARGE2', 'Custom Charge2', 'LABEL' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Property_Value, Obj_Property )
Values
  ( NEXTVAL('S_Config'), 'TR_ORDER', 1, 'BL_LABEL.B_ORDER_CHARGE3', 'Custom Charge3', 'LABEL' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Property_Value, Obj_Property )
Values
  ( NEXTVAL('S_Config'), 'TR_ORDER', 1, 'BL_LABEL.B_ORDER_CHARGE4', 'Custom Charge4', 'LABEL' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Property_Value, Obj_Property )
Values
  ( NEXTVAL('S_Config'), 'TR_ORDER', 1, 'BL_LABEL.B_ORDER_NUM1', 'Custom Num1', 'LABEL' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Property_Value, Obj_Property )
Values
  ( NEXTVAL('S_Config'), 'TR_ORDER', 1, 'BL_LABEL.B_ORDER_NUM2', 'Custom Num2', 'LABEL' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Property_Value, Obj_Property )
Values
  ( NEXTVAL('S_Config'), 'TR_ORDER', 1, 'BL_LABEL.B_ORDER_NUM3', 'Custom Num3', 'LABEL' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Property_Value, Obj_Property )
Values
  ( NEXTVAL('S_Config'), 'TR_ORDER', 1, 'BL_LABEL.B_ORDER_NUM4', 'Custom Num4', 'LABEL' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Property_Value, Obj_Property )
Values
  ( NEXTVAL('S_Config'), 'TR_ORDER', 1, 'BL_LABEL.B_ORDER_NUM5', 'Custom Num5', 'LABEL' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Property_Value, Obj_Property )
Values
  ( NEXTVAL('S_Config'), 'TR_ORDER', 1, 'BL_LABEL.B_ORDER_TEXT1', 'Custom Text1', 'LABEL' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Property_Value, Obj_Property )
Values
  ( NEXTVAL('S_Config'), 'TR_ORDER', 1, 'BL_LABEL.B_ORDER_TEXT2', 'Custom Text2', 'LABEL' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Property_Value, Obj_Property )
Values
  ( NEXTVAL('S_Config'), 'TR_ORDER', 1, 'BL_LABEL.B_ORDER_TEXT3', 'Custom Text3', 'LABEL' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Property_Value, Obj_Property )
Values
  ( NEXTVAL('S_Config'), 'TR_ORDER', 1, 'BL_LABEL.B_ORDER_TEXT4', 'Custom Text4', 'LABEL' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Property_Value, Obj_Property )
Values
  ( NEXTVAL('S_Config'), 'TR_ORDER', 1, 'BL_LABEL.B_ORDER_TEXT5', 'Custom Text5', 'LABEL' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Property_Value, Obj_Property )
Values
  ( NEXTVAL('S_Config'), 'TR_ORDER', 1, 'BL_LABEL.B_ORDER_REM1', 'Custom Rem1', 'LABEL' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Property_Value, Obj_Property )
Values
  ( NEXTVAL('S_Config'), 'TR_ORDER', 1, 'BL_LABEL.B_ORDER_REM2', 'Custom Rem2', 'LABEL' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Property_Value, Obj_Property )
Values
  ( NEXTVAL('S_Config'), 'TR_ORDER', 1, 'BL_LABEL.B_ORDER_REM3', 'Custom Rem3', 'LABEL' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Property_Value, Obj_Property )
Values
  ( NEXTVAL('S_Config'), 'TR_ORDER', 1, 'BL_LABEL.B_ORDER_CLIENT_NAME', 'Client Name', 'LABEL' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Property_Value, Obj_Property )
Values
  ( NEXTVAL('S_Config'), 'TR_ORDER', 1, 'BL_LABEL.B_ORDER_ORDER_NR_FROM', 'Order No From', 'LABEL' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Property_Value, Obj_Property )
Values
  ( NEXTVAL('S_Config'), 'TR_ORDER', 1, 'BL_LABEL.B_ORDER_ORDER_NR_TO', 'Order No To', 'LABEL' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Property_Value, Obj_Property )
Values
  ( NEXTVAL('S_Config'), 'TR_ORDER', 1, 'BL_LABEL.B_ORDER_ORDER_DT_FROM', 'Order Date From', 'LABEL' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Property_Value, Obj_Property )
Values
  ( NEXTVAL('S_Config'), 'TR_ORDER', 1, 'BL_LABEL.B_ORDER_ORDER_DT_TO', 'Order Date To', 'LABEL' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Property_Value, Obj_Property )
Values
  ( NEXTVAL('S_Config'), 'TR_ORDER', 1, 'BL_LABEL.B_ORDER_EXPDEL_DT_FROM', 'Expected Delivery Date From', 'LABEL' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Property_Value, Obj_Property )
Values
  ( NEXTVAL('S_Config'), 'TR_ORDER', 1, 'BL_LABEL.B_ORDER_EXPDEL_DT_TO', 'Expected Delivery Date To', 'LABEL' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Property_Value, Obj_Property )
Values
  ( NEXTVAL('S_Config'), 'TR_ORDER', 1, 'BL_LABEL.B_ORDER_TEMPLATE', 'Select Order Template', 'LABEL' );

commit;

PROMPT *****[ Ending TR_ORDER.sql ]*****
