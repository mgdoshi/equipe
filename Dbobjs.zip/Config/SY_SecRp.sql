/* Script Name : SY_SecRp.sql.
   Author      : Manoj Doshi : Ingenium Computing Private Ltd, on 9th July 1999.
   Description : Config Details for Security Report Form
*/

PROMPT *****[ Starting SY_SECREP.sql ]*****

DELETE FROM T_Config
WHERE  Parent_Obj = 'SY_SECREP'
AND    Fk_Lang_ID = 1;

		/* Form Name */

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'SY_SECREP', 1, 'WD_QUERY', 'LABEL', 'Security Report / Q' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'SY_SECREP', 1, 'WD_LIST', 'LABEL', 'Security Report / L' );

		/* Buttons */

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'SY_SECREP', 1, 'BL_SECREP.BU_QUERY', 'LABEL', 'Query Security Report' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'SY_SECREP', 1, 'BL_SECREP.BU_FORMHELP', 'LABEL', 'Security Form Information' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'SY_SECREP', 1, 'BL_SECREP.BU_HELP', 'LABEL', 'Security Form Help' );

		/* Fields */

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Property_Value, Obj_Property )
Values
  ( NEXTVAL('S_Config'), 'SY_SECREP', 1, 'BL_LABEL.B_SECREP_SELECT_CLIENT_NAME', 'Select Client', 'LABEL' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Property_Value, Obj_Property )
Values
  ( NEXTVAL('S_Config'), 'SY_SECREP', 1, 'BL_LABEL.B_SECREP_SELECT_USER_NAME', 'Select User', 'LABEL' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Property_Value, Obj_Property )
Values
  ( NEXTVAL('S_Config'), 'SY_SECREP', 1, 'BL_LABEL.B_SECREP_CLIENT_NAME', 'Client Name', 'LABEL' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Property_Value, Obj_Property )
Values
  ( NEXTVAL('S_Config'), 'SY_SECREP', 1, 'BL_LABEL.B_SECREP_USER_NAME', 'User Name', 'LABEL' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Property_Value, Obj_Property )
Values
  ( NEXTVAL('S_Config'), 'SY_SECREP', 1, 'BL_LABEL.B_SECREP_EMPLOYEE_NAME', 'Employee Name', 'LABEL' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Property_Value, Obj_Property )
Values
  ( NEXTVAL('S_Config'), 'SY_SECREP', 1, 'BL_LABEL.B_SECREP_EMPLOYEE_FUNCT', 'Functions Assigned', 'LABEL' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Property_Value, Obj_Property )
Values
  ( NEXTVAL('S_Config'), 'SY_SECREP', 1, 'BL_LABEL.B_SECREP_RECSEC_NAME', 'Record Security Name', 'LABEL' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Property_Value, Obj_Property )
Values
  ( NEXTVAL('S_Config'), 'SY_SECREP', 1, 'BL_LABEL.B_SECREP_RECSEC_ASSGN', 'Record Security Assigned', 'LABEL' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Property_Value, Obj_Property )
Values
  ( NEXTVAL('S_Config'), 'SY_SECREP', 1, 'BL_LABEL.B_SECREP_CLIENT_ASSGN', 'Clients Assigned', 'LABEL' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Property_Value, Obj_Property )
Values
  ( NEXTVAL('S_Config'), 'SY_SECREP', 1, 'BL_LABEL.B_SECREP_EMPLOYEE_ASSGN', 'Employees Assigned', 'LABEL' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Property_Value, Obj_Property )
Values
  ( NEXTVAL('S_Config'), 'SY_SECREP', 1, 'BL_LABEL.B_SECREP_ITEM_ASSGN', 'Items Assigned', 'LABEL' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Property_Value, Obj_Property )
Values
  ( NEXTVAL('S_Config'), 'SY_SECREP', 1, 'BL_LABEL.B_SECREP_SYSTEM', 'System Security Report', 'LABEL' );

commit;

PROMPT *****[ Ending TR_ORDER.sql ]*****
