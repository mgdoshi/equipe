/* Script Name : ST_ADDRESS.sql.
   Author      : Manoj Doshi : Ingenium Computing Private Ltd, on 23th July 1999.
   Description : Config Details for Address Form
*/

/* PROMPT *****[ Starting ST_ADDRESS.sql ]***** */

DELETE FROM T_Config
WHERE  Parent_Obj = 'ST_ADDRESS'
AND    Fk_Lang_ID = 1;

		/* Form Name */

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'ST_ADDRESS', 1, 'WD_FORM_DEFINE', 'LABEL', 'Address / D' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'ST_ADDRESS', 1, 'WD_TABLE', 'LABEL', 'Address / T' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'ST_ADDRESS', 1, 'WD_FORM_INSERT', 'LABEL', 'Address / I' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'ST_ADDRESS', 1, 'WD_FORM_UPDATE', 'LABEL', 'Address / U' );

		/* Buttons */

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'ST_ADDRESS', 1, 'BL_ADDRESS.BU_MAINTAIN', 'LABEL', 'Maintain Address' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'ST_ADDRESS', 1, 'BL_ADDRESS.BU_NEW', 'LABEL', 'Create New Address' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'ST_ADDRESS', 1, 'BL_ADDRESS.BU_UPDATE', 'LABEL', 'Update Address' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
 ( NEXTVAL('S_Config'), 'ST_ADDRESS', 1, 'BL_ADDRESS.BU_DELETE', 'LABEL', 'Delete Address' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'ST_ADDRESS', 1, 'BL_ADDRESS.BU_SAVE', 'LABEL', 'Save Address' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'ST_ADDRESS', 1, 'BL_ADDRESS.BU_SAVE1', 'LABEL', 'Save Address And Create New Address' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'ST_ADDRESS', 1, 'BL_ADDRESS.BU_FORMHELP', 'LABEL', 'Address Form Information' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'ST_ADDRESS', 1, 'BL_ADDRESS.BU_HELP', 'LABEL', 'Address Form Help' );

		/* Fields */

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'ST_ADDRESS', 1, 'BL_LABEL.B_ADDRESS_CLIENT', 'VALUE', 'Client' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'ST_ADDRESS', 1, 'BL_LABEL.B_ADDRESS_BRANCH', 'VALUE', 'Branch' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'ST_ADDRESS', 1, 'BL_LABEL.B_ADDRESS_EMPLOYEE', 'VALUE', 'Employee' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'ST_ADDRESS', 1, 'BL_LABEL.B_ADDRESS', 'VALUE', 'Address of' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'ST_ADDRESS', 1, 'BL_LABEL.B_ADDRESS_DM_ADDTYPE', 'VALUE', 'Address Type' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'ST_ADDRESS', 1, 'BL_LABEL.B_ADDRESS_ADDRESS', 'VALUE', 'Address' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'ST_ADDRESS', 1, 'BL_LABEL.B_ADDRESS_CITY', 'VALUE', 'City' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'ST_ADDRESS', 1, 'BL_LABEL.B_ADDRESS_STATE', 'VALUE', 'State' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'ST_ADDRESS', 1, 'BL_LABEL.B_ADDRESS_PIN', 'VALUE', 'Pin' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'ST_ADDRESS', 1, 'BL_LABEL.B_ADDRESS_TELNR', 'VALUE', 'Tele No' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'ST_ADDRESS', 1, 'BL_LABEL.B_ADDRESS_FAXNO', 'VALUE', 'Fax No' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'ST_ADDRESS', 1, 'BL_LABEL.B_ADDRESS_TELEXNR', 'VALUE', 'Telex No' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'ST_ADDRESS', 1, 'BL_LABEL.B_ADDRESS_MAILID', 'VALUE', 'Mail ID' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'ST_ADDRESS', 1, 'BL_LABEL.B_ADDRESS_CONTACT_PERSON', 'VALUE', 'Contact Person' );

commit;

/* PROMPT *****[ Ending ST_ADDRESS.sql ]***** */
