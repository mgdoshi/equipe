/* Script Name : ST_ITEMGROUP.sql.
   Author      : Manoj Doshi : Ingenium Computing Private Ltd, on 23th July 1999.
   Description : Config Details for ItemGroup Form
*/

PROMPT *****[ Starting ST_ITEMGROUP.sql ]*****

DELETE FROM T_Config
WHERE  Parent_Obj = 'ST_ITEMGROUP'
AND    Fk_Lang_ID = 1;

		/* Form Name */

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'ST_ITEMGROUP', 1, 'WD_TABLE', 'LABEL', 'ItemGroup / T' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'ST_ITEMGROUP', 1, 'WD_FORM_INSERT', 'LABEL', 'ItemGroup / I' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'ST_ITEMGROUP', 1, 'WD_FORM_UPDATE', 'LABEL', 'ItemGroup / U' );

		/* Buttons */

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'ST_ITEMGROUP', 1, 'BL_ITEMGROUP.BU_NEW', 'LABEL', 'Create New ItemGroup' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'ST_ITEMGROUP', 1, 'BL_ITEMGROUP.BU_UPDATE', 'LABEL', 'Update ItemGroup' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
 ( NEXTVAL('S_Config'), 'ST_ITEMGROUP', 1, 'BL_ITEMGROUP.BU_DELETE', 'LABEL', 'Delete ItemGroup' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'ST_ITEMGROUP', 1, 'BL_ITEMGROUP.BU_SAVE', 'LABEL', 'Save ItemGroup' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'ST_ITEMGROUP', 1, 'BL_ITEMGROUP.BU_SAVE1', 'LABEL', 'Save ItemGroup And Create New ItemGroup' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'ST_ITEMGROUP', 1, 'BL_ITEMGROUP.BU_FORMHELP', 'LABEL', 'ItemGroup Form Information' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'ST_ITEMGROUP', 1, 'BL_ITEMGROUP.BU_HELP', 'LABEL', 'ItemGroup Form Help' );

		/* Fields */

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'ST_ITEMGROUP', 1, 'BL_LABEL.B_ITEMGROUP_ITEMGROUP_NAME', 'VALUE', 'ItemGroup Name' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'ST_ITEMGROUP', 1, 'BL_LABEL.B_ITEMGROUP_ITEMGROUP_DESC', 'VALUE', 'Description' );

commit;

PROMPT *****[ Ending ST_ITEMGROUP.sql ]*****
