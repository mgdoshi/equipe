/* Script Name : ST_ITEMCLASS.sql.
   Author      : Manoj Doshi : Ingenium Computing Private Ltd, on 23th July 1999.
   Description : Config Details for ItemClass Form
*/

PROMPT *****[ Starting ST_ITEMCLASS.sql ]*****

DELETE FROM T_Config
WHERE  Parent_Obj = 'ST_ITEMCLASS'
AND    Fk_Lang_ID = 1;

		/* Form Name */

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'ST_ITEMCLASS', 1, 'WD_TABLE', 'LABEL', 'ItemClass / T' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'ST_ITEMCLASS', 1, 'WD_FORM_INSERT', 'LABEL', 'ItemClass / I' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'ST_ITEMCLASS', 1, 'WD_FORM_UPDATE', 'LABEL', 'ItemClass / U' );

		/* Buttons */

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'ST_ITEMCLASS', 1, 'BL_ITEMCLASS.BU_NEW', 'LABEL', 'Create New ItemClass' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'ST_ITEMCLASS', 1, 'BL_ITEMCLASS.BU_UPDATE', 'LABEL', 'Update ItemClass' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
 ( NEXTVAL('S_Config'), 'ST_ITEMCLASS', 1, 'BL_ITEMCLASS.BU_DELETE', 'LABEL', 'Delete ItemClass' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'ST_ITEMCLASS', 1, 'BL_ITEMCLASS.BU_SAVE', 'LABEL', 'Save ItemClass' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'ST_ITEMCLASS', 1, 'BL_ITEMCLASS.BU_SAVE1', 'LABEL', 'Save ItemClass And Create New ItemClass' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'ST_ITEMCLASS', 1, 'BL_ITEMCLASS.BU_FORMHELP', 'LABEL', 'ItemClass Form Information' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'ST_ITEMCLASS', 1, 'BL_ITEMCLASS.BU_HELP', 'LABEL', 'ItemClass Form Help' );

		/* Fields */

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'ST_ITEMCLASS', 1, 'BL_LABEL.B_ITEMCLASS_ITEMCLASS_NAME', 'VALUE', 'ItemClass Name' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'ST_ITEMCLASS', 1, 'BL_LABEL.B_ITEMCLASS_ITEMCLASS_DESC', 'VALUE', 'Description' );

commit;

PROMPT *****[ Ending ST_ITEMCLASS.sql ]*****
