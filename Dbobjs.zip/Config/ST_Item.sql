/* Script Name : ST_ITEM.sql.
   Author      : Manoj Doshi : Ingenium Computing Private Ltd, on 23th July 1999.
   Description : Config Details for Item Form
*/

PROMPT *****[ Starting ST_ITEM.sql ]*****

DELETE FROM T_Config
WHERE  Parent_Obj = 'ST_ITEM'
AND    Fk_Lang_ID = 1;

		/* Form Name */

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'ST_ITEM', 1, 'WD_QUERY', 'LABEL', 'Item / Q' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'ST_ITEM', 1, 'WD_TABLE', 'LABEL', 'Item / T' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'ST_ITEM', 1, 'WD_FORM_INSERT', 'LABEL', 'Item / I' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'ST_ITEM', 1, 'WD_FORM_UPDATE', 'LABEL', 'Item / U' );

		/* Buttons */

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'ST_ITEM', 1, 'BL_ITEM.BU_QUERY', 'LABEL', 'Query Item' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'ST_ITEM', 1, 'BL_ITEM.BU_NEW', 'LABEL', 'Create New Item' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'ST_ITEM', 1, 'BL_ITEM.BU_UPDATE', 'LABEL', 'Update Item' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
 ( NEXTVAL('S_Config'), 'ST_ITEM', 1, 'BL_ITEM.BU_DELETE', 'LABEL', 'Delete Item' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'ST_ITEM', 1, 'BL_ITEM.BU_SAVE', 'LABEL', 'Save Item' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'ST_ITEM', 1, 'BL_ITEM.BU_SAVE1', 'LABEL', 'Save Item And Create New Item' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'ST_ITEM', 1, 'BL_ITEM.BU_ASSIGN', 'LABEL', 'Assign Item Rates' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'ST_ITEM', 1, 'BL_ITEM.BU_ASSIGN1', 'LABEL', 'Assign Clients to Item' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'ST_ITEM', 1, 'BL_ITEM.BU_ASSIGN2', 'LABEL', 'Update/Delete Item Rates' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'ST_ITEM', 1, 'BL_ITEM.BU_ASSIGN3', 'LABEL', 'Assign Users to Item' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'ST_ITEM', 1, 'BL_ITEM.BU_FORMHELP', 'LABEL', 'Item Form Information' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'ST_ITEM', 1, 'BL_ITEM.BU_HELP', 'LABEL', 'Item Form Help' );

		/* Fields */

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'ST_ITEM', 1, 'BL_LABEL.B_ITEM_ITEM_NAME', 'VALUE', 'Item Name' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'ST_ITEM', 1, 'BL_LABEL.B_ITEM_ITEM_INACTIVE', 'VALUE', 'Available' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'ST_ITEM', 1, 'BL_LABEL.B_ITEM_ITEM_DESC', 'VALUE', 'Description' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'ST_ITEM', 1, 'BL_LABEL.B_ITEM_ITEM_REM1', 'VALUE', 'Remark 1' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'ST_ITEM', 1, 'BL_LABEL.B_ITEM_ITEM_REM2', 'VALUE', 'Remark 2' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'ST_ITEM', 1, 'BL_LABEL.B_ITEM_ITEM_REM3', 'VALUE', 'Remark 3' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'ST_ITEM', 1, 'BL_LABEL.B_ITEM_ITEM_REM4', 'VALUE', 'Remark 4' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'ST_ITEM', 1, 'BL_LABEL.B_ITEM_MINORDQTY', 'VALUE', 'Min Ord Qty' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'ST_ITEM', 1, 'BL_LABEL.B_ITEM_MAXORDQTY', 'VALUE', 'Max Ord Qty' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'ST_ITEM', 1, 'BL_LABEL.B_ITEM_FK_ITEMCLASS_ID', 'VALUE', 'Item Class ' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'ST_ITEM', 1, 'BL_LABEL.B_ITEM_FK_ITEMGROUP_ID', 'VALUE', 'Item Group ' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'ST_ITEM', 1, 'BL_LABEL.B_ITEM_FK_COSTCENTRE_ID', 'VALUE', 'Cost Centre Name' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'ST_ITEM', 1, 'BL_LABEL.B_ITEM_DM_UNITTYPE', 'VALUE', 'Unit Type ' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'ST_ITEM', 1, 'BL_LABEL.B_ITEM_SPLINSTRUCT', 'VALUE', 'Spl Instruct ' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'ST_ITEM', 1, 'BL_LABEL.B_ITEM_ASSIGN_CLIENTS', 'VALUE', 'Assign this Item to all Clients ' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'ST_ITEM', 1, 'BL_LABEL.B_ITEM_ASSIGN_USERS', 'VALUE', 'Assign this Item to all Users ' );

commit;

PROMPT *****[ Ending ST_ITEM.sql ]*****
