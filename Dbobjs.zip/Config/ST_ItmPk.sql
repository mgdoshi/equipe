/* Script Name : ST_ITEMPACK.sql.
   Author      : Manoj Doshi : Ingenium Computing Private Ltd, on 23th July 1999.
   Description : Config Details for ItemPack Form
*/

PROMPT *****[ Starting ST_ITEMPACK.sql ]*****

DELETE FROM T_Config
WHERE  Parent_Obj = 'ST_ITEMPACK'
AND    Fk_Lang_ID = 1;

		/* Form Name */

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'ST_ITEMPACK', 1, 'WD_TABLE', 'LABEL', 'ItemPack / T' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'ST_ITEMPACK', 1, 'WD_FORM_INSERT', 'LABEL', 'ItemPack / I' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'ST_ITEMPACK', 1, 'WD_FORM_UPDATE', 'LABEL', 'ItemPack / U' );

		/* Buttons */

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'ST_ITEMPACK', 1, 'BL_ITEMPACK.BU_NEW', 'LABEL', 'Create New ItemPack' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'ST_ITEMPACK', 1, 'BL_ITEMPACK.BU_UPDATE', 'LABEL', 'Update ItemPack' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
 ( NEXTVAL('S_Config'), 'ST_ITEMPACK', 1, 'BL_ITEMPACK.BU_DELETE', 'LABEL', 'Delete ItemPack' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'ST_ITEMPACK', 1, 'BL_ITEMPACK.BU_SAVE', 'LABEL', 'Save ItemPack' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'ST_ITEMPACK', 1, 'BL_ITEMPACK.BU_SAVE1', 'LABEL', 'Save ItemPack And Create New ItemPack' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'ST_ITEMPACK', 1, 'BL_ITEMPACK.BU_FORMHELP', 'LABEL', 'ItemPack Form Information' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'ST_ITEMPACK', 1, 'BL_ITEMPACK.BU_HELP', 'LABEL', 'ItemPack Form Help' );

		/* Fields */

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'ST_ITEMPACK', 1, 'BL_LABEL.B_ITEMPACK_ITEMPACK_NAME', 'VALUE', 'ItemPack Name' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'ST_ITEMPACK', 1, 'BL_LABEL.B_ITEMPACK_ITEMPACK_DESC', 'VALUE', 'Description' );

commit;

PROMPT *****[ Ending ST_ITEMPACK.sql ]*****
