/* Script Name : TR_SHOPCART.sql.
   Author      : Manoj Doshi : Ingenium Computing Private Ltd, on 26th July 1999.
   Description : Config Details for Shopping Cart Form
*/

PROMPT *****[ Starting TR_SHOPCART.sql ]*****

DELETE FROM T_Config
WHERE  Parent_Obj = 'TR_SHOPCART'
AND    Fk_Lang_ID = 1;

		/* Form Name */

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'TR_SHOPCART', 1, 'WD_QUERY', 'LABEL', 'Shopping Cart / Q' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'TR_SHOPCART', 1, 'WD_FORM_INSERT', 'LABEL', 'Shopping Cart / I' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'TR_SHOPCART', 1, 'WD_FORM_UPDATE', 'LABEL', 'Shopping Cart / U' );

		/* Buttons */

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'TR_SHOPCART', 1, 'BL_SHOPCART.BU_NEW', 'LABEL', 'Create New Shopping Cart' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'TR_SHOPCART', 1, 'BL_SHOPCART.BU_UPDATE', 'LABEL', 'Update Shopping Cart' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
 ( NEXTVAL('S_Config'), 'TR_SHOPCART', 1, 'BL_SHOPCART.BU_DELETE', 'LABEL', 'Delete Shopping Cart' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'TR_SHOPCART', 1, 'BL_SHOPCART.BU_SAVE', 'LABEL', 'Save Shopping Cart' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'TR_SHOPCART', 1, 'BL_SHOPCART.BU_FORMHELP', 'LABEL', 'Shopping Cart Form Information' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'TR_SHOPCART', 1, 'BL_SHOPCART.BU_HELP', 'LABEL', 'Shopping Cart Form Help' );

		/* Fields */

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'TR_SHOPCART', 1, 'BL_LABEL.B_SHOPCART_DEFN', 'VALUE', 'Select Shopping Cart Defination' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'TR_SHOPCART', 1, 'BL_LABEL.B_SHOPCART_SHOPCART_NAME', 'VALUE', 'Shopping Cart Name' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'TR_SHOPCART', 1, 'BL_LABEL.B_SHOPCART_ITEM_NAME', 'VALUE', 'Item Name' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'TR_SHOPCART', 1, 'BL_LABEL.B_SHOPCART_ITEM_DESC', 'VALUE', 'Item Desc' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'TR_SHOPCART', 1, 'BL_LABEL.B_SHOPCART_FK_ITEMCLASS_ID', 'VALUE', 'Item Class' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'TR_SHOPCART', 1, 'BL_LABEL.B_SHOPCART_FK_ITEMGROUP_ID', 'VALUE', 'Item Group' );

commit;

PROMPT *****[ Ending TR_SHOPCART.sql ]*****
