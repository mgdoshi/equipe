/* Script Name : ST_USRREL.sql.
   Author      : Manoj Doshi : Ingenium Computing Private Ltd, on 23th July 1999.
   Description : Config Details for User RelationShip
*/

PROMPT *****[ Starting ST_USRREL.sql ]*****

DELETE FROM T_Config
WHERE  Parent_Obj = 'ST_USERREL'
AND    Fk_Lang_ID = 1;

		/* Form Name */

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'ST_USERREL', 1, 'WD_FROM_DEFINE', 'LABEL', 'UserRel / D' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'ST_USERREL', 1, 'WD_FROM_INSERT', 'LABEL', 'UserRel / I' );

		/* Buttons */

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'ST_USERREL', 1, 'BL_USERREL.BU_DEFINE', 'LABEL', 'Define User RelationShip' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'ST_USERREL', 1, 'BL_USERREL.BU_SAVE', 'LABEL', 'Save User RelationShip' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'ST_USERREL', 1, 'BL_USERREL.BU_FORMHELP', 'LABEL', 'User RelationShip Form Information' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'ST_USERREL', 1, 'BL_USERREL.BU_HELP', 'LABEL', 'User RelationShip Form Help' );

		/* Fields */

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'ST_USERREL', 1, 'BL_LABEL.B_USERREL_SELECT', 'VALUE', 'Select a User Name' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'ST_USERREL', 1, 'BL_LABEL.B_USERREL_RELATION', 'VALUE', 'Select a Relation' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'ST_USERREL', 1, 'BL_LABEL.B_USERREL_CLIENT', 'VALUE', 'Client' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'ST_USERREL', 1, 'BL_LABEL.B_USERREL_EMPLOYEE', 'VALUE', 'Employee' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'ST_USERREL', 1, 'BL_LABEL.B_USERREL_ITEM', 'VALUE', 'Item' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'ST_USERREL', 1, 'BL_LABEL.B_USERREL_USER', 'VALUE', 'RelationShip of User' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'ST_USERREL', 1, 'BL_LABEL.B_USERREL_RELATION_WITH', 'VALUE', 'With' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'ST_USERREL', 1, 'BL_LABEL.B_USERREL_ASSIGN', 'VALUE', 'Assign' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'ST_USERREL', 1, 'BL_LABEL.B_USERREL_DEASSIGN', 'VALUE', 'DeAssign' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'ST_USERREL', 1, 'BL_LABEL.B_USERREL_GROUP', 'VALUE', 'Groups assigned to User' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'ST_USERREL', 1, 'BL_LABEL.B_USERREL_USER_NAME', 'VALUE', 'User Name' );

commit;

PROMPT *****[ Ending ST_USRREL.sql ]*****
