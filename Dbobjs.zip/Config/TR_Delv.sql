/* Script Name : TR_Delivery.sql.
   Author      : Manoj Doshi : Ingenium Computing Private Ltd, on 10th July 1999.
   Description : Config Details for Delivery Form 
*/

PROMPT *****[ Starting TR_Delivery.sql ]*****

DELETE FROM T_Config
WHERE  Parent_Obj = 'TR_DELIVERY'
AND    Fk_Lang_ID = 1;

		/* Form Name */

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'TR_DELIVERY', 1, 'WD_DELIVERY', 'LABEL', 'Delivery Details' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'TR_DELIVERY', 1, 'WD_DELIVERY_INSERT', 'LABEL', 'Delivery / I' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'TR_DELIVERY', 1, 'WD_DELIVERY_UPDATE', 'LABEL', 'Delivery / U' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'TR_DELIVERY', 1, 'WD_DELIVERY_DEFINE', 'LABEL', 'Delivery / D' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'TR_DELIVERY', 1, 'WD_QUERY', 'LABEL', 'Delivery / Q' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'TR_DELIVERY', 1, 'WD_TABLE', 'LABEL', 'Delivery / T' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'TR_DELIVERY', 1, 'WD_FORM_QUERY', 'LABEL', 'Delivery Report / Q' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'TR_DELIVERY', 1, 'WD_FORM_TABLE', 'LABEL', 'Delivery Report/ T' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'TR_DELIVERY', 1, 'WD_FORM_LIST', 'LABEL', 'Delivery List' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'TR_DELIVERY', 1, 'WD_FORM_DETAILS', 'LABEL', 'Delivery Details' );

		/* Buttons */

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'TR_DELIVERY', 1, 'BL_DELIVERY.BU_CLIENTSAVE', 'LABEL', 'Create Delivery for Orders' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'TR_DELIVERY', 1, 'BL_DELIVERY.BU_SHOWORDERWIN', 'LABEL', 'Show Order Window' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'TR_DELIVERY', 1, 'BL_DELIVERY.BU_SAVE', 'LABEL', 'Save Delivery Header' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'TR_DELIVERY', 1, 'BL_DELIVERY.BU_QUERY', 'LABEL', 'Delivery Query Details' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'TR_DELIVERY', 1, 'BL_DELIVERY.BU_DELETE', 'LABEL', 'Delete Delivery' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'TR_DELIVERY', 1, 'BL_DELIVERY.BU_QUERY_LIST', 'LABEL', 'Show Delivery Report List' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'TR_DELIVERY', 1, 'BL_DELIVERY.BU_QUERY_REPORT', 'LABEL', 'Show Delivery Report Table' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'TR_DELIVERY', 1, 'BL_DELIVERY.BU_FORMHELP', 'LABEL', 'Delivery Entry Form Information' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'TR_DELIVERY', 1, 'BL_DELIVERY.BU_HELP', 'LABEL', 'Delivery Entry Form Help' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'TR_DELIVERY', 1, 'BL_DELVREP.BU_FORMHELP', 'LABEL', 'Delivery Report Form Information' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'TR_DELIVERY', 1, 'BL_DELVREP.BU_HELP', 'LABEL', 'Delivery Report Form Help' );

		/* Fields */

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Property_Value, Obj_Property )
Values
  ( NEXTVAL('S_Config'), 'TR_DELIVERY', 1, 'BL_LABEL.B_DELIVERY_SELCLIENT', 'Select Client', 'LABEL' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Property_Value, Obj_Property )
Values
  ( NEXTVAL('S_Config'), 'TR_DELIVERY', 1, 'BL_LABEL.B_DELIVERY_ORDER_NR', 'Order No', 'LABEL' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Property_Value, Obj_Property )
Values
  ( NEXTVAL('S_Config'), 'TR_DELIVERY', 1, 'BL_LABEL.B_DELIVERY_DELIVERY_ID', 'Delivery ID', 'LABEL' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Property_Value, Obj_Property )
Values
  ( NEXTVAL('S_Config'), 'TR_DELIVERY', 1, 'BL_LABEL.B_DELIVERY_DELIVERY_NR', 'Delivery No', 'LABEL' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Property_Value, Obj_Property )
Values
  ( NEXTVAL('S_Config'), 'TR_DELIVERY', 1, 'BL_LABEL.B_DELIVERY_DELIVERY_DT', 'Delivery Date', 'LABEL' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Property_Value, Obj_Property )
Values
  ( NEXTVAL('S_Config'), 'TR_DELIVERY', 1, 'BL_LABEL.B_DELIVERY_DM_DELSTAT', 'Delivery Status', 'LABEL' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Property_Value, Obj_Property )
Values
  ( NEXTVAL('S_Config'), 'TR_DELIVERY', 1, 'BL_LABEL.B_DELIVERY_DM_SHIPMODE', 'Shipping Mode', 'LABEL' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Property_Value, Obj_Property )
Values
  ( NEXTVAL('S_Config'), 'TR_DELIVERY', 1, 'BL_LABEL.B_DELIVERY_REF_NR', 'Ref No', 'LABEL' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Property_Value, Obj_Property )
Values
  ( NEXTVAL('S_Config'), 'TR_DELIVERY', 1, 'BL_LABEL.B_DELIVERY_SHIPFROMADD_ID', 'Shipp From Addr', 'LABEL' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Property_Value, Obj_Property )
Values
  ( NEXTVAL('S_Config'), 'TR_DELIVERY', 1, 'BL_LABEL.B_DELIVERY_SHIPTOADD_ID', 'Shipp To Addr', 'LABEL' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Property_Value, Obj_Property )
Values
  ( NEXTVAL('S_Config'), 'TR_DELIVERY', 1, 'BL_LABEL.B_DELIVERY_TRANSADD_ID', 'Transport Addr', 'LABEL' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Property_Value, Obj_Property )
Values
  ( NEXTVAL('S_Config'), 'TR_DELIVERY', 1, 'BL_LABEL.B_DELIVERY_DT1', 'Custom Date1', 'LABEL' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Property_Value, Obj_Property )
Values
  ( NEXTVAL('S_Config'), 'TR_DELIVERY', 1, 'BL_LABEL.B_DELIVERY_DT2', 'Custom Date2', 'LABEL' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Property_Value, Obj_Property )
Values
  ( NEXTVAL('S_Config'), 'TR_DELIVERY', 1, 'BL_LABEL.B_DELIVERY_DT3', 'Custom Date3', 'LABEL' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Property_Value, Obj_Property )
Values
  ( NEXTVAL('S_Config'), 'TR_DELIVERY', 1, 'BL_LABEL.B_DELIVERY_NUM1', 'Custom Num1', 'LABEL' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Property_Value, Obj_Property )
Values
  ( NEXTVAL('S_Config'), 'TR_DELIVERY', 1, 'BL_LABEL.B_DELIVERY_NUM2', 'Custom Num2', 'LABEL' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Property_Value, Obj_Property )
Values
  ( NEXTVAL('S_Config'), 'TR_DELIVERY', 1, 'BL_LABEL.B_DELIVERY_NUM3', 'Custom Num3', 'LABEL' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Property_Value, Obj_Property )
Values
  ( NEXTVAL('S_Config'), 'TR_DELIVERY', 1, 'BL_LABEL.B_DELIVERY_NUM4', 'Custom Num4', 'LABEL' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Property_Value, Obj_Property )
Values
  ( NEXTVAL('S_Config'), 'TR_DELIVERY', 1, 'BL_LABEL.B_DELIVERY_NUM5', 'Custom Num5', 'LABEL' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Property_Value, Obj_Property )
Values
  ( NEXTVAL('S_Config'), 'TR_DELIVERY', 1, 'BL_LABEL.B_DELIVERY_TEXT1', 'Custom Text1', 'LABEL' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Property_Value, Obj_Property )
Values
  ( NEXTVAL('S_Config'), 'TR_DELIVERY', 1, 'BL_LABEL.B_DELIVERY_TEXT2', 'Custom Text2', 'LABEL' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Property_Value, Obj_Property )
Values
  ( NEXTVAL('S_Config'), 'TR_DELIVERY', 1, 'BL_LABEL.B_DELIVERY_TEXT3', 'Custom Text3', 'LABEL' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Property_Value, Obj_Property )
Values
  ( NEXTVAL('S_Config'), 'TR_DELIVERY', 1, 'BL_LABEL.B_DELIVERY_TEXT4', 'Custom Text4', 'LABEL' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Property_Value, Obj_Property )
Values
  ( NEXTVAL('S_Config'), 'TR_DELIVERY', 1, 'BL_LABEL.B_DELIVERY_TEXT5', 'Custom Text5', 'LABEL' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Property_Value, Obj_Property )
Values
  ( NEXTVAL('S_Config'), 'TR_DELIVERY', 1, 'BL_LABEL.B_DELIVERY_REMARK1', 'Custom Rem1', 'LABEL' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Property_Value, Obj_Property )
Values
  ( NEXTVAL('S_Config'), 'TR_DELIVERY', 1, 'BL_LABEL.B_DELIVERY_REMARK2', 'Custom Rem2', 'LABEL' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Property_Value, Obj_Property )
Values
  ( NEXTVAL('S_Config'), 'TR_DELIVERY', 1, 'BL_LABEL.B_DELIVERY_REMARK3', 'Custom Rem3', 'LABEL' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Property_Value, Obj_Property )
Values
  ( NEXTVAL('S_Config'), 'TR_DELIVERY', 1, 'BL_LABEL.B_DELIVERY_DELIVERY_NR_FROM', 'Delivery No From', 'LABEL' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Property_Value, Obj_Property )
Values
  ( NEXTVAL('S_Config'), 'TR_DELIVERY', 1, 'BL_LABEL.B_DELIVERY_DELIVERY_NR_TO', 'Delivery No To', 'LABEL' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Property_Value, Obj_Property )
Values
  ( NEXTVAL('S_Config'), 'TR_DELIVERY', 1, 'BL_LABEL.B_DELIVERY_DELIVERY_DT_FROM', 'Delivery Date From', 'LABEL' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Property_Value, Obj_Property )
Values
  ( NEXTVAL('S_Config'), 'TR_DELIVERY', 1, 'BL_LABEL.B_DELIVERY_DELIVERY_DT_TO', 'Delivery Date To', 'LABEL' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Property_Value, Obj_Property )
Values
  ( NEXTVAL('S_Config'), 'TR_DELIVERY', 1, 'BL_LABEL.B_DELIVERY_REMARKS', 'Custom Remarks', 'LABEL' );

commit;

PROMPT *****[ Ending TR_DELIVERY.sql ]*****
