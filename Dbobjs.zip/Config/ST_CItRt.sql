/* Script Name : ST_CLIENTITEMRATE.sql.
   Author      : Manoj Doshi : Ingenium Computing Private Ltd, on 23th July 1999.
   Description : Config Details for Client Item Form
*/

PROMPT *****[ Starting ST_CLIENTITEMRATE.sql ]*****

DELETE FROM T_Config
WHERE  Parent_Obj = 'ST_CLIENTITEMRATE'
AND    Fk_Lang_ID = 1;

		/* Form Name */

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'ST_CLIENTITEMRATE', 1, 'WD_QUERY', 'LABEL', 'Client Item Rate/ Q' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'ST_CLIENTITEMRATE', 1, 'WD_TABLE', 'LABEL', 'Client Item Rate / T' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'ST_CLIENTITEMRATE', 1, 'WD_FORM_INSERT', 'LABEL', 'Client Item Rate / I' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'ST_CLIENTITEMRATE', 1, 'WD_FORM_UPDATE', 'LABEL', 'Client Item Rate / U' );

		/* Buttons */

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'ST_CLIENTITEMRATE', 1, 'BL_CLIENTITEMRATE.BU_QUERY', 'LABEL', 'Client Item Rates Query Details' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'ST_CLIENTITEMRATE', 1, 'BL_CLIENTITEMRATE.BU_NEW', 'LABEL', 'Create New Client Item Rates' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'ST_CLIENTITEMRATE', 1, 'BL_CLIENTITEMRATE.BU_UPDATE', 'LABEL', 'Update Client Item Rate' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'ST_CLIENTITEMRATE', 1, 'BL_CLIENTITEMRATE.BU_DELETE', 'LABEL', 'Delete Client Item Rates' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'ST_CLIENTITEMRATE', 1, 'BL_CLIENTITEMRATE.BU_SAVE', 'LABEL', 'Save Client Item Rates' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'ST_CLIENTITEMRATE', 1, 'BL_CLIENTITEMRATE.BU_FORMHELP', 'LABEL', 'Client Item Rate Form Information' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'ST_CLIENTITEMRATE', 1, 'BL_CLIENTITEMRATE.BU_HELP', 'LABEL', 'Client Item Rate Form Help' );

		/* Fields */

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'ST_CLIENTITEMRATE', 1, 'BL_LABEL.B_CLIENTITEMRATE_FROM_DT', 'VALUE', 'From Date' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'ST_CLIENTITEMRATE', 1, 'BL_LABEL.B_CLIENTITEMRATE_TO_DT', 'VALUE', 'To Date' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'ST_CLIENTITEMRATE', 1, 'BL_LABEL.B_CLIENTITEMRATE_MINQTY', 'VALUE', 'Min Qty' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'ST_CLIENTITEMRATE', 1, 'BL_LABEL.B_CLIENTITEMRATE_MAXQTY', 'VALUE', 'Max Qty' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'ST_CLIENTITEMRATE', 1, 'BL_LABEL.B_CLIENTITEMRATE_UNITPRICE', 'VALUE', 'Unit Price' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'ST_CLIENTITEMRATE', 1, 'BL_LABEL.B_CLIENTITEMRATE_INACTIVE', 'VALUE', 'Active' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'ST_CLIENTITEMRATE', 1, 'BL_LABEL.B_CLIENTITEMRATE_FK_CLIENTITEM_ID', 'VALUE', 'Item Name' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'ST_CLIENTITEMRATE', 1, 'BL_LABEL.B_CLIENTITEMRATE_FK_CLIENT_ID', 'VALUE', 'Client Name' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'ST_CLIENTITEMRATE', 1, 'BL_LABEL.B_CLIENTITEMRATE_FK_ITEM_ID', 'VALUE', 'Item Name' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'ST_CLIENTITEMRATE', 1, 'BL_LABEL.B_CLIENTITEMRATE_CLIENT', 'VALUE', 'Client :' );

commit;

PROMPT *****[ Ending ST_CLIENTITEMRATE.sql ]*****
