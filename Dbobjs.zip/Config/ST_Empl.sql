/* Script Name : ST_EMPLOYEE.sql.
   Author      : Manoj Doshi : Ingenium Computing Private Ltd, on 23th July 1999.
   Description : Config Details for Employee Form
*/

PROMPT *****[ Starting ST_EMPLOYEE.sql ]*****

DELETE FROM T_Config
WHERE  Parent_Obj = 'ST_EMPLOYEE'
AND    Fk_Lang_ID = 1;

		/* Form Name */

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'ST_EMPLOYEE', 1, 'WD_TABLE', 'LABEL', 'Employee / T' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'ST_EMPLOYEE', 1, 'WD_FORM_INSERT', 'LABEL', 'Employee / I' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'ST_EMPLOYEE', 1, 'WD_FORM_UPDATE', 'LABEL', 'Employee / U' );

		/* Buttons */

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'ST_EMPLOYEE', 1, 'BL_EMPLOYEE.BU_NEW', 'LABEL', 'Create New Employee' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'ST_EMPLOYEE', 1, 'BL_EMPLOYEE.BU_UPDATE', 'LABEL', 'Update Employee' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'ST_EMPLOYEE', 1, 'BL_EMPLOYEE.BU_DELETE', 'LABEL', 'Delete Employee' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'ST_EMPLOYEE', 1, 'BL_EMPLOYEE.BU_SAVE', 'LABEL', 'Save Employee' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'ST_EMPLOYEE', 1, 'BL_EMPLOYEE.BU_SAVE1', 'LABEL', 'Save Employee And Create New Employee' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'ST_EMPLOYEE', 1, 'BL_EMPLOYEE.BU_ASSIGN', 'LABEL', 'Assign Functions' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'ST_EMPLOYEE', 1, 'BL_EMPLOYEE.BU_INS_ADDRESS', 'LABEL', 'Create New Address' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'ST_EMPLOYEE', 1, 'BL_EMPLOYEE.BU_UPD_ADDRESS', 'LABEL', 'Update/Delete Address' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'ST_EMPLOYEE', 1, 'BL_EMPLOYEE.BU_FORMHELP', 'LABEL', 'Employee Form Information' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'ST_EMPLOYEE', 1, 'BL_EMPLOYEE.BU_HELP', 'LABEL', 'Employee Form Help' );

		/* Fields */

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'ST_EMPLOYEE', 1, 'BL_LABEL.B_EMPLOYEE_EMPLOYEE_NAME', 'VALUE', 'Employee Name' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'ST_EMPLOYEE', 1, 'BL_LABEL.B_EMPLOYEE_DESCRIPTION', 'VALUE', 'Description ' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'ST_EMPLOYEE', 1, 'BL_LABEL.B_EMPLOYEE_BRANCH_NAME', 'VALUE', 'Branch Name ' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'ST_EMPLOYEE', 1, 'BL_LABEL.B_EMPLOYEE_DESIGNATION', 'VALUE', 'Designation ' );

commit;

PROMPT *****[ Ending ST_EMPLOYEE.sql ]*****
