/* Script Name : TR_DeliveryDetails.sql.
   Author      : Manoj Doshi : Ingenium Computing Private Ltd, on 25th July 1999
   Description : Config Details for Delivery Detials Form 
*/

PROMPT *****[ Starting TR_Delivery.sql ]*****

DELETE FROM T_Config
WHERE  Parent_Obj = 'TR_DELVDTLS'
AND    Fk_Lang_ID = 1;

		/* Form Name */

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'TR_DELVDTLS', 1, 'WD_DELIVERYDTLS', 'LABEL', 'Delivery Details' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'TR_DELVDTLS', 1, 'WD_FORM_INSERT', 'LABEL', 'Delivery Details / I' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'TR_DELVDTLS', 1, 'WD_FORM_UPDATE', 'LABEL', 'Delivery Details / U' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'TR_DELVDTLS', 1, 'WD_DELIVERYDTLS_DEFINE', 'LABEL', 'Delivery Details / D' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'TR_DELVDTLS', 1, 'WD_TABLE', 'LABEL', 'Delivery Details / T' );

		/* Buttons */

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'TR_DELVDTLS', 1, 'BL_DELIVERYDTLS.BU_SAVE', 'LABEL', 'Save Delivery Details' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'TR_DELVDTLS', 1, 'BL_DELIVERYDTLS.BU_DELETE', 'LABEL', 'Delete Delivery Details' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'TR_DELVDTLS', 1, 'BL_DELIVERYDTLS.BU_NEW', 'LABEL', 'Create New Delivery Details' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'TR_DELVDTLS', 1, 'BL_DELIVERYDTLS.BU_UPDATE', 'LABEL', 'Update Delivery Details' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'TR_DELVDTLS', 1, 'BL_DELIVERYDTLS.BU_FORMHELP', 'LABEL', 'Delivery Maintenance Form Information' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'TR_DELVDTLS', 1, 'BL_DELIVERYDTLS.BU_HELP', 'LABEL', 'Delivery Maintenance Form Help' );

		/* Fields */

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Property_Value, Obj_Property )
Values
  ( NEXTVAL('S_Config'), 'TR_DELVDTLS', 1, 'BL_LABEL.B_DELIVERYDTLS_ORDER_NR', 'Order No', 'LABEL' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Property_Value, Obj_Property )
Values
  ( NEXTVAL('S_Config'), 'TR_DELVDTLS', 1, 'BL_LABEL.B_DELIVERYDTLS_POS_NR', 'Ord/Del Pos No', 'LABEL' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Property_Value, Obj_Property )
Values
  ( NEXTVAL('S_Config'), 'TR_DELVDTLS', 1, 'BL_LABEL.B_DELIVERYDTLS_ITEM_NAME', 'Item Name', 'LABEL' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Property_Value, Obj_Property )
Values
  ( NEXTVAL('S_Config'), 'TR_DELVDTLS', 1, 'BL_LABEL.B_DELIVERYDTLS_ITEMPACK_NAME', 'Item Pack', 'LABEL' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Property_Value, Obj_Property )
Values
  ( NEXTVAL('S_Config'), 'TR_DELVDTLS', 1, 'BL_LABEL.B_DELIVERYDTLS_QUANTITY', 'Ord/Del Quantity', 'LABEL' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Property_Value, Obj_Property )
Values
  ( NEXTVAL('S_Config'), 'TR_DELVDTLS', 1, 'BL_LABEL.B_DELIVERYDTLS_DM_UNITTYPE', 'Unit Type', 'LABEL' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Property_Value, Obj_Property )
Values
  ( NEXTVAL('S_Config'), 'TR_DELVDTLS', 1, 'BL_LABEL.B_DELIVERYDTLS_UNITPRICE', 'Unit Price', 'LABEL' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Property_Value, Obj_Property )
Values
  ( NEXTVAL('S_Config'), 'TR_DELVDTLS', 1, 'BL_LABEL.B_DELIVERYDTLS_BATCH_NR', 'Batch No', 'LABEL' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Property_Value, Obj_Property )
Values
  ( NEXTVAL('S_Config'), 'TR_DELVDTLS', 1, 'BL_LABEL.B_DELIVERYDTLS_DT1', 'Cust Date1', 'LABEL' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Property_Value, Obj_Property )
Values
  ( NEXTVAL('S_Config'), 'TR_DELVDTLS', 1, 'BL_LABEL.B_DELIVERYDTLS_DT2', 'Cust Date2', 'LABEL' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Property_Value, Obj_Property )
Values
  ( NEXTVAL('S_Config'), 'TR_DELVDTLS', 1, 'BL_LABEL.B_DELIVERYDTLS_DT3', 'Cust Date3', 'LABEL' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Property_Value, Obj_Property )
Values
  ( NEXTVAL('S_Config'), 'TR_DELVDTLS', 1, 'BL_LABEL.B_DELIVERYDTLS_NUM1', 'Cust Num1', 'LABEL' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Property_Value, Obj_Property )
Values
  ( NEXTVAL('S_Config'), 'TR_DELVDTLS', 1, 'BL_LABEL.B_DELIVERYDTLS_NUM2', 'Cust Num2', 'LABEL' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Property_Value, Obj_Property )
Values
  ( NEXTVAL('S_Config'), 'TR_DELVDTLS', 1, 'BL_LABEL.B_DELIVERYDTLS_NUM3', 'Cust Num3', 'LABEL' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Property_Value, Obj_Property )
Values
  ( NEXTVAL('S_Config'), 'TR_DELVDTLS', 1, 'BL_LABEL.B_DELIVERYDTLS_NUM4', 'Cust Num4', 'LABEL' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Property_Value, Obj_Property )
Values
  ( NEXTVAL('S_Config'), 'TR_DELVDTLS', 1, 'BL_LABEL.B_DELIVERYDTLS_NUM5', 'Cust Num5', 'LABEL' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Property_Value, Obj_Property )
Values
  ( NEXTVAL('S_Config'), 'TR_DELVDTLS', 1, 'BL_LABEL.B_DELIVERYDTLS_TEXT1', 'Cust Text1', 'LABEL' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Property_Value, Obj_Property )
Values
  ( NEXTVAL('S_Config'), 'TR_DELVDTLS', 1, 'BL_LABEL.B_DELIVERYDTLS_TEXT2', 'Cust Text2', 'LABEL' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Property_Value, Obj_Property )
Values
  ( NEXTVAL('S_Config'), 'TR_DELVDTLS', 1, 'BL_LABEL.B_DELIVERYDTLS_TEXT3', 'Cust Text3', 'LABEL' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Property_Value, Obj_Property )
Values
  ( NEXTVAL('S_Config'), 'TR_DELVDTLS', 1, 'BL_LABEL.B_DELIVERYDTLS_TEXT4', 'Cust Text4', 'LABEL' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Property_Value, Obj_Property )
Values
  ( NEXTVAL('S_Config'), 'TR_DELVDTLS', 1, 'BL_LABEL.B_DELIVERYDTLS_TEXT5', 'Cust Text5', 'LABEL' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Property_Value, Obj_Property )
Values
  ( NEXTVAL('S_Config'), 'TR_DELVDTLS', 1, 'BL_LABEL.B_DELIVERYDTLS_REMARK1', 'Cust Remark1', 'LABEL' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Property_Value, Obj_Property )
Values
  ( NEXTVAL('S_Config'), 'TR_DELVDTLS', 1, 'BL_LABEL.B_DELIVERYDTLS_REMARK2', 'Cust Remark2', 'LABEL' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Property_Value, Obj_Property )
Values
  ( NEXTVAL('S_Config'), 'TR_DELVDTLS', 1, 'BL_LABEL.B_DELIVERYDTLS_REMARK3', 'Cust Remark3', 'LABEL' );

commit;

PROMPT *****[ Ending TR_DELVDTLS.sql ]*****
