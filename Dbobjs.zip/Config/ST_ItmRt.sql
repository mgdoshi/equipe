/* Script Name : ST_ITEMRATE.sql.
   Author      : Manoj Doshi : Ingenium Computing Private Ltd, on 23th July 1999.
   Description : Config Details for ItemRate Form
*/

PROMPT *****[ Starting ST_ITEMRATE.sql ]*****

DELETE FROM T_Config
WHERE  Parent_Obj = 'ST_ITEMRATE'
AND    Fk_Lang_ID = 1;

		/* Form Name */

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'ST_ITEMRATE', 1, 'WD_FORM_QUERY', 'LABEL', 'ItemRate / Q' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'ST_ITEMRATE', 1, 'WD_TABLE', 'LABEL', 'ItemRate / T' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'ST_ITEMRATE', 1, 'WD_FORM_INSERT', 'LABEL', 'ItemRate / I' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'ST_ITEMRATE', 1, 'WD_FORM_UPDATE', 'LABEL', 'ItemRate / U' );

		/* Buttons */

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'ST_ITEMRATE', 1, 'BL_ITEMRATE.BU_QUERY', 'LABEL', 'ItemRate Query Details' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'ST_ITEMRATE', 1, 'BL_ITEMRATE.BU_NEW', 'LABEL', 'Create New ItemRate' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'ST_ITEMRATE', 1, 'BL_ITEMRATE.BU_UPDATE', 'LABEL', 'Update ItemRate' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
 ( NEXTVAL('S_Config'), 'ST_ITEMRATE', 1, 'BL_ITEMRATE.BU_DELETE', 'LABEL', 'Delete ItemRate' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'ST_ITEMRATE', 1, 'BL_ITEMRATE.BU_SAVE', 'LABEL', 'Save ItemRate' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'ST_ITEMRATE', 1, 'BL_ITEMRATE.BU_FORMHELP', 'LABEL', 'ItemRate Form Information' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'ST_ITEMRATE', 1, 'BL_ITEMRATE.BU_HELP', 'LABEL', 'ItemRate Form Help' );

		/* Fields */

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'ST_ITEMRATE', 1, 'BL_LABEL.B_ITEMRATE_FK_ITEM_ID', 'VALUE', 'Item Name' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'ST_ITEMRATE', 1, 'BL_LABEL.B_ITEMRATE_FROM_DT', 'VALUE', 'From Date' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'ST_ITEMRATE', 1, 'BL_LABEL.B_ITEMRATE_TO_DT', 'VALUE', 'To Date' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'ST_ITEMRATE', 1, 'BL_LABEL.B_ITEMRATE_MINQTY', 'VALUE', 'Min Qty' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'ST_ITEMRATE', 1, 'BL_LABEL.B_ITEMRATE_MAXQTY', 'VALUE', 'Max Qty' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'ST_ITEMRATE', 1, 'BL_LABEL.B_ITEMRATE_UNITPRICE', 'VALUE', 'Unit Price' );

Insert Into T_Config
  ( Config_ID, Parent_Obj, Fk_Lang_ID, Obj_Name, Obj_Property, Property_Value )
Values
  ( NEXTVAL('S_Config'), 'ST_ITEMRATE', 1, 'BL_LABEL.B_ITEMRATE_INACTIVE', 'VALUE', 'Active' );

commit;

PROMPT *****[ Ending ST_ITEMRATE.sql ]*****
