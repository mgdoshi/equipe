/* Script Name : F_Group.sql.
   Author      : Manoj Doshi.
   Description : Functions related to the Group Table.
   Procedures  :
   Fuctions    : 
                  GetGroupName for Group_ID Returns Group_Name.
                  GetGroupDesc for Group_ID Returns Group_Desc.
                  GetGroupID   for Group_Name Returns Group_ID.

*/

/* PROMPT *****[ Starting F_Group.sql ]***** */

/* PROMPT *****[ Drop Function GetGroupName ] ***** */ 

Drop function GetGroupName( Integer );

/* PROMPT *****[ Creating Function GetGroupName ] **** */ 

Create Function GetGroupName( Integer ) Returns VarChar As '
Declare
  pn_Group_ID Alias For $1;
  vGroupName VarChar( 30 );
Begin
  Select grp.Group_Name
  Into   vGroupName
  From   T_Group grp
  Where  grp.Group_ID = pn_Group_ID;
  IF NOT FOUND THEN
    Return null;
  END IF;
  Return vGroupName;
End;
' language 'plpgsql';

/*  PROMPT *****[ Drop Function GetGroupDesc ]***** */

Drop function GetGroupDesc( Integer );

/* PROMPT *****[ Creating Function GetGroupDesc ]**** */

Create Function GetGroupDesc( Integer ) Returns VarChar As '
Declare
  pn_Group_ID Alias For $1;
  vGroupDesc VarChar( 100 );
Begin
  Select grp.Group_Desc
  Into   vGroupDesc
  From   T_Group grp
  Where  grp.Group_ID = pn_Group_ID;
  IF NOT FOUND THEN
    Return null;
  END IF;
  Return vGroupDesc;
End;
' language 'plpgsql';

/*  PROMPT *****[ Drop Function GetGroupID ]***** */

Drop function GetGroupID( VarChar );

/* PROMPT *****[ Creating Function GetGroupID ]***** */

Create Function GetGroupID( VarChar ) Returns Integer As '
Declare
  pv_Group_Name Alias For $1;
  nGroupID Integer;
Begin
  Select grp.Group_ID
  Into   nGroupID
  From   T_Group grp
  Where  grp.Group_Name = pv_Group_Name;
  IF NOT FOUND THEN
    Return null;
  END IF;
  Return nGroupID;
End;
' language 'plpgsql';
/
 
/* PROMPT *****[ Ending F_Group.sql ]***** */
