/* Script Name : F_EmployeeFunc.sql.
   Author      : Manoj Doshi.
   Description : Functions related to the EmployeeFunc Table.
   Procedures  :
   Fuctions    : IsEmployeeFunc for Employee_ID, and FuncType Returns Boolean.
*/

/* PROMPT *****[ Starting F_EmployeeFunc.sql ]***** */

/* PROMPT *****[ Drop Function IsEmployeeFunc ]***** */

DROP FUNCTION IsEmployeeFunc( Integer, VarChar);

/* PROMPT *****[ Creating Function IsEmployeeFunc ]***** */

Create Function IsEmployeeFunc( Integer, VarChar) Returns Boolean AS '
Declare
  pn_EmployeeFunc_ID ALIAS FOR $1;
  pv_FuncType ALIAS FOR $2;
  nCount Integer;
Begin
  Select Count(*)
  Into   nCount
  From   T_EmployeeFunc efn
  Where  efn.FK_Employee_ID = pn_EmployeeFunc_ID
  And    efn.DM_FuncType = pv_FuncType
  And    ROWNUM = 1;
  IF NOT FOUND THEN
    Return FALSE;
  END IF;  
  IF NVL(nCount, 0) > 0 Then
    Return TRUE;
  Else
    Return FALSE;
  End If;
End;
' language 'plpgsql';
/
/* *****[ Ending F_EmployeeFunc.sql ]***** */
