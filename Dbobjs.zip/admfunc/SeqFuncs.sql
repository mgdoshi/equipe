/* File Name   :- SeqFuncs.sql
   Author      :- Manoj Doshi
   Description :- Creating all Function Which Returns Nextval of Sequences
*/

/* PROMPT *****[ Drop Funtion GetAddressSeq ]***** */

Drop Function GetAddressSeq();

/* PROMPT *****[ Creating Funtion GetAddressSeq ]***** */

Create Function GetAddressSeq() Returns Integer AS '
Declare
  nAddressID Integer; 
Begin
  Select NEXTVAL(''S_Address'')
  Into   nAddressID;
  Return nAddressID;
End;
' language 'plpgsql';

/* PROMPT *****[ Drop Funtion GetAddressRefSeq ]***** */

Drop Function GetAddressRefSeq();

/* PROMPT *****[ Creating Funtion GetAddressRefSeq ]***** */

Create Function GetAddressRefSeq() Returns Integer AS '
Declare
  nAddressRefID Integer; 
Begin
  Select NEXTVAL(''S_AddressRef'')
  Into   nAddressRefID;
  Return nAddressRefID;
End;
' language 'plpgsql';

/* PROMPT *****[ Drop Funtion GetAuditSeq ]***** */

Drop Function GetAuditSeq();

/* PROMPT *****[ Creating Funtion GetAuditSeq ]***** */

Create Function GetAuditSeq() Returns Integer AS '
Declare
  nAuditID Integer; 
Begin
  Select NEXTVAL(''S_Audit'')
  Into   nAuditID;
  Return nAuditID;
End;
' language 'plpgsql';

/* PROMPT *****[ Drop Funtion GetBranchSeq ]***** */

Drop Function GetBranchSeq();

/* PROMPT *****[ Creating Funtion GetBranchSeq ]***** */

Create Function GetBranchSeq() Returns Integer AS '
Declare
  nBranchID Integer; 
Begin
  Select NEXTVAL(''S_Branch'')
  Into   nBranchID;
  Return nBranchID;
End;
' language 'plpgsql';

/* PROMPT *****[ Drop Funtion GetCartDefSeq ]***** */

Drop Function GetCartDefSeq();

/* PROMPT *****[ Creating Funtion GetCartDefSeq ]***** */

Create Function GetCartDefSeq() Returns Integer AS '
Declare
  nCartDefID Integer; 
Begin
  Select NEXTVAL(''S_CartDef'')
  Into   nCartDefID;
  Return nCartDefID;
End;
' language 'plpgsql';

/* PROMPT *****[ Drop Funtion GetClientSeq ]***** */

Drop Function GetClientSeq();

/* PROMPT *****[ Creating Funtion GetClientSeq ]***** */

Create Function GetClientSeq() Returns Integer AS '
Declare
  nClientID Integer; 
Begin
  Select NEXTVAL(''S_Client'')
  Into   nClientID;
  Return nClientID;
End;
' language 'plpgsql';

/* PROMPT *****[ Drop Funtion GetClientItemSeq ]***** */

Drop Function GetClientItemSeq();

/* PROMPT *****[ Creating Funtion GetClientItemSeq ]***** */

Create Function GetClientItemSeq() Returns Integer AS '
Declare
  nClientItemID Integer; 
Begin
  Select NEXTVAL(''S_ClientItem'')
  Into   nClientItemID;
  Return nClientItemID;
End;
' language 'plpgsql';

/* PROMPT *****[ Drop Funtion GetClnItmRateSeq ]***** */

Drop Function GetClnItmRateSeq();

/* PROMPT *****[ Creating Funtion GetClnItmRateSeq ]***** */

Create Function GetClnItmRateSeq() Returns Integer AS '
Declare
  nClnItmRateID Integer; 
Begin
  Select NEXTVAL(''S_ClientItemRate'')
  Into   nClnItmRateID;
  Return nClnItmRateID;
End;
' language 'plpgsql';

/* PROMPT *****[ Drop Funtion GetConfigSeq ]***** */

Drop Function GetConfigSeq();

/* PROMPT *****[ Creating Funtion GetConfigSeq ]***** */

Create Function GetConfigSeq() Returns Integer AS '
Declare
  nConfigID Integer; 
Begin
  Select NEXTVAL(''S_Config'')
  Into   nConfigID;
  Return nConfigID;
End;
' language 'plpgsql';

/* PROMPT *****[ Drop Funtion GetCostCentreSeq ]***** */

Drop Function GetCostCentreSeq();

/* PROMPT *****[ Creating Funtion GetCostCentreSeq ]***** */

Create Function GetCostCentreSeq() Returns Integer AS '
Declare
  nCostCentreID Integer; 
Begin
  Select NEXTVAL(''S_CostCentre'')
  Into   nCostCentreID;
  Return nCostCentreID;
End;
' language 'plpgsql';

/* PROMPT *****[ Drop Funtion GetDeliverySeq ]***** */

Drop Function GetDeliverySeq();

/* PROMPT *****[ Creating Funtion GetDeliverySeq ]***** */

Create Function GetDeliverySeq() Returns Integer AS '
Declare
  nDeliveryID Integer; 
Begin
  Select NEXTVAL(''S_Delivery'')
  Into   nDeliveryID;
  Return nDeliveryID;
End;
' language 'plpgsql';

/* PROMPT *****[ Drop Funtion GetDeliveryDtlsSeq ]***** */

Drop Function GetDeliveryDtlsSeq();

/* PROMPT *****[ Creating Funtion GetDeliveryDtlsSeq ]***** */

Create Function GetDeliveryDtlsSeq() Returns Integer AS '
Declare
  nDelvDtlsID Integer; 
Begin
  Select NEXTVAL(''S_DeliveryDtls'')
  Into   nDelvDtlsID;
  Return nDelvDtlsID;
End;
' language 'plpgsql';

/* PROMPT *****[ Drop Funtion GetDataLogSeq ]***** */

Drop Function GetDataLogSeq();

/* PROMPT *****[ Creating Funtion GetDataLogSeq ]***** */

Create Function GetDataLogSeq() Returns Integer AS '
Declare
  nDataLogID Integer; 
Begin
  Select NEXTVAL(''S_DataLog'')
  Into   nDataLogID;
  Return nDataLogID;
End;
' language 'plpgsql';

/* PROMPT *****[ Drop Funtion GetEmployeeSeq ]***** */

Drop Function GetEmployeeSeq();

/* PROMPT *****[ Creating Funtion GetEmployeeSeq ]***** */

Create Function GetEmployeeSeq() Returns Integer AS '
Declare
  nEmployeeID Integer; 
Begin
  Select NEXTVAL(''S_Employee'')
  Into   nEmployeeID;
  Return nEmployeeID;
End;
' language 'plpgsql';

/* PROMPT *****[ Drop Funtion GetGroupSeq ]***** */

Drop Function GetGroupSeq();

/* PROMPT *****[ Creating Funtion GetGroupSeq ]***** */

Create Function GetGroupSeq() Returns Integer AS '
Declare
  nGroupID Integer; 
Begin
  Select NEXTVAL(''S_Group'')
  Into   nGroupID;
  Return nGroupID;
End;
' language 'plpgsql';

/* PROMPT *****[ Drop Funtion GetHelpSeq ]***** */

Drop Function GetHelpSeq();

/* PROMPT *****[ Creating Funtion GetHelpSeq ]***** */

Create Function GetHelpSeq() Returns Integer AS '
Declare
  nHelpID Integer; 
Begin
  Select NEXTVAL(''S_Help'')
  Into   nHelpID;
  Return nHelpID;
End;
' language 'plpgsql';

/* PROMPT *****[ Drop Funtion GetItemSeq ]***** */

Drop Function GetItemSeq();

/* PROMPT *****[ Creating Funtion GetItemSeq ]***** */

Create Function GetItemSeq() Returns Integer AS '
Declare
  nItemID Integer; 
Begin
  Select NEXTVAL(''S_Item'')
  Into   nItemID;
  Return nItemID;
End;
' language 'plpgsql';

/* PROMPT *****[ Drop Funtion GetItemClassSeq ]***** */

Drop Function GetItemClassSeq();

/* PROMPT *****[ Creating Funtion GetItemClassSeq ]***** */

Create Function GetItemClassSeq() Returns Integer AS '
Declare
  nItmClsID Integer; 
Begin
  Select NEXTVAL(''S_ItemClass'')
  Into   nItmClsID;
  Return nItmClsID;
End;
' language 'plpgsql';

/* PROMPT *****[ Drop Funtion GetItemGroupSeq ]***** */

Drop Function GetItemGroupSeq();

/* PROMPT *****[ Creating Funtion GetItemGroupSeq ]***** */

Create Function GetItemGroupSeq() Returns Integer AS '
Declare
  nItmGrpID Integer; 
Begin
  Select NEXTVAL(''S_ItemGroup'')
  Into   nItmGrpID;
  Return nItmGrpID;
End;
' language 'plpgsql';

/* PROMPT *****[ Drop Funtion GetItemPackSeq ]***** */

Drop Function GetItemPackSeq();

/* PROMPT *****[ Creating Funtion GetItemPackSeq ]***** */

Create Function GetItemPackSeq() Returns Integer AS '
Declare
  nItmPakID Integer; 
Begin
  Select NEXTVAL(''S_ItemPack'')
  Into   nItmPakID;
  Return nItmPakID;
End;
' language 'plpgsql';

/* PROMPT *****[ Drop Funtion GetItemRateSeq ]***** */

Drop Function GetItemRateSeq();

/* PROMPT *****[ Creating Funtion GetItemRateSeq ]***** */

Create Function GetItemRateSeq() Returns Integer AS '
Declare
  nItmRtID Integer; 
Begin
  Select NEXTVAL(''S_ItemRate'')
  Into   nItmRtID;
  Return nItmRtID;
End;
' language 'plpgsql';

/* PROMPT *****[ Drop Funtion GetLangSeq ]***** */

Drop Function GetLangSeq();

/* PROMPT *****[ Creating Funtion GetLangSeq ]***** */

Create Function GetLangSeq() Returns Integer AS '
Declare
  nLangID Integer; 
Begin
  Select NEXTVAL(''S_Lang'')
  Into   nLangID;
  Return nLangID;
End;
' language 'plpgsql';

/* PROMPT *****[ Drop Funtion GetMenuSecSeq ]***** */

Drop Function GetMenuSecSeq();

/* PROMPT *****[ Creating Funtion GetMenuSecSeq ]***** */

Create Function GetMenuSecSeq() Returns Integer AS '
Declare
  nMenuSecID Integer; 
Begin
  Select NEXTVAL(''S_MenuSec'')
  Into   nMenuSecID;
  Return nMenuSecID;
End;
' language 'plpgsql';

/* PROMPT *****[ Drop Funtion GetNewsSeq ]***** */

Drop Function GetNewsSeq();

/* PROMPT *****[ Creating Funtion GetNewsSeq ]***** */

Create Function GetNewsSeq() Returns Integer AS '
Declare
  nNewsID Integer; 
Begin
  Select NEXTVAL(''S_News'')
  Into   nNewsID;
  Return nNewsID;
End;
' language 'plpgsql';

/* PROMPT *****[ Drop Funtion GetObjSecSeq ]***** */

Drop Function GetObjSecSeq();

/* PROMPT *****[ Creating Funtion GetObjSecSeq ]***** */

Create Function GetObjSecSeq() Returns Integer AS '
Declare
  nObjSecID Integer; 
Begin
  Select NEXTVAL(''S_ObjSec'')
  Into   nObjSecID;
  Return nObjSecID;
End;
' language 'plpgsql';

/* PROMPT *****[ Drop Funtion GetOrderSeq ]***** */

Drop Function GetOrderSeq();

/* PROMPT *****[ Creating Funtion GetOrderSeq ]***** */

Create Function GetOrderSeq() Returns Integer AS '
Declare
  nOrderID Integer; 
Begin
  Select NEXTVAL(''S_Order'')
  Into   nOrderID;
  Return nOrderID;
End;
' language 'plpgsql';

/* PROMPT *****[ Drop Funtion GetOrderDtlsSeq ]***** */

Drop Function GetOrderDtlsSeq();

/* PROMPT *****[ Creating Funtion GetOrderDtlsSeq ]***** */

Create Function GetOrderDtlsSeq() Returns Integer AS '
Declare
  nOrderDtlsID Integer; 
Begin
  Select NEXTVAL(''S_OrderDtls'')
  Into   nOrderDtlsID;
  Return nOrderDtlsID;
End;
' language 'plpgsql';

/* PROMPT *****[ Drop Funtion GetParamSeq ]***** */

Drop Function GetParamSeq();

/* PROMPT *****[ Creating Funtion GetParamSeq ]***** */

Create Function GetParamSeq() Returns Integer AS '
Declare
  nParamID Integer; 
Begin
  Select NEXTVAL(''S_Param'')
  Into   nParamID;
  Return nParamID;
End;
' language 'plpgsql';

/* PROMPT *****[ Drop Funtion GetRecSecSeq ]***** */

Drop Function GetRecSecSeq();

/* PROMPT *****[ Creating Funtion GetRecSecSeq ]***** */

Create Function GetRecSecSeq() Returns Integer AS '
Declare
  nRecSecID Integer; 
Begin
  Select NEXTVAL(''S_RecSec'')
  Into   nRecSecID;
  Return nRecSecID;
End;
' language 'plpgsql';

/* PROMPT *****[ Drop Funtion GetSchemeSeq ]***** */

Drop Function GetSchemeSeq();

/* PROMPT *****[ Creating Funtion GetSchemeSeq ]***** */

Create Function GetSchemeSeq() Returns Integer AS '
Declare
  nSchemeID Integer; 
Begin
  Select NEXTVAL(''S_Scheme'')
  Into   nSchemeID;
  Return nSchemeID;
End;
' language 'plpgsql';

/* PROMPT *****[ Drop Funtion GetTemplateSeq ]***** */

Drop Function GetTemplateSeq();

/* PROMPT *****[ Creating Funtion GetTemplateSeq ]***** */

Create Function GetTemplateSeq() Returns Integer AS '
Declare
  nTemplateID Integer; 
Begin
  Select NEXTVAL(''S_Template'')
  Into   nTemplateID;
  Return nTemplateID;
End;
' language 'plpgsql';

/* PROMPT *****[ Drop Funtion GetTemplateDtlsSeq ]***** */

Drop Function GetTemplateDtlsSeq();

/* PROMPT *****[ Creating Funtion GetTemplateDtlsSeq ]***** */

Create Function GetTemplateDtlsSeq() Returns Integer AS '
Declare
  nTemplateDtlsID Integer; 
Begin
  Select NEXTVAL(''S_TemplateDtls'')
  Into   nTemplateDtlsID;
  Return nTemplateDtlsID;
End;
' language 'plpgsql';

/* PROMPT *****[ Drop Funtion GetTransSeq ]***** */

Drop Function GetTransSeq();

/* PROMPT *****[ Creating Funtion GetTransSeq ]***** */

Create Function GetTransSeq() Returns Integer AS '
Declare
  nTransID Integer; 
Begin
  Select NEXTVAL(''S_Trans'')
  Into   nTransID;
  Return nTransID;
End;
' language 'plpgsql';

/* PROMPT *****[ Drop Funtion GetUserSeq ]***** */

Drop Function GetUserSeq();

/* PROMPT *****[ Creating Funtion GetUserSeq ]***** */

Create Function GetUserSeq() Returns Integer AS '
Declare
  nUserID Integer; 
Begin
  Select NEXTVAL(''S_User'')
  Into   nUserID;
  Return nUserID;
End;
' language 'plpgsql';

/* PROMPT *****[ Drop Funtion GetUserGroupSeq ]***** */

Drop Function GetUserGroupSeq();

/* PROMPT *****[ Creating Funtion GetUserGroupSeq ]***** */

Create Function GetUserGroupSeq() Returns Integer AS '
Declare
  nUsrGrpID Integer; 
Begin
  Select NEXTVAL(''S_UserGroup'')
  Into   nUsrGrpID;
  Return nUsrGrpID;
End;
' language 'plpgsql';

/* PROMPT *****[ Drop Funtion GetUserParamSeq ]***** */

Drop Function GetUserParamSeq();

/* PROMPT *****[ Creating Funtion GetUserParamSeq ]***** */

Create Function GetUserParamSeq() Returns Integer AS '
Declare
  nUsrParamID Integer; 
Begin
  Select NEXTVAL(''S_UserParam'')
  Into   nUsrParamID;
  Return nUsrParamID;
End;
' language 'plpgsql';
