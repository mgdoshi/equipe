/* 
   Script Name : F_MenuSec.sql.
   Author      : Manoj Doshi
   Description : Functions related to the MenuSec Table.
   Procedures  :
   Functions   : 
                  1. IsMenuEnabled for a User_ID and Menu_Name
                     Returns Boolean value.
*/

/* PROMPT *************[ Starting F_MenuSec.sql ]*************** */

/* PROMPT ***********[ Drop Function IsMenuEnabled ] ******** */

DROP FUNCTION IsMenuEnabled( Integer, VarChar );

/* PROMPT ****[ Start Creating Function IsMenuEnabled ]***** */

CREATE FUNCTION IsMenuEnabled( Integer, VarChar ) RETURNS Boolean AS '
DECLARE
  pn_UserID   ALIAS FOR $1;
  pv_MenuName ALIAS FOR $2;
  nCnt          Integer;
  nAllowCnt     Integer;
  nDisAllowCnt  Integer;
BEGIN
  IF pn_UserId ISNULL THEN
    RETURN FALSE;
  END IF;

  SELECT COUNT(*)
  INTO   nDisAllowCnt
  FROM   T_MenuSec msc
  WHERE  msc.Menu_Name = pv_MenuName
  AND    msc.DM_SecLevel = ''S''
  AND    msc.Allow_Flg = 0;

  IF nDisAllowCnt > 0 THEN
    RETURN FALSE;
  END IF;

  SELECT Count(*)
  INTO   nDisAllowCnt
  FROM   T_MenuSec msc
  WHERE  msc.Ref_Id = pn_UserID
  AND    msc.Menu_Name = pv_MenuName
  AND    msc.DM_SecLevel = ''U''
  AND    msc.Allow_Flg = 0;

  IF nDisAllowCnt > 0 THEN
    RETURN FALSE;
  End If;

  SELECT Count(*)
  INTO   nAllowCnt
  FROM   T_MenuSec msc
  WHERE  msc.Ref_Id = pn_UserID
  AND    msc.Menu_Name = pv_MenuName
  AND    msc.DM_SecLevel = ''U''
  AND    msc.Allow_Flg = 1;

  IF nAllowCnt > 0 THEN
    RETURN TRUE;
  END IF;

  SELECT COUNT(*), SUM( Allow_Flg )
  INTO   nCnt, nAllowCnt
  FROM   T_MenuSec msc
  WHERE  msc.Menu_Name = pv_MenuName
  AND    msc.DM_SecLevel = ''G''
  AND    msc.Ref_Id in 
           ( SELECT usg.FK_Group_ID
             FROM   T_UserGroup usg
             WHERE  usg.FK_User_ID = pn_UserID );

  IF (nAllowCnt > 0) OR nCnt = 0 THEN
    RETURN TRUE;
  ELSE
    RETURN FALSE;
  END IF;

  IF NOT FOUND THEN
    RETURN FALSE;
  END IF;

END;
' language 'plpgsql';
/

/* PROMPT ****[ End Creating Function IsMenuEnabled ]***** */

/* PROMPT **********[ Ending F_MenuSec.sql ]***************** */


