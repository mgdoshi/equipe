/* Script Name : F_Employee.sql.
   Author      : Manoj Doshi.
   Description : Functions related to the Employee Table.
   Procedures  :
   Fuctions    : 
                  GetEmployeeName for Employee_ID Returns Employee_Name.
                  GetEmployeeDesc for Employee_ID Returns Employee_Desc.
                  GetEmployeeBranchID for Employee_ID Returns Branch_ID.
                  GetEmployeeID   for Employee_Name Returns Employee_ID.

*/

/* PROMPT *****[ Starting F_Employee.sql ]***** */

/* PROMPT *****[ Dropping Function GetEmployeeName ]***** */

DROP FUNCTION GetEmployeeName( Integer );

/* PROMPT *****[ Creating Function GetEmployeeName ]***** */

Create Function GetEmployeeName ( Integer ) Returns VarChar AS '
Declare
  pn_Employee_ID ALIAS FOR $1;
  vEmployeeName VarChar( 30 );
Begin
  Select emp.Employee_Name
  Into   vEmployeeName
  From   T_Employee emp
  Where  emp.Employee_ID = pn_Employee_ID;
  IF NOT FOUND THEN
    Return Null;
  END IF;
  Return vEmployeeName;
End;
' language 'plpgsql';

/* PROMPT *****[ Dropping Function GetEmployeeDesc ]***** */

DROP FUNCTION GetEmployeeDesc( Integer );

/* PROMPT *****[ Creating Function GetEmployeeDesc ]***** */

Create Function GetEmployeeDesc( Integer ) Returns VarChar AS '
Declare
  pn_Employee_ID ALIAS FOR $1;
  vEmployeeDesc VarChar( 100 );
Begin
  Select emp.Employee_Desc
  Into   vEmployeeDesc
  From   T_Employee emp
  Where  emp.Employee_ID = pn_Employee_ID;
  IF NOT FOUND THEN
    Return Null;
  END IF;
  Return vEmployeeDesc;
End;
' language 'plpgsql';

/* PROMPT *****[ Dropping Function GetEmployeeBranchID ]***** */

DROP FUNCTION GetEmployeeBranchID( Integer );

/* PROMPT *****[ Creating Function GetEmployeeBranchID ]***** */

Create Function GetEmployeeBranchID( Integer ) Returns Integer AS '
Declare
  pn_Employee_ID ALIAS FOR $1;
  nBranchID Integer;
Begin
  Select emp.FK_Branch_ID
  Into   nBranchID
  From   T_Employee emp
  Where  emp.Employee_ID = pn_Employee_ID;
  IF NOT FOUND THEN
    Return Null;
  END IF;
  Return nBranchID;
End;
' language 'plpgsql';

/* PROMPT *****[ Dropping Function GetEmployeeID ]***** */

DROP FUNCTION GetEmployeeID( VarChar );

/* PROMPT *****[ Creating Function GetEmployeeID ]***** */

Create Function GetEmployeeID ( VarChar ) Returns Integer AS '
Declare
  pv_Employee_Name ALIAS FOR $1;
  nEmployeeID Integer;
Begin
  Select emp.Employee_ID
  Into   nEmployeeID
  From   T_Employee emp
  Where  emp.Employee_Name = pv_Employee_Name;
  IF NOT FOUND THEN
    Return Null;
  END IF;
  Return nEmployeeID;
End;
' language 'plpgsql';
/

/* *****[ Ending F_Employee.sql ]***** */
