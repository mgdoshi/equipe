/* Script Name : F_Main.sql
   Author      : Manoj Doshi.
   Description : Main Functions which must be created before creating any other plsql function.
   Procedures  :
   Fuctions    : 

*/

DROP FUNCTION plpgsql_call_handler ();
CREATE FUNCTION plpgsql_call_handler () RETURNS OPAQUE AS 
'/hd2/pgsql/lib/plpgsql.so' LANGUAGE 'C';


DROP PROCEDURAL LANGUAGE 'plpgsql';
CREATE TRUSTED PROCEDURAL LANGUAGE 'plpgsql' HANDLER
plpgsql_call_handler LANCOMPILER 'PL/pgSQL';

