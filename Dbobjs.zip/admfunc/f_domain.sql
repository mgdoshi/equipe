/* Script Name : F_Domain.sql.
   Author      : Manoj Doshi.
   Description : Functions related to the Domain Table.
   Procedures  :
   Fuctions    : 
                  GetDomainName for Domain Returns Domain_Name.
                  GetDomainAttribFrmDesc for Domain, Attrib Desc, Lang_ID
                  Returns Attribute.
                  GetDomainDescFrmAttrib for Domain, Attrib, Lang_ID
                  Returns Description.
*/

/* PROMPT *****[ Starting F_Domain.sql ]***** */

/* PROMPT *****[ Drop Function GetDomainName ]***** */

DROP FUNCTION GetDomainName( VarChar );

/* PROMPT *****[ Creating Function GetDomainName ]***** */

Create Function GetDomainName( VarChar ) Returns VarChar AS '
Declare
  pv_Domain ALIAS FOR $1;
  vDomainName VarChar( 100 );
Begin
  Select dom.Domain_Name
  Into   vDomainName
  From   T_Domain dom
  Where  dom.Domain = pv_Domain
  And    ROWNUM = 1;
  IF NOT FOUND THEN
    Return Null;
  ENF IF;
  Return vDomainName;
End;
' language 'plpgsql';

/* PROMPT *****[ Drop Function GetDomainAttribFrmDesc ]***** */

DROP FUNCTION GetDomainAttribFrmDesc( VarChar, VarChar, Integer );

/* PROMPT *****[ Creating Function GetDomainAttribFrmDesc ]***** */

Create Function GetDomainAttribFrmDesc ( VarChar, VarChar, Integer )
Returns VarChar AS '
Declare
  pv_Domain ALIAS FOR $1;
  pv_Attrib_Desc ALIAS FOR $2;
  pn_Lang_ID ALIAS FOR $3;
  vAttrib   Char(1);
Begin
  Select dom.Attrib
  Into   vAttrib
  From   T_Domain dom
  Where  dom.Domain      = pv_Domain
  And    dom.Attrib_Desc = pv_Attrib_Desc
  And    dom.FK_Lang_ID = pn_Lang_ID;
  IF NOT FOUND THEN
    Return Null;
  ENF IF;
  Return vAttrib;
End;
' language 'plpgsql';

/* PROMPT *****[ Drop Function GetDomainDescFrmAttrib ]***** */

DROP FUNCTION GetDomainDescFrmAttrib( VarChar, VarChar, Integer );

/* PROMPT *****[ Creating Function GetDomainDescFrmAttrib ]***** */

Create Function GetDomainDescFrmAttrib ( VarChar, VarChar, Integer )
Returns VarChar AS '
Declare
  pv_Domain ALIAS FOR $1;
  pv_Attrib ALIAS FOR $2;
  pn_Lang_ID ALIAS FOR $3;
  vAttribDesc VarChar( 100 );
Begin
  Select dom.Attrib_Desc
  Into   vAttribDesc
  From   T_Domain dom
  Where  dom.Domain = pv_Domain
  And    dom.Attrib = pv_Attrib
  And    dom.FK_Lang_ID = pn_Lang_ID;
  IF NOT FOUND THEN
    Return Null;
  ENF IF;
  Return vAttribDesc;
End;
' language 'plpgsql';
/

/* *****[ Ending F_Domain.sql ]***** */
