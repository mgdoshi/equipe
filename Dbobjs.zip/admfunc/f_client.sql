/*
   Script Name : F_Client.sql.
   Author      : Manoj Doshi.
   Description : Functions related to the Client Table.
   Procedures  :
   Fuctions    : 
                  GetClientName for Client_ID Returns Client_Name.
                  GetClientDesc for Client_ID Returns Client_Desc.
                  GetClientCode for Client_ID Returns ClientCode.
                  GetClientType for Client_ID Returns ClientType.
                  GetClientIDFrmName for Client_Name Returns Client_ID.
                  GetClientIDFrmCode for Client_Code Returns Client_ID.
*/

/* PROMPT *****[ Starting F_Client.sql ]***** */

/* PROMPT *****[ Drop Function GetClientName ]***** */

DROP FUNCTION GetClientName( Integer );

/* PROMPT *****[ Creating Function GetClientName ]***** */

Create Function GetClientName( Integer ) Returns VarChar AS '
Declare
  pn_Client_ID ALIAS FOR $1;
  vClientName VarChar( 30 );
Begin
  Select cln.Client_Name
  Into   vClientName
  From   T_Client cln
  Where  cln.Client_ID = pn_Client_ID;
  IF NOT FOUND THEN
    Return null;
  END IF;
  Return vClientName;
End;
' language 'plpgsql';

/* PROMPT *****[ Drop Function GetClientDesc ]***** */

DROP FUNCTION GetClientDesc( Integer );

/* PROMPT *****[ Creating Function GetClientDesc ]***** */

Create Function GetClientDesc( Integer ) Returns VarChar AS '
Declare
  pn_Client_ID ALIAS FOR $1;
  vClientDesc VarChar( 100 );
Begin
  Select cln.Client_Desc
  Into   vClientDesc
  From   T_Client cln
  Where  cln.Client_ID = pn_Client_ID;
  IF NOT FOUND THEN
    Return null;
  END IF;
  Return vClientDesc;
End;
' language 'plpgsql';

/* PROMPT *****[ Drop Function GetClientCode ]***** */

DROP FUNCTION GetClientCode( Integer );

/* PROMPT *****[ Creating Function GetClientCode ]***** */

Create Function GetClientCode( Integer ) Returns VarChar AS '
Declare
  pn_Client_ID ALIAS FOR $1;
  vClientCode VarChar( 2 );
Begin
  Select cln.Client_Code
  Into   vClientCode
  From   T_Client cln
  Where  cln.Client_ID = pn_Client_ID;
  IF NOT FOUND THEN
    Return null;
  END IF;
  Return vClientCode;
End;
' language 'plpgsql';

/* PROMPT *****[ Drop Function GetClientType ]***** */

DROP FUNCTION GetClientType( Integer );

/* PROMPT *****[ Creating Function GetClientType ]***** */

Create Function GetClientType( Integer ) Returns VarChar AS '
Declare
  pn_Client_ID ALIAS FOR $1;
  vClientType Char(1);
Begin
  Select cln.DM_ClnType
  Into   vClientType
  From   T_Client cln
  Where  cln.Client_ID = pn_Client_ID;
  IF NOT FOUND THEN
    Return null;
  END IF;
  Return vClientType;
End;
' language 'plpgsql';

/* PROMPT *****[ Drop Function GetClientIDFrmName ]***** */

DROP FUNCTION GetClientIDFrmName( VarChar );

/* PROMPT *****[ Creating Function GetClientIDFrmName ]***** */

Create Function GetClientIDFrmName ( VarChar ) Returns Integer AS '
Declare
  pv_Client_Name ALIAS FOR $1;
  nClientID Integer;
Begin
  Select cln.Client_ID
  Into   nClientID
  From   T_Client cln
  Where  cln.Client_Name = pv_Client_Name;
  IF NOT FOUND THEN
    Return null;
  END IF;
  Return nClientID;
End;
' language 'plpgsql';

/* PROMPT *****[ Drop Function GetClientIDFrmCode ]***** */

DROP FUNCTION GetClientIDFrmCode( VarChar );

/* PROMPT *****[ Creating Function GetClientIDFrmCode ]***** */

Create Function GetClientIDFrmCode ( VarChar ) Returns Integer AS '
Declare
  pv_Client_Code ALIAS FOR $1;
  nClientID Integer;
Begin
  Select cln.Client_ID
  Into   nClientID
  From   T_Client cln
  Where  cln.Client_Code = pv_Client_Code;
  IF NOT FOUND THEN
    Return Null;
  END IF;
  Return nClientID;
End;
' language 'plpgsql';
/

/* PROMPT *****[ Ending F_Client.sql ]***** */
