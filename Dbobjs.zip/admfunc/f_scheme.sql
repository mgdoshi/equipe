/* Script Name : F_Scheme.sql.
   Author      : Teena Doshi On 13th May 1999.
   Description : Functions related to the Scheme Table.
   Procedures  :
   Fuctions    : 
                 GetSchemeID         for Scheme_Name Returns Scheme_ID.
                 GetSchemeName       for Scheme_ID Returns Scheme_Name.
                 GetSchemeProperty   for pn_UserId, DM_SchemeObj Return
                 Properties.
*/

/* PROMPT *****[ Starting F_Scheme.sql ]***** */

/* PROMPT *****[ Drop Function GetSchemeID ]***** */

Drop Function GetSchemeID ( Integer );

/* PROMPT *****[ Creating Function GetSchemeID ]***** */

Create Function GetSchemeID ( Integer ) Returns Integer AS '
Declare
  pn_Scheme_Name ALIAS FOR $1;
  nSchemeID Integer;
Begin
  Select sch.Scheme_ID
  Into   nSchemeID
  From   T_Scheme sch
  Where  sch.scheme_Name = pn_Scheme_Name;

  IF NOT FOUND THEN 
    Return Null;
  END IF;

  Return nSchemeID;
End;
' language 'plpgsql';

/* PROMPT *****[ Drop Function GetSchemeName ]****** */

Drop Function GetSchemeName( Integer );

/* PROMPT *****[ Creating Function GetSchemeName ]****** */

Create Function GetSchemeName ( Integer ) Returns VarChar AS '
Declare
  pn_Scheme_ID ALIAS FOR $1;
  vSchemeName VarChar( 30 );
Begin
  Select sch.Scheme_Name
  Into   vSchemeName
  From   T_Scheme sch
  Where  sch.scheme_ID = pn_Scheme_ID;

  IF NOT FOUND THEN 
    Return Null;
  END IF;

  Return vSchemeName;
End;
' language 'plpgsql';

/* PROMPT *****[ Drop Function GetSchemeProperty ]***** */

Drop Function GetSchemeProperty( Integer, Char, Char);

/* PROMPT *****[ Creating Function GetSchemeProperty ]***** */

Create Function GetSchemeProperty ( Integer, Char, Char )
Returns VarChar AS '
Declare
  pn_Scheme_ID  ALIAS FOR $1;
  pc_DM_ObjType ALIAS FOR $2;
  pc_DM_OpMode  ALIAS FOR $3;
  vProperty VarChar(32767);
Begin  
  SELECT scr.Prop1  || '' '' || scr.Prop2  || '' '' ||
         scr.Prop3  || '' '' || scr.Prop4  || '' '' ||
         scr.Prop5  || '' '' || scr.Prop6  || '' '' ||
         scr.Prop7  || '' '' || scr.Prop8  || '' '' ||
         scr.Prop9  || '' '' || scr.Prop10 || '' '' ||
         scr.Prop11 || '' '' || scr.Prop12 || '' '' ||
         scr.Prop13 || '' '' || scr.Prop14 || '' '' ||
         scr.Prop15 || '' '' || scr.Prop16 || '' '' ||
         scr.Prop17 || '' '' || scr.Prop18 || '' '' ||
         scr.Prop19 || '' '' || scr.Prop20
  INTO   vProperty
  FROM   T_SchemeRef scr
  WHERE  scr.FK_Scheme_ID = pn_Scheme_ID
  AND    scr.DM_ObjType   = pc_DM_ObjType
  AND    scr.DM_OpMode    = pc_DM_OpMode;

  IF NOT FOUND THEN 
    Return Null;
  END IF;

  Return vProperty;
End;
' language 'plpgsql';
/

/* PROMPT *****[ Ending F_Scheme.sql ]***** */
