/* PROMPT *****[ Starting F_UserParam.sql ]***** */

/* PROMPT *****[ Creating Function GetUserSpecParamName ]***** */

Create Function GetUserSpecParamValue ( Integer, VarChar ) Returns VarChar AS '
Declare
  pn_User_ID ALIAS FOR $1;
  pv_UserParam_Name ALIAS FOR $2;
  vUserParamValue VarChar( 100 );
Begin
  Select usp.UserParam_Value
  Into   vUserParamValue
  From   T_UserParam usp
  Where  usp.FK_User_ID = pn_User_ID
  And    usp.UserParam_Name = pv_UserParam_Name;

  IF NOT FOUND THEN
    Return Null;
  END IF;

  Return vUserParamValue;

End;
' language 'plpgsql';
/
