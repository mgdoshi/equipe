/* Script Name : F_Trans.sql.
   Author      : Manoj Doshi.
   Description : Functions related to the T_Trans Table.
   Procedures  :
   Functions   : 
                  1. GetTransID for pn_AuditID, pc_TransType Returns Trans_ID
                  2. SetTransID for pn_AuditID  Returns Trans_ID
                  3. GetRptTableID for pn_AuditID Returns RptTable_ID
                  4. SetRptTableID for pn_AuditID Returns Trans_ID
                  5. CheckTransValidity for pn_AuditID Returns 'OK' or 'ERROR'
*/

/* PROMPT **********[ Starting F_Trans.sql ]*************** */

/* PROMPT *******[ Drop Function GetTransID ]********** */

Drop Function GetTransID ( Integer, Char );

/* PROMPT *******[ Creating Function GetTransID ]********** */

CREATE FUNCTION GetTransID ( Integer, Char ) Returns Integer AS '
Declare
  pn_Audit_ID ALIAS FOR $1;
  pc_TransType ALIAS FOR $2;
  nTransID Integer;
BEGIN  

  INSERT INTO T_Trans
   ( Trans_ID, Trans_Type, Trans_Status, Fk_Audit_ID ) 
  VALUES
   ( GetTransSeq(), pc_TransType, ''O'', pn_Audit_ID );

  COMMIT;

  IF NOT FOUND THEN
    Return Null;
  END IF;

  RETURN nTransID;

END;
' language 'plpgsql';

/* PROMPT *******[ Drop Function SetTransID ]****** */

Drop Function SetTransID ( Integer );

/* PROMPT *******[ Creating Function SetTransID ]********** */

CREATE FUNCTION SetTransID ( Integer ) RETURNS Integer AS '
Declare
  pn_Trans_ID ALIAS FOR $1;
BEGIN  
  UPDATE T_Trans
    SET  Trans_Status = ''F''
  WHERE  Trans_ID = pn_Trans_ID;

  COMMIT;

  IF NOT FOUND THEN
    Return Null;
  END IF;

  RETURN pn_Trans_Id; 
END;
' language 'plpgsql';

/* PROMPT *******[ Drop Function CheckTransValidity ]****** */

Drop Function CheckTransValidity( Integer );

/* PROMPT *******[ Creating Function CheckTransValidity ]********** */

CREATE FUNCTION CheckTransValidity( Integer ) RETURNS VarChar AS ' 
Declare
  pn_Trans_ID ALIAS FOR $1;
  cTransType Char;
  cTransStat Char;
BEGIN  
  SELECT trn.Trans_Type, trn.Trans_Status
  INTO   cTransType, cTransStat
  FROM   T_Trans trn
  WHERE  trn.Trans_ID = pn_Trans_ID;

  IF cTransType = ''Q''
  THEN 
    RETURN ''OK'';
  ELSIF cTransType = ''M''
  THEN
    IF cTransStat = ''O''
    THEN
      RETURN ''OK'';
    ELSIF cTransStat = ''F''
    THEN
      RETURN ''ERROR'';
    END IF;
  END IF;
  IF NOT FOUND THEN
    RETURN ''ERROR''; 
  END IF;
END;
' language 'plpgsql';

/* PROMPT *******[ Drop Function GetRptTableID ]********** */

Drop Funtion GetRptTableID( Integer );

/* PROMPT *******[ Creating Function GetRptTableID ]********** */

CREATE FUNCTION GetRptTableID ( Integer ) RETURNS Integer AS '
Declare
  pn_Trans_ID ALIAS FOR $1;
  nRptTableID Integer;
BEGIN  
  SELECT trn.RptTableID
  INTO   nRptTableID
  FROM   T_Trans trn
  WHERE  trn.Trans_ID = pn_Trans_ID; 
 
  IF NOT FOUND THEN
    RETURN Null;
  END IF;

  RETURN nRptTableID;   
END;
' language 'plpgsql';

/* PROMPT *******[ Drop Function SetRptTableID ]********** */

Drop Function SetRptTableID ( Integer, Integer );
  
/* PROMPT *******[ Creating Function SetRptTableID ]********** */

CREATE FUNCTION SetRptTableID ( Integer, Integer ) RETURNS Integer AS ' 
Declare
  pn_Trans_ID    ALIAS FOR $1;
  pn_RptTable_ID ALIAS FOR $2;
BEGIN  
  UPDATE T_Trans
  SET    RptTableID = pn_RptTable_ID
  WHERE  Trans_ID = pn_Trans_ID;

  COMMIT;

  IF NOT FOUND THEN
    Return Null;
  END IF;

  RETURN pn_Trans_ID;
END;
' language 'plpgsql';
/

/* PROMPT*****[ End of file F_trans.sql]***** */


