/* Script Name : F_ItemClass.sql.
   Author      : Manoj Doshi.
   Description : Functions related to the ItemClass Table.
   Procedures  :
   Fuctions    : 
                  GetItemClassName for ItemClass_ID Returns ItemClass_Name.
                  GetItemClassDesc for ItemClass_ID Returns ItemClass_Desc.
                  GetItemClassID   for ItemClass_Name Returns ItemClass_ID.

*/

/* PROMPT *****[ Starting F_ItemClass.sql ]***** */

/* PROMPT*****[ Drop Function GetItemClassName ]***** */

Drop Function GetItemClassName( Integer );

/* PROMPT *****[ Creating Function GetItemClassName ] **** */

Create Function GetItemClassName( Integer ) Returns VarChar As '
Declare 
  pn_ItemClass_ID Alias For $1;
  vItemClassName VarChar( 30 );
Begin
  Select itc.ItemClass_Name
  Into   vItemClassName
  From   T_ItemClass itc
  Where  itc.ItemClass_ID = pn_ItemClass_ID;
  If NOT FOUND Then
    Return null;
  End If;
  Return vItemClassName;
End;
' language 'plpgsql';

/* PROMPT *****[ Drop Function GetItemClassDesc ]***** */

Drop Function GetItemClassDesc( Integer );

/* PROMPT ****[ Creating Function GetItemClassDesc ]***** */

Create Function GetItemClassDesc( Integer ) Returns VarChar As '
Declare
  pn_ItemClass_ID Alias For $1;
  vItemClassDesc VarChar( 100 );
Begin
  Select itc.ItemClass_Desc
  Into   vItemClassDesc
  From   T_ItemClass itc
  Where  itc.ItemClass_ID = pn_ItemClass_ID;
  If NOT FOUND Then
    Return null;
  End If;
  Return vItemClassDesc;
End;
' language 'plpgsql';

/* PROMPT *****[ Drop Function GetItemClassID ] **** */ 

Drop Function GetItemClassID ( VarChar );

/* PROMPT *****[ Creating Function GetItemClassID ] **** */

Create Function GetItemClassID ( VarChar ) Returns Integer As '
Declare 
  pv_ItemClass_Name Alias For $1;
  nItemClassID Integer;
Begin
  Select itc.ItemClass_ID
  Into   nItemClassID
  From   T_ItemClass itc
  Where  itc.ItemClass_Name = pv_ItemClass_Name;
  If NOT FOUND Then
    Return null;
  End If;
  Return nItemClassID;
End;
' language 'plpgsql';
/


/* *****[ Ending F_ItemClass.sql ]***** */
