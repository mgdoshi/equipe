/* Script Name : F_Audit.sql.
   Author      : Manoj Doshi.
   Description : Functions related to the T_Audit Table.
   Procedures  :
   Functions   : 
                   1. GetLoginInfo for pc_Info, pn_AuditID Returns Login Time
                   2. GetLogoutInfo for pc_Info, pn_AuditID Returns Login Time
                   3. GetNodeIPAddress for pn_AuditID Returns Node_IP_Addr
                   4. GetCurrentUser  for pn_AuditID Returns Fk_User_ID
                   5. GetCurrentEmployee for pn_AuditID Returns Fk_Employee_ID
                   6. GetCurrentClient for pn_AuditID Returns Fk_Client_ID
                   7. GetCurrentUserLang for pn_AuditID Returns Fk_Lang_ID
                   8. GetCurrentRecSec for pn_AuditID Returns Fk_RecSec_ID
*/

/* PROMPT **********[ Starting F_Audit.sql ]*************** */

/* PROMPT *****[ Drop Function GetLoginInfo ]********** */

Drop Function GetLoginInfo( Char, Integer );

/* PROMPT *****[ Creating Function GetLoginInfo ]********** */

CREATE FUNCTION GetLoginInfo( Char, Integer ) RETURNS Date AS '
Declare
  pc_Info ALIAS FOR $1;
  pn_Audit_ID ALIAS FOR $2;
  dDate Date;
BEGIN
  IF pc_Info = ''T'' THEN
    SELECT To_Char(aud.Login_Dt, ''HH:MI:SS AM'')
    INTO   dDate
    FROM   T_Audit aud
    WHERE  aud.Audit_ID = pn_Audit_ID;
  ELSE
    SELECT To_Char(aud.Login_dt, ''DD.MM.YYYY'')
    INTO   dDate
    FROM   T_Audit aud
    WHERE  aud.Audit_ID = pn_Audit_ID;
  END IF;
  IF NOT FOUND THEN
    RETURN null;
  END IF;
  RETURN dDate;
End;
' language 'plpgsql';

/* PROMPT *****[ Drop Function GetLogoutInfo ]********** */

Drop Function GetLogoutInfo( Char, Integer );

/* PROMPT *****[ Creating Function GetLogoutInfo ]********** */

CREATE FUNCTION GetLogoutInfo( Char, Integer ) RETURNS Date AS '
Declare
  pc_Info ALIAS FOR $1;
  pn_Audit_ID ALIAS FOR $2; 
  dDate Date;
BEGIN
  IF pc_Info = ''T'' THEN
    SELECT To_Char(aud.Logout_dt, ''HH:MI:SS AM'')
    INTO   dDate
    FROM   T_Audit aud
    WHERE  aud.Audit_ID = pn_Audit_ID;
  ELSE
    SELECT To_Char(aud.Logout_dt, ''DD.MM.YYYY'')
    INTO   dDate
    FROM   T_Audit aud
    WHERE  aud.Audit_ID = pn_Audit_ID;
  END IF;
  IF NOT FOUND THEN
    RETURN null;
  END IF;
  RETURN dDate;
End;
' language 'plpgsql';

/* PROMPT *****[ Drop Function GetNodeIPAddress ]********** */

Drop Function GetNodeIPAddress( Integer );

/* PROMPT *****[ Creating Function GetNodeIPAddress ]********** */

CREATE FUNCTION GetNodeIPAddress( Integer ) RETURNS VarChar AS '
Declare
  pn_AuditID ALIAS FOR $1;
  vNodeIPAddr VarChar(100);
BEGIN
  SELECT aud.Node_IP_Addr
  INTO   vNodeIPAddr
  FROM   T_Audit aud
  WHERE  aud.Audit_Id = pn_AuditId;
  IF NOT FOUND  THEN
    RETURN null;
  END IF;
  RETURN vNodeIPAddr;
End;
' language 'plpgsql';

/* PROMPT *****[ Drop Function GetCurrentUser ]********** */

Drop Function GetCurrentUser( Integer );

/* PROMPT *****[ Creating Function GetCurrentUser ]********** */

CREATE FUNCTION GetCurrentUser( Integer ) RETURNS Integer AS '
DECLARE
  pn_Audit_ID ALIAS FOR $1;
  nUserID Integer;
BEGIN
  SELECT aud.Fk_User_ID
  INTO   nUserID
  FROM   T_Audit aud
  WHERE  aud.Audit_ID = pn_Audit_ID;
  IF NOT FOUND  THEN
    RETURN null;
  END IF;
  RETURN nUserID;
End;
' language 'plpgsql';

/* PROMPT *****[ Drop Function GetCurrentEmployee ]********** */

Drop Function GetCurrentEmployee( Integer );

PROMPT *****[ Creating Function GetCurrentEmployee ]**********

CREATE FUNCTION GetCurrentEmployee( Integer ) RETURNS Integer AS '
Declare
  pn_Audit_ID ALIAS FOR $1;
  nEmployeeID Integer;
BEGIN
  SELECT GetEmployeeForUser( aud.Fk_User_ID )
  INTO   nEmployeeID
  FROM   T_Audit aud
  WHERE  aud.Audit_ID = pn_Audit_ID;
  IF NOT FOUND  THEN
    RETURN null;
  END IF;
  RETURN nEmployeeID;
End;
' language 'plpgsql';

/* PROMPT *****[ Drop Function GetCurrentClient ]********** */

Drop Function GetCurrentClient( Integer );

/* PROMPT *****[ Creating Function GetCurrentClient ]********** */

CREATE FUNCTION GetCurrentClient( Integer ) RETURNS Integer AS '
Declare 
  pn_Audit_ID ALIAS FOR $1;
  nClientID Integer;
BEGIN
  SELECT GetClientForUser( aud.Fk_User_ID )
  INTO   nClientID
  FROM   T_Audit aud
  WHERE  aud.Audit_ID = pn_Audit_ID;
  IF NOT FOUND  THEN
    RETURN null;
  END IF;
  RETURN nClientID;
End;
' language 'plpgsql';

/* PROMPT *****[ Drop Function GetCurrentUserLang ]********** */

Drop Function GetCurrentUserLang( Integer );

/* PROMPT *****[ Creating Function GetCurrentUserLang ]********** */

CREATE FUNCTION GetCurrentUserLang( Integer ) RETURNS Integer AS ' 
Declare
  pn_Audit_ID ALIAS FOR $1;
  nLangID Integer;
BEGIN
  SELECT GetUserLang( aud.Fk_User_ID )
  INTO   nLangID
  FROM   T_Audit aud
  WHERE  aud.Audit_ID = pn_Audit_ID;
  IF NOT FOUND  THEN
    RETURN null;
  END IF;
  RETURN nLangID;
End;
' language 'plpgsql';

/* PROMPT *****[ Drop Function GetCurrentRecSec ]********** */

Drop Function GetCurrentRecSec( Integer );

/* PROMPT *****[ Creating Function GetCurrentRecSec ]********** */

CREATE FUNCTION GetCurrentRecSec( Integer ) RETURNS Integer AS '
Declare
  pn_Audit_ID ALIAS FOR $1;
  nRecSecID Integer;
BEGIN
  SELECT GetRecSecForUser( aud.Fk_User_ID )
  INTO   nRecSecID
  FROM   T_Audit aud
  WHERE  aud.Audit_ID = pn_Audit_ID;
  IF NOT FOUND  THEN
    RETURN null;
  END IF;
  RETURN nRecSecID;
End;
' language 'plpgsql';
/

/* PROMPT ***********[ End of file F_Audit]******************** */
