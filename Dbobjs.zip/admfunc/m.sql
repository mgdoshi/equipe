
/* PROMPT *****[ Starting F_User.sql ]***** */

/* PROMPT *****[ Creating Function GetUserName ]***** */

Create Function GetUserName ( Integer ) Returns VarChar AS '
Declare
  pn_User_ID ALIAS FOR $1;
  vUserName VarChar( 30 );
Begin
  Select usr.User_Name
  Into   vUserName
  From   T_User usr
  Where  usr.User_ID = pn_User_ID;

  IF NOT FOUND THEN
    Return Null;
  END IF;

  Return vUserName;

End;
' language 'plpgsql';

/* PROMPT *****[ Creating Function GetUserDesc ]***** */

Create Function GetUserDesc ( Integer ) Returns VarChar AS '
Declare
  pn_User_ID ALIAS FOR $1;
  vUserDesc VarChar( 100 );
Begin
  Select usr.User_Desc
  Into   vUserDesc
  From   T_User usr
  Where  usr.User_ID = pn_User_ID;

  IF NOT FOUND THEN
    Return Null;
  END IF;

  Return vUserDesc;

End;
' language 'plpgsql';

/* PROMPT *****[ Creating Function GetUserID ]***** */

Create Function GetUserID ( VarChar ) Returns Integer AS '
Declare
  pv_User_Name ALIAS FOR $1;
  nUserID Integer;
Begin

  Select usr.User_ID
  Into   nUserID
  From   T_User usr
  Where  usr.User_Name = pv_User_Name;

  IF NOT FOUND THEN
    Return Null;
  END IF;

  Return nUserID;

End;
' language 'plpgsql';

/* PROMPT *****[ Creating Function GetUserLang ]***** */

Create Function GetUserLang ( Integer ) Returns Integer AS '
Declare
  pn_User_ID ALIAS FOR $1;
  nLangID Integer;
Begin
  Select usr.FK_Lang_ID
  Into   nLangID
  From   T_User usr
  Where  usr.User_ID = pn_User_ID;

  IF NOT FOUND THEN
    Return Null;
  END IF;

  Return nLangID;

End;
' language 'plpgsql';

/* PROMPT *****[ Creating Function GetUserScheme ]***** */

Create Function GetUserScheme ( Integer ) Returns Integer AS '
Declare
  pn_User_ID ALIAS FOR $1;
  nSchemeID Integer;
Begin
  Select usr.FK_Scheme_ID
  Into   nSchemeID
  From   T_User usr
  Where  usr.User_ID = pn_User_ID;

  IF NOT FOUND THEN
    Return Null;
  END IF;

  Return nSchemeID;

End;
' language 'plpgsql';

/* PROMPT *****[ Creating Function IsUserValid ]***** */

Create Function IsUserValid ( Integer) Returns Boolean AS '
Declare
  pn_User_ID ALIAS FOR $1;
  bRetval Boolean := FALSE;
  
  DECLARE c_User CURSOR
     FOR Select usr.User_Name
         From T_User usr
         Where  User_ID = pn_User_ID;
  vUserName  VarChar(30); 
Begin
  Open c_User;
  Loop
    Fetch c_User into vUserName;   
    Exit;
  End Loop;
  bRetVal := (c_User%FOUND);
  Close c_User;

  Return bRetVal;
  
  IF NOT FOUND THEN
    bRetval  := FALSE; 
    Return bRetval;
  END IF;

End;
' language 'plpgsql';

/* PROMPT *****[ Creating Function EncryptString ]***** */

CREATE FUNCTION EncryptString ( VarChar ) RETURNS VarChar AS '
Declare
  pv_String ALIAS FOR $1;
  vRetString VarChar(100) DEFAULT NULL; 
Begin
  vRetString := TRANSLATE ( pv_String ,
                            ''0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ'' ||
                            ''abcdefghijklmnopqrstuvwxyz'' ,
                            ''9876543210zyxwvutsrqponmlkjihgfedcba'' ||
                            ''ZYXWVUTSRQPONMLKJIHGFEDCBA'' );

  RETURN vRetString;

  IF NOT FOUND THEN
    vRetString := Null;
    Return vRetString;
  END IF;

End;
' language 'plpgsql';

/* PROMPT *****[ Creating Function DecryptString ]***** */

CREATE FUNCTION DecryptString ( VarChar ) RETURNS VarChar AS '
Declare
  pv_String ALIAS FOR $1;
  vRetString VarChar(100) DEFAULT NULL; 
Begin
  vRetString := TRANSLATE ( pv_String ,
                            ''9876543210zyxwvutsrqponmlkjihgfedcba'' ||
                            ''ZYXWVUTSRQPONMLKJIHGFEDCBA'' ,
                            ''0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ'' ||
                            ''abcdefghijklmnopqrstuvwxyz'' );

  RETURN vRetString;
 
  IF NOT FOUND THEN
    vRetString := Null;
    Return vRetString;
  END IF;

End;
' language 'plpgsql';

/* PROMPT *****[ Creating Function ChangeUserPassword ]***** */

Create Function ChangeUserPassword ( Integer, VarChar, VarChar ) RETURNS BOOLEAN AS '
Declare
  pn_User_ID ALIAS FOR $1;
  pv_OldPasswd ALIAS FOR $2;
  pv_NewPasswd ALIAS FOR $3;
  bRetval    Boolean DEFAULT FALSE;
  vUserPass  VarChar(30);
  nLen       Integer := CHAR_LENGTH(pv_NewPasswd);
Begin

  IF nLen > 30 THEN
    RETURN FALSE;
  END IF;

  IF IsUserValid ( pn_User_ID ) THEN
    Select usr.User_Pass
    Into   vUserPass
    From   T_User usr
    Where  usr.User_ID = pn_User_ID;

    IF NVL(vUserPass,''~'') = NVL(EncryptString(pv_OldPasswd),''~'') THEN
       UPDATE T_User
       SET User_Pass = EncryptString(pv_NewPasswd)
       Where User_ID = pn_User_ID;

       bRetval  := TRUE;
       COMMIT;
    ELSE
        bRetval  := FALSE;
    END IF;
  ELSE
    bRetval  := FALSE;
    
  END IF;
  Return bRetval; 

  IF NOT FOUND Then
    bRetval  := FALSE;
    Return bRetval;
  END IF;

End;
' language 'plpgsql';

/* PROMPT *****[ Creating Function GetClientForUser ]***** */

CREATE FUNCTION GetClientForUser ( Integer ) RETURNS Integer AS '
Declare
  pn_User_ID ALIAS FOR $1;
  nClientID Integer;
BEGIN
  SELECT usr.FK_Client_ID
  INTO   nClientID
  FROM   T_User usr
  WHERE  usr.User_ID = pn_User_ID;

  RETURN nClientID;

  IF NOT FOUND THEN
    RETURN Null;
  END IF;

End;
' language 'plpgsql';

/* PROMPT *****[ Creating Function GetEmployeeForUser ]***** */

CREATE FUNCTION GetEmployeeForUser ( Integer ) RETURNS Integer AS '
Declare
  pn_User_ID ALIAS FOR $1;
  nEmpID Integer;
BEGIN
  SELECT usr.FK_Employee_ID
  INTO   nEmpID
  FROM   T_User usr
  WHERE  usr.User_ID = pn_User_ID;

  RETURN nEmpID;

  IF NOT FOUND THEN
    RETURN Null;
  END IF;

End;
' language 'plpgsql';

/* PROMPT *****[ Creating Function GetRecSecForUser ]***** */

CREATE FUNCTION GetRecSecForUser ( Integer ) RETURNS Integer AS '
Declare
  pn_User_ID ALIAS FOR $1;
  nRecSecID Integer;
BEGIN
  SELECT usr.FK_RecSec_ID
  INTO   nRecSecID
  FROM   T_User usr
  WHERE  usr.User_ID = pn_User_ID;

  RETURN nRecSecID;

  IF NOT FOUND THEN
    RETURN Null;
  END IF;

End;
' language 'plpgsql';

/* PROMPT *****[ Creating Function GetUserSchemeID ]***** */

CREATE FUNCTION GetUserSchemeID ( Integer ) RETURNS Integer AS '
Declare
  pn_User_ID ALIAS FOR $1;
  nSchemeID Integer;
BEGIN
  SELECT usr.FK_Scheme_ID
  INTO   nSchemeID
  FROM   T_User usr
  WHERE  usr.User_ID = pn_User_ID;

  RETURN nSchemeID;

  IF NOT FOUND THEN
    RETURN Null;
  END IF;

End;
' language 'plpgsql';

/* PROMPT *****[ Creating Function IsLoginValid ]***** */

CREATE FUNCTION IsLoginValid ( VarChar, VarChar ) RETURNS Boolean AS '
Declare
  pv_User_Name ALIAS FOR $1;
  pv_User_Pass ALIAS FOR $2;
  nUserID Integer;
BEGIN
  SELECT usr.User_ID 
  INTO   nUserID
  FROM   T_User usr
  WHERE  usr.User_Name = pv_User_Name
  AND    ( pv_User_Pass ISNULL OR usr.User_Pass = pv_User_Pass );

  RETURN TRUE;

  IF NOT FOUND THEN
    RETURN Null;
  END IF;

End;
' language 'plpgsql';

/* PROMPT *****[ Creating Function GetUserPass ]***** */

Create Function GetUserPass ( Integer ) Returns VarChar AS '
Declare
  pn_User_ID ALIAS FOR $1;
  vUserPass VarChar( 100 );
Begin
  Select DecryptString(usr.User_Pass)
  Into   vUserPass
  From   T_User usr
  Where  usr.User_ID = pn_User_ID;

  Return vUserPass;

  IF NOT FOUND THEN
    RETURN Null;
  END IF;

End;
' language 'plpgsql';
/

/* PROMPT *****[ Ending F_User.sql ]***** */
