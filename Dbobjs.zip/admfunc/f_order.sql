/*
   Script Name : F_Order.sql.
   Author      : Manoj Doshi.
   Description : Functions related to the Order Table.
   Procedures  :
   Fuctions    : 
                  1. GetOrderIDForOrderNo for Order_No Returns Order_ID.
                  2. GetOrderStatus       for Order_ID Returns DM_OrdStat
*/

/* PROMPT *****[ Starting F_Order.sql ]***** */

/* PROMPT *****[ Drop Function GetOrderIDForOrderNo ]***** */

Drop Function GetOrderIDForOrderNo( VarChar );

/* PROMPT *****[ Creating Function GetOrderIDForOrderNo ]***** */

Create Function GetOrderIDForOrderNo( VarChar ) Returns Integer AS '
Declare
  pn_Order_Nr ALIAS FOR $1;
  nOrderID Integer;
Begin
  Select ord.Order_ID
  Into   nOrderID
  From   T_Order ord
  Where  ord.Order_Nr LIKE pn_Order_Nr;
  
  IF NOT FOUND THEN
    Return Null;
  END IF;

  Return nOrderID;
End;
' language 'plpgsql';

/* PROMPT *****[ Drop Function GetOrderStatus ]***** */

Drop Function GetOrderStatus( Integer );

/* PROMPT *****[ Creating Function GetOrderStatus ]***** */

Create Function GetOrderStatus( Integer ) Returns Char AS '
Declare
  pn_Order_ID ALIAS FOR $1;
  cDMOrdStat Char(1);
Begin
  Select ord.DM_OrdStat
  Into   cDMOrdStat
  From   T_Order ord
  Where  ord.Order_ID = pn_Order_ID;
  IF NOT FOUND THEN
    Return Null;
  END IF;

  Return cDMOrdStat;
End;
' language 'plpgsql';
/

/* PROMPT *****[ Ending F_Order.sql ]***** */