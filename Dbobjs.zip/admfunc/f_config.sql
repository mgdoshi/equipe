/* Script Name : F_Config.sql.
   Author      : Manoj Doshi. on 15th May 1999
   Description : Functions related to the Config Table.
   Procedures  :
   Functions   : 
                 1. GetConfigValue for Parent_Obj, Fk_Lang_ID and Obj_Name 
                    returns Property_Value
*/

/* PROMPT *****[ Starting F_Config.sql ]***** */

/* PROMPT *****[ Drop Function GetConfigValue ]***** */

DROP FUNCTION GetConfigValue( VarChar, Integer, VarChar );

/* PROMPT *****[ Creating Function GetConfigValue ]***** */

CREATE FUNCTION GetConfigValue( VarChar, Integer, VarChar ) RETURNS VarChar AS '
Declare
  pv_ParentObj ALIAS FOR $1;
  pn_LangID ALIAS FOR $2;
  pv_ObjName ALIAS FOR $3;
  vConfig VarChar(100);
BEGIN
  SELECT cnf.Property_Value
  INTO   vConfig
  FROM   T_Config cnf
  WHERE  cnf.parent_obj = pv_ParentObj
  AND    cnf.obj_name   = pv_ObjName
  AND    cnf.fk_lang_id = pn_LangID;
  IF NOT FOUND THEN
    RETURN Null;
  END IF;
  RETURN vConfig;
END;
' language 'plpgsql';
/
/* Prompt *********[ End of F_Config.sql File ]***************** */
