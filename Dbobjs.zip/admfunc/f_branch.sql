/*
   Script Name : F_Branch.sql.
   Author      : Manoj Doshi.
   Description : Functions related to the Branch Table.
   Procedures  :
   Functions   : 
                  GetBranchName for Branch_ID   Returns Branch_Name.
                  GetBranchDesc for Branch_ID   Returns Branch_Desc.
                  GetBranchID   for Branch_Name Returns Branch_ID.
*/

/* PROMPT *****[ Starting F_Branch.sql ]***** */

/* PROMPT *****[ Drop Function GetBranchName ]********** */

Drop Function GetBranchName( Integer );

/* PROMPT *****[ Creating Function GetBranchName ]***** */

Create Function GetBranchName( Integer ) Returns VarChar AS '
Declare
  pn_Branch_ID ALIAS FOR $1;
  vBranchName VarChar( 100 );
Begin
  Select brn.Branch_Name
  Into   vBranchName
  From   T_Branch brn
  Where  brn.Branch_ID = pn_Branch_ID; 
  IF NOT FOUND THEN
    RETURN null;
  END IF;
  Return vBranchName;
End;
' language 'plpgsql';

/* PROMPT *****[ Drop Function GetBranchDesc ]********** */

Drop Function GetBranchDesc( Integer );

/* PROMPT *****[ Creating Function GetBranchDesc ]***** */

Create Function GetBranchDesc( Integer ) Returns VarChar AS '
Declare
  pn_Branch_ID ALIAS FOR $1;
  vBranchDesc VarChar( 100 );
Begin
  Select brn.Branch_Desc
  Into   vBranchDesc
  From   T_Branch brn
  Where  brn.Branch_ID = pn_Branch_ID;
  IF NOT FOUND THEN
    RETURN null;
  END IF;
  Return vBranchDesc;
End;
' language 'plpgsql';

/* PROMPT *****[ Drop Function GetBranchID ]********** */

Drop Function GetBranchID( VarChar );

/* PROMPT *****[ Creating Function GetBranchID ]***** */

Create Function GetBranchID( VarChar ) Returns Integer AS '
Declare
  pv_Branch_Name ALIAS FOR $1;  
  nBranchID Integer;
Begin
  Select brn.Branch_ID
  Into   nBranchID
  From   T_Branch brn
  Where  brn.Branch_Name = pv_Branch_Name;
  IF NOT FOUND THEN
    RETURN null;
  END IF;
  Return nBranchID;
End;
' language 'plpgsql';
/

/* PROMPT *****[ Ending F_Branch.sql ]***** */
