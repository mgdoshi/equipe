/* Script Name : F_Param.sql.
   Author      : Manoj Doshi.
   Description : Functions related to the Param Table.
   Procedures  :
   Fuctions    : 
                  GetParamValue for Param_Name Returns Param Value.
                  GetParamType for Param_ID Returns Param Type.
                  GetParamClass for Param_ID Returns Param Class.
*/

/* PROMPT *****[ Starting F_Param.sql ]***** */

/* PROMPT *****[ Drop Function GetParamValue ]***** */

Drop Function GetParamValue( VarChar );

/* PROMPT *****[ Creating Function GetParamValue ]***** */

Create Function GetParamValue( VarChar ) Returns VarChar AS '
Declare
  pv_Param_Name ALIAS FOR $1;
  vParamValue VarChar( 100 );
Begin
  Select par.Param_Value
  Into   vParamValue
  From   T_Param par
  Where  par.Param_Name = pv_Param_Name;

  IF NOT FOUND THEN
    Return Null;
  END IF;
  Return vParamValue;
End;
' language 'plpgsql';

/* PROMPT *****[ Drop Function GetParamType ]***** */

Drop Function GetParamType( Integer );

/* PROMPT *****[ Creating Function GetParamType ]***** */

Create Function GetParamType( Integer ) Returns Char AS '
Declare
  pn_Param_ID ALIAS FOR $1;
  vParamType Char(1);
Begin
  Select par.DM_ParType
  Into   vParamType
  From   T_Param par
  Where  par.Param_ID = pn_Param_ID;

  IF NOT FOUND THEN
    Return Null;
  END IF;

  Return vParamType;
End;
' language 'plpgsql';

/* PROMPT *****[ Drop Function GetParamClass ]***** */

Drop Function GetParamClass( Integer );

/* PROMPT *****[ Creating Function GetParamClass ]***** */

Create Function GetParamClass( Integer ) Returns Char AS '
Declare
  pn_Param_ID ALIAS FOR $1;
  vParamClass Char(1);
Begin
  Select par.DM_ParClass
  Into   vParamClass
  From   T_Param par
  Where  par.Param_ID = pn_Param_ID;

  IF NOT FOUND THEN
    Return Null;
  END IF;

  Return vParamClass;
End;
' language 'plpgsql';
/

/* PROMPT *****[ Ending F_Param.sql ]***** */
