/* Script Name : F_Lang.sql.
   Author      : Manoj Doshi.
   Description : Functions related to the Lang Table.
   Procedures  :
   Fuctions    : 
                  GetLangName for Lang_ID Returns Lang_Name.
                  GetLangDesc for Lang_ID Returns Lang_Desc.
                  GetLangID   for Lang_Name Returns Lang_ID.
*/

/* PROMPT *****[ Starting F_Lang.sql ]***** */

/* PROMPT *****[ Drop Function GetLangName ]**** */

Drop Function GetLangName ( Integer );

/* PROMPT *****[ Creating Function GetLangName ]***** */

Create Function GetLangName ( Integer ) Returns VarChar AS '
Declare
  pn_Lang_ID ALIAS FOR $1;
  vLangName VarChar( 3 );
Begin
  Select lan.Lang_Name
  Into   vLangName
  From   T_Lang lan
  Where  lan.Lang_ID = pn_Lang_ID;
  IF NOT FOUND THEN
    Return Null;
  END IF;
  Return vLangName;
End;
' language 'plpgsql';

/* PROMPT *****[ Drop Function GetLangDesc ]***** */

Drop Function GetLangDesc( Integer );

/* PROMPT *****[ Creating Function GetLangDesc ]***** */

Create Function GetLangDesc ( Integer ) Returns VarChar AS '
Declare
  pn_Lang_ID ALIAS FOR $1;
  vLangDesc VarChar( 100 );
Begin
  Select lan.Lang_Desc
  Into   vLangDesc
  From   T_Lang lan
  Where  lan.Lang_ID = pn_Lang_ID;
  IF NOT FOUND THEN
    Return Null;
  END IF; 
  Return vLangDesc;
End;
' language 'plpgsql';

/* PROMPT *****[ Drop Function GetLangID ]***** */

Drop Function GetLangID ( VarChar );

/* PROMPT *****[ Creating Function GetLangID ]***** */

Create Function GetLangID ( VarChar ) Returns Integer AS '
Declare
  pv_Lang_Name ALIAS FOR $1;
  nLangID Number;
Begin
  Select lan.Lang_ID
  Into   nLangID
  From   T_Lang lan
  Where  lan.Lang_Name = pv_Lang_Name;
  IF NOT FOUND THEN
    Return Null;
  END IF;   
  Return nLangID;
End;
' language 'plpgsql';
/

/* PROMPT *****[ Ending F_Lang.sql ]***** */
