/* Script Name : F_Msg.sql.
   Author      : Manoj Doshi.
   Description : Functions related to the Msg Table.
   Procedures  :
   Fuctions    : 
                  GetMsgDesc for Msg_ID, Lang_ID Returns Msg_Desc.
*/

/* PROMPT *****[ Starting F_Msg.sql ]***** */

/* PROMPT *****[ Drop Function GetMsgDesc ] ***** */

DROP FUNCTION GetMsgDesc( Integer, Integer );

/* PROMPT *****[ Creating Function GetMsgDesc ]***** */

Create Function GetMsgDesc( Integer, Integer ) Returns VarChar AS '
Declare  
  pn_Msg_ID  ALIAS FOR $1;
  pn_Lang_ID ALIAS FOR $2;
  vMsgDesc VarChar( 250 );
Begin
  Select msg.Msg_Desc
  Into   vMsgDesc
  From   T_Msg msg
  Where  msg.Msg_ID = pn_Msg_ID
  And    msg.FK_Lang_ID = pn_Lang_ID;
  Return vMsgDesc;
  IF NOT FOUND THEN
   Return Null;
  END IF;
End;
' language 'plpgsql';
/

/* PROMPT *****[ Ending F_Msg.sql ]***** */
