/* Script Name : F_ItemGroup.sql.
   Author      : Manoj Doshi.
   Description : Functions related to the ItemGroup Table.
   Procedures  :
   Fuctions    : 
                  GetItemGroupName for ItemGroup_ID Returns ItemGroup_Name.
                  GetItemGroupDesc for ItemGroup_ID Returns ItemGroup_Desc.
                  GetItemGroupID   for ItemGroup_Name Returns ItemGroup_ID.
*/

/* PROMPT *****[ Starting F_ItemGroup.sql ]***** */

/* PROMPT *****[ Drop Function GetItemGroupName ]***** */

Drop Function GetItemGroupName ( Integer );

/* PROMPT ****[ Creating Function GetItemGroupName ]**** */

Create Function GetItemGroupName ( Integer ) Returns VarChar As '
Declare 
  pn_ItemGroup_ID Alias For $1; 
  vItemGroupName VarChar( 30 );
Begin
  Select itg.ItemGroup_Name
  Into   vItemGroupName
  From   T_ItemGroup itg
  Where  itg.ItemGroup_ID = pn_ItemGroup_ID;
  IF NOT FOUND THEN
    Return null;
  END IF;
  Return vItemGroupName;
End;
' language 'plpgsql';

/* PROMPT *****[ Drop Function GetItemGroupDesc ]***** */

Drop Function GetItemGroupDesc ( Integer );

/* PROMPT *****[ Creating Function GetItemGroupDesc ]**** */

Create Function GetItemGroupDesc ( Integer ) Returns VarChar As '
Declare
  pn_ItemGroup_ID Alias For $1;
  vItemGroupDesc VarChar( 100 );
Begin
  Select itg.ItemGroup_Desc
  Into   vItemGroupDesc
  From   T_ItemGroup itg
  Where  itg.ItemGroup_ID = pn_ItemGroup_ID;
  IF NOT FOUND THEN
    Return null;
  END IF;
  Return vItemGroupDesc;
End;
' language 'plpgsql';

/* PROMPT *****[ Drop Function GetItemGroupID ]***** */

Drop Function GetItemGroupID ( VarChar );

/* PROMPT *****[ Creating Function GetItemGroupID ]**** */

Create Function GetItemGroupID ( VarChar ) Returns Integer As '
Declare
  pv_ItemGroup_Name Alias For $1;
  nItemGroupID Integer;
Begin
  Select itg.ItemGroup_ID
  Into   nItemGroupID
  From   T_ItemGroup itg
  Where  itg.ItemGroup_Name = pv_ItemGroup_Name;
  IF NOT FOUND THEN
    Return null;
  END IF;
  Return nItemGroupID;
End;
' language 'plpgsql';
/

/* *****[ Ending F_ItemGroup.sql ]***** */
