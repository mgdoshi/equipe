/*
   Script Name : F_Address.sql.
   Author      : Manoj Doshi.
   Description : Functions related to the Address Table.
   Procedures  :
   Functions   : GetAddress for Address_ID   Returns Address.
*/

/* PROMPT *****[ Starting F_address.sql ]***** */

/* PROMPT *****[ Drop Function GetAddress ]***** */

Drop Function GetAddress( Integer );

/* PROMPT *****[ Creating Function GetAddress ]***** */

Create Function GetAddress ( Integer ) Returns VarChar AS '
Declare
  pn_Address_ID ALIAS FOR $1;
  vAddress VarChar( 500 );
Begin
  Select adr.Address1 || adr.Address2 || adr.Address3 || adr.Address4
  Into   vAddress
  From   T_Address adr
  Where  adr.Address_ID = pn_Address_ID;
  IF NOT FOUND THEN
    Return null;
  END IF;
  Return vAddress;
End;
' language 'plpgsql';
/

/* PROMPT *****[ Ending F_Address.sql ]***** */
