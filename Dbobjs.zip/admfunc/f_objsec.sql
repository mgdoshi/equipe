

DROP FUNCTION ChkObjSec(Integer,VarChar,VarChar,VarChar);

CREATE FUNCTION ChkObjSec(Integer,VarChar,VarChar,VarChar) RETURNS Integer AS '
Declare
  pn_UserID        ALIAS FOR $1;
  pv_ObjParentName ALIAS FOR $2;
  pv_ObjName       ALIAS FOR $3;
  pv_Mode          ALIAS FOR $4;

  nInsFlg Integer;
  nUpdFlg Integer;
  nDisFlg Integer;
  nUpNFlg Integer;
  cObjType Char(1);
  vObjParentName VarChar(100);
  vObjName       VarChar(100);

  nCnt          Integer;
  nAllowCnt     Integer;
  nDisAllowCnt  Integer;
BEGIN
  vObjParentName := pv_ObjParentName;
  vObjName       := pv_ObjName;

  IF pn_UserID ISNULL OR
     pv_ObjParentName ISNULL OR
     pv_ObjName ISNULL OR 
     pv_Mode ISNULL 
  THEN
    RETURN -1;
  END IF;

  Begin
    SELECT obs.DM_ObjType
    INTO   cObjType
    FROM   T_ObjSec obs
    WHERE  obs.ObjParent_Name = vObjParentName
    AND    obs.Obj_Name = vObjName
    AND    ROWNUM = 1;
    IF NOT FOUND THEN   
      RETURN 0; 
    END IF;
    IF cObjType ISNULL THEN
      RETURN 0;
    END IF;
  End;

  Begin
    SELECT obs.Display_Flg, obs.Insert_Flg, obs.Update_Flg, obs.UpdNull_Flg
    INTO   nDisFlg, nInsFlg, nUpdFlg, nUpNFlg
    FROM   T_ObjSec obs
    WHERE  obs.ObjParent_Name = vObjParentName
    AND    obs.Obj_Name = vObjName
    AND    obs.DM_SecLevel = ''S'';

    IF pv_Mode = ''Q'' THEN
      IF nDisFlg = 0 THEN
        RETURN 1;
      END IF;

    ELSIF pv_Mode = ''I'' THEN
      IF ( cObjType = ''K'' And nDisFlg = 0 ) OR 
         ( cObjType <> ''K'' And ( nDisFlg = 0 OR nInsFlg = 0 ) )
      THEN
        RETURN 1;
      END IF;

    ELSIF pv_Mode = ''U'' Then
      IF cObjType = ''K'' Then
        IF nDisFlg = 0 Then
          RETURN 1;
        END IF;
      Else
        IF nDisFlg = 0 Then
          RETURN 1;
        ELSIF nUpdFlg = 0 And nUpnFlg = 0 Then
          RETURN 2;
        ELSIF nUpdFlg = 0 And nUpnFlg = 1 Then
          RETURN 3;
        END IF;
      END IF;
    END IF;
    IF NOT FOUND THEN
      Return Null;
    End IF;
  END;

  Begin
    SELECT obs.Display_Flg, obs.Insert_Flg, obs.Update_Flg, obs.UpdNull_Flg
    INTO   nDisFlg, nInsFlg, nUpdFlg, nUpNFlg
    FROM   T_ObjSec obs
    WHERE  obs.ObjParent_Name = vObjParentName
    AND    obs.Obj_Name = vObjName
    AND    obs.DM_SecLevel = ''U''
    AND    obs.Ref_ID = pn_userID;

    IF pv_Mode = ''Q'' Then
      IF nDisFlg = 0 Then
        RETURN 1;
      END IF;
    ELSIF pv_Mode = ''I'' Then
      IF ( cObjType = ''K'' And nDisFlg = 0 ) OR 
         ( cObjType <> ''K'' And ( nDisFlg = 0 OR nInsFlg = 0 ) )
      Then
        RETURN 1;
      END IF;
    ELSIF pv_Mode = ''U'' Then
      IF cObjType = ''K'' Then
        IF nDisFlg = 0 Then
          RETURN 1;
        END IF;
      Else
        IF nDisFlg = 0 Then
          RETURN 1;
        ELSIF nUpdFlg = 0 And nUpnFlg = 0 Then
          RETURN 2;
        ELSIF nUpdFlg = 0 And nUpnFlg = 1 Then
          RETURN 3;
        END IF;
      END IF;
    END IF;
    IF NOT FOUND THEN
      Null;
    End IF;
  End;

  Begin
    SELECT SUM( obs.Display_Flg ), SUM( obs.Insert_Flg ), 
           SUM( obs.Update_Flg ), SUM( obs.UpdNull_Flg )
    INTO   nDisFlg, nInsFlg, nUpdFlg, nUpNFlg
    FROM   T_ObjSec obs
    WHERE  obs.ObjParent_Name = vObjParentName
    AND    obs.Obj_Name = vObjName
    AND    obs.DM_SecLevel = ''G''
    AND    obs.Ref_ID IN
             ( SELECT usg.FK_Group_ID
               FROM   T_UserGroup usg
               WHERE  usg.FK_User_ID = pn_UserID );

    IF pv_Mode = ''Q'' Then
      IF nDisFlg = 0 Then
        RETURN 1;
      END IF;
    ELSIF pv_Mode = ''I'' Then
      IF ( cObjType = ''K'' And nDisFlg = 0 ) OR 
         ( cObjType <> ''K'' And ( nDisFlg = 0 OR nInsFlg = 0 ) )
      Then
        RETURN 1;
      END IF;
    ELSIF pv_Mode = ''U'' Then
      IF cObjType = ''K'' Then
        IF nDisFlg = 0 Then
          RETURN 1;
        END IF;
      Else
        IF nDisFlg = 0 Then
          RETURN 1;
        ELSIF nUpdFlg = 0 And nUpnFlg = 0 Then
          RETURN 2;
        ELSIF nUpdFlg = 0 And nUpnFlg = 1 Then
          RETURN 3;
        END IF;
      END IF;
    END IF;
    IF NOT FOUND THEN
      Null;
    End IF;
  End;
  RETURN 0;
  IF NOT FOUND THEN
    RETURN -2;
  End IF;
END;
' language 'plpgsql';
/

/* PROMPT ****[ End Creating Function ChkObjSec ]***** */

/* PROMPT **********[ Ending F_ObjSec.sql ]******************** */

