/* Script Name : F_ItemPack.sql
   Author      : Manoj Doshi.
   Description : Functions related to the ItemPack Table.
   Procedures  :
   Fuctions    : 
                  GetItemPackName for ItemPack_ID Returns ItemPack_Name.
                  GetItemPackDesc for ItemPack_ID Returns ItemPack_Desc.
                  GetItemPackID   for ItemPack_Name Returns ItemPack_ID.
*/

/* PROMPT *****[ Starting F_ItemPack.sql ]***** */

/* PROMPT *****[ Drop Function GetItemPackName ]***** */

Drop Function GetItemPackName ( Integer );

/* PROMPT *****[ Creating Function GetItemPackName ]***** */

Create Function GetItemPackName ( Integer ) Returns VarChar AS '
Declare
  pn_ItemPack_ID ALIAS FOR $1; 
  vItemPackName VarChar( 30 );
Begin
  Select itp.ItemPack_Name
  Into   vItemPackName
  From   T_ItemPack itp
  Where  itp.ItemPack_ID = pn_ItemPack_ID;
  IF NOT FOUND THEN
    Return Null;
  END IF;
  Return vItemPackName;
END;
' language 'plpgsql';

/* PROMPT *****[ Drop Function GetItemPackDesc ]**** */

Drop Funtion GetItemPackDesc( Integer );

/* PROMPT *****[ Creating Function GetItemPackDesc ]***** */

Create Function GetItemPackDesc ( Integer ) Returns VarChar AS '
Declare
  pn_ItemPack_ID ALIAS FOR $1;
  vItemPackDesc VarChar2( 100 );
Begin
  Select itp.ItemPack_Desc
  Into   vItemPackDesc
  From   T_ItemPack itp
  Where  itp.ItemPack_ID = pn_ItemPack_ID;
  IF NOT FOUND THEN
    Return Null;
  END IF;
  Return vItemPackDesc;
End;
' language 'plpgsql';

/* PROMPT *****[ Drop Function GetItemPackID ]***** */

Drop Function GetItemPackID( VarChar );

/* PROMPT *****[ Creating Function GetItemPackID ]***** */

Create Function GetItemPackID ( VarChar ) Returns Integer AS '
Declare
  pv_ItemPack_Name ALIAS FOR $1;
  nItemPackID Integer;
Begin
  Select itp.ItemPack_ID
  Into   nItemPackID
  From   T_ItemPack itp
  Where  itp.ItemPack_Name = pv_ItemPack_Name;
  IF NOT FOUND THEN
    Return Null;
  END IF;
  Return nItemPackID;
End;
' language 'plpgsql';
/

/* PROMPT *****[ Ending F_ItemPack.sql ]***** */
