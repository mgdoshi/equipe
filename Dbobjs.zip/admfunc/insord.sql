CREATE FUNCTION InsOrd ( Integer ) RETURNS Boolean AS '
DECLARE
  i Integer;
  n Integer;
BEGIN

  For i in 1..1000 Loop
    n := NextVal( ''S_Order'' );

    Insert Into T_Order
	  ( Order_ID, Order_Nr, Order_Dt, FK_Employee_ID, FK_Client_ID, DM_OrdStat, Text1, FK_RecSec_ID )
	Values
	  ( n, n, now(), 8, 14, ''O'', ''Test Order'', 4 );

	Insert Into T_OrderDtls
	  ( OrderDtls_ID, FK_Order_ID, Pos_Nr, FK_Item_ID, FK_ItemPack_ID, Quantity, DM_UnitType, UnitPrice,
	    Text1, FK_RecSec_ID )
	Values
	  ( NextVal( ''S_OrderDtls'' ), n, 1, 49, 7, 1, ''K'', 1, ''Test Order Dtl'', 4 );

	Insert Into T_OrderDtls
	  ( OrderDtls_ID, FK_Order_ID, Pos_Nr, FK_Item_ID, FK_ItemPack_ID, Quantity, DM_UnitType, UnitPrice,
	    Text1, FK_RecSec_ID )
	Values
	  ( NextVal( ''S_OrderDtls'' ), n, 2, 50, 7, 1, ''K'', 1, ''Test Order Dtl'', 4 );

  End Loop;
  Return TRUE;
END;
' language 'plpgsql';
/
