/* Script Name : F_RecSec.sql.
   Author      : Manoj Doshi.
   Description : Functions related to the RecSec Table.
   Procedures  :
   Functions   : 
                  GetRecSecName for RecSec_ID Returns RecSec_Name.
                  GetRecSecDesc for RecSec_ID Returns RecSec_Desc.
                  GetRecSecID   for RecSec_Name Returns RecSec_ID.
*/

/* PROMPT *****[ Starting F_RecSec.sql ]***** */

/* PROMPT *****[ Drop Function GetRecSecName ]***** */

Drop Funtion GetRecSecName ( Integer );

/* PROMPT *****[ Creating Function GetRecSecName ]***** */

Create Function GetRecSecName ( Integer ) Returns VarChar AS '
Declare
  pn_RecSec_ID ALIAS FOR $1;
  vRecSecName VarChar( 30 );
Begin
  Select rsc.RecSec_Name
  Into   vRecSecName
  From   T_RecSec rsc
  Where  rsc.RecSec_ID = pn_RecSec_ID;

  IF NOT NULL THEN
    Return Null;
  END IF;

  Return vRecSecName;
End;
' language 'plpgsql';

/* PROMPT *****[ Drop Function GetRecSecDesc ]***** */

Drop Function GetRecRecDesc ( Integer );

/* PROMPT *****[ Creating Function GetRecSecDesc ]***** */

Create Function GetRecSecDesc ( Integer ) Returns VarChar AS '
Declare
  pn_RecSec_ID ALIAS FOR $1; 
  vRecSecDesc VarChar( 100 );
Begin
  Select rsc.RecSec_Desc
  Into   vRecSecDesc
  From   T_RecSec rsc
  Where  rsc.RecSec_ID = pn_RecSec_ID;

  IF NOT NULL THEN
    Return Null;
  END IF;

  Return vRecSecDesc;
End;
' language 'plpgsql';

/* PROMPT *****[ Drop Function GetRecSecID ]***** */

Drop Function GetRecSecID( VarChar );

/* PROMPT *****[ Creating Function GetRecSecID ]***** */

Create Function GetRecSecID ( VarChar ) Returns Integer AS '
Declare
  pv_RecSec_Name ALIAS FOR $1;
  nRecSecID Integer;
Begin
  Select rsc.RecSec_ID
  Into   nRecSecID
  From   T_RecSec rsc
  Where  rsc.RecSec_Name = pv_RecSec_Name;

  IF NOT NULL THEN
    Return Null;
  END IF;

  Return nRecSecID;
End;
' language 'plpgsql';
/

/* PROMPT *****[ Ending F_RecSec.sql ]******/
