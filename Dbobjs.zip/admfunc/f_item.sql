/* Script Name : F_Item.sql.
   Author      : Manoj Doshi.
   Description : Functions related to the Item Table.
   Procedures  :
   Fuctions    : 
                  GetItemName for Item_ID Returns Item_Name.
                  GetItemDesc for Item_ID Returns Item_Desc.
                  GetItemID   for Item_Name Returns Item_ID.

*/

/* PROMPT *****[ Starting F_Item.sql ]***** */

/* PROMPT *****[ Drop Function GetItemName ]***** */

Drop function GetItemName( Integer );

/* PROMPT ******[ Creating Function GetItemName ] *** */

Create Function GetItemName ( Integer ) Returns VarChar As '
Declare
  pn_Item_ID Alias For $1;
  vItemName VarChar( 30 );
Begin
  Select itm.Item_Name
  Into   vItemName
  From   T_Item itm
  Where  itm.Item_ID = pn_Item_ID;  
  If Not Found Then
    Return Null;
  End If;
  Return vItemName;
End;
' language 'plpgsql';

/* PROMPT *****[ Drop Function GetItemDesc ]***** */

Drop function GetItemDesc( Integer );

/* PROMPT ******[ Creating Function GetItemDesc ] *** */

Create Function GetItemDesc ( Integer ) Returns VarChar As '
Declare
  pn_Item_ID Alias for $1;
  vItemDesc VarChar( 100 );
Begin
  Select itm.Item_Desc
  Into   vItemDesc
  From   T_Item itm
  Where  itm.Item_ID = pn_Item_ID;
  If Not Found Then
    Return Null;
  End If;
  Return vItemDesc;
End;
' language 'plpgsql';

/* PROMPT *****[ Drop Function GetItemID ]***** */

Drop Function GetItemID( VarChar );

/* PROMPT ******[ Creating Function GetItemID ] *** */

Create Function GetItemID ( VarChar ) Returns Integer As ' 
Declare
  pv_Item_Name Alias For $1;
  nItemID Integer;
Begin
  Select itm.Item_ID
  Into   nItemID
  From   T_Item itm
  Where  itm.Item_Name = pv_Item_Name;
  If Not Found Then
    Return Null;
  End If;
  Return nItemID;
End;
' language 'plpgsql';
/

/* *****[ Ending F_Item.sql ]***** */
