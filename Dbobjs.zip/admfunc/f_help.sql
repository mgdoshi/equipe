/* Script Name : F_Help.sql.
   Author      : Manoj Doshi.
   Description : Functions related to the Help Table.
   Procedures  :
   Fuctions    : 
                  GetColumnMenuPath Returns Menu_Path.
*/

/* PROMPT ********[ Starting F_Help.sql ]**** */

/* PROMPT ********[ Drop Funtion GetColumnMenuPath ]**** */

DROP FUNCTION GetColumnMenuPath( Integer );

/* PROMPT ********[ Creating Funtion GetColumnMenuPath ]**** */

CREATE FUNCTION GetColumnMenuPath( Integer ) RETURNS VarChar AS '
Declare
  pnHelpID ALIAS FOR $1;
  nParentID Integer := 1;
  vCaption  VarChar(100);
  vColPath  VarChar(3000);
  nCurrID   Integer := pnHelpId;
BEGIN

  While nParentID <> 0 Loop
    Begin
      SELECT hlp.Parent_ID, hlp.Caption
      INTO   nParentID, vCaption
      FROM   T_Help hlp
      WHERE  hlp.Help_ID = nCurrID;

      vColPath := vCaption || ''|'' || vColPath;
      nCurrId  := nParentId;

      IF NOT FOUND THEN  
        Return Null;
      End IF;
    END;
  End Loop;

  Return substring( vColPath, 1, char_length ( vColPath )  - 1 ) ;

END;
' language 'plpgsql';
/

/* PROMPT ********[ Ending F_Help.sql ]**** */
