/* Script Name : F_CostCentre.sql.
   Author      : Manoj Doshi.
   Description : Functions related to the CostCentre Table.
   Procedures  :
   Fuctions    : 
                  GetCostCentreName for CostCentre_ID Returns CostCentre_Name.
                  GetCostCentreDesc for CostCentre_ID Returns CostCentre_Desc.
                  GetCostCentreID   for CostCentre_Name Returns CostCentre_ID.
*/

/* PROMPT *****[ Starting F_CostCentre.sql ]***** */

/* PROMPT *****[ Drop Function GetCostCentreName ]***** */

DROP FUNCTION GetCostCentreName( Integer );

/* PROMPT *****[ Creating Function GetCostCentreName ]***** */

Create Function GetCostCentreName( Integer ) Returns VarChar AS '
Declare
  pn_CostCentre_ID ALIAS FOR $1;
  vCostCentreName VarChar( 30 );
Begin
  Select cst.CostCentre_Name
  Into   vCostCentreName
  From   T_CostCentre cst
  Where  cst.CostCentre_ID = pn_CostCentre_ID;
  IF NOT FOUND THEN
    Return Null;
  END IF;
  Return vCostCentreName;
End;
' language 'plpgsql';

/* PROMPT *****[ Drop Function GetCostCentreDesc ]***** */

DROP FUNCTION GetCostCentreDesc( Integer );

/* PROMPT *****[ Creating Function GetCostCentreDesc ]***** */

Create Function GetCostCentreDesc( Integer ) Returns VarChar AS '
Declare
  pn_CostCentre_ID ALIAS FOR $1;
  vCostCentreDesc VarChar( 100 );
Begin
  Select cst.CostCentre_Desc
  Into   vCostCentreDesc
  From   T_CostCentre cst
  Where  cst.CostCentre_ID = pn_CostCentre_ID;
  IF NOT FOUND THEN
    Return Null;
  END IF;
  Return vCostCentreDesc;
End;
' language 'plpgsql';

/* PROMPT *****[ Drop Function GetCostCentreID ]***** */

DROP FUNCTION GetCostCentreID( VarChar );

/* PROMPT *****[ Creating Function GetCostCentreID ]***** */

Create Function GetCostCentreID( VarChar ) Returns Integer AS '
Declare
  pv_CostCentre_Name ALIAS FOR $1;
  nCostCentreID Number;
Begin
  Select cst.CostCentre_ID
  Into   nCostCentreID
  From   T_CostCentre cst
  Where  cst.CostCentre_Name = pv_CostCentre_Name;
  IF NOT FOUND THEN
    Return Null;
  END IF;
  Return nCostCentreID;
End;
' language 'plpgsql';
/

/* PROMPT *****[ Ending F_CostCentre.sql ]***** */
