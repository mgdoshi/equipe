/* Script Name : AllTabs.sql
   Author      : Manoj Doshi.
   Description : Script to create all the tables.
*/

/* Prompt *****[ Creating Table T_Address ]***** */

CREATE TABLE T_ClsTempl
( 
  Ref_Id              Integer      NOT NULL,
  Templ_Name          VarChar(30)  NOT NULL,
  Text1               VarChar(100) ,
  Text2               VarChar(100) ,
  Text3               VarChar(100) ,
  Text4               VarChar(100) ,
  Text5               VarChar(100) ,
  Text6               VarChar(100) ,
  Text7               VarChar(100) ,
  Text8               VarChar(100) ,
  Text9               VarChar(500) ,
  Text10              VarChar(500) ,
  Flag1               Char(1)      ,
  Flag2               Char(1)      ,
  Flag3               Char(1)      ,
  Flag4               Char(1)      ,
  Flag5               Char(1)      ,
  Flag6               Char(1)      ,
  Flag7               Char(1)      ,
  Flag8               Char(1)      ,
  Flag9               Char(1)      ,
  Flag10              Char(1)      ,
  Num1                Integer      ,
  Num2                Integer      ,
  Num3                Integer      ,
  alias_name          VarChar(30) NOT NULL 
);
/* Prompt*****[ Ending AllTabs.sql ]***** */
