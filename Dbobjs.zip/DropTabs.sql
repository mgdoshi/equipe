/* Script Name : DropTabs.sql
   Author      : Manoj Doshi.
   Description : Script to drop all the tables.
*/

/* Prompt *****[ Dropping All Tables  ]***** */

DROP TABLE T_Address;
DROP TABLE T_AddressRef;
DROP TABLE T_Audit;
DROP TABLE T_Branch;
DROP TABLE T_CartDef;
DROP TABLE T_Client;
DROP TABLE T_ClientItem;
DROP TABLE T_ClientItemRate;
DROP TABLE T_Config;
DROP TABLE T_CostCentre;
DROP TABLE T_Delivery;
DROP TABLE T_DeliveryDtls;
DROP TABLE T_OrderDelivery;
DROP TABLE T_DataLog;
DROP TABLE T_DataLogTrace;
DROP TABLE T_Domain;
DROP TABLE T_EmployeeFunc;
DROP TABLE T_Employee;
DROP TABLE T_Group;
DROP TABLE T_Help;
DROP TABLE T_Item;
DROP TABLE T_ItemClass;
DROP TABLE T_ItemGroup;
DROP TABLE T_ItemPack;
DROP TABLE T_ItemRate;
DROP TABLE t_lang;
DROP TABLE T_MenuSecRef;
DROP TABLE T_MenuSec;
DROP TABLE T_Msg;
DROP TABLE T_MsgCon;
DROP TABLE T_News;
DROP TABLE T_ObjSec;
DROP TABLE T_Order;
DROP TABLE T_OrderDtls;
DROP TABLE T_Param;
DROP TABLE T_RecSec;
DROP TABLE T_RecSecPriv;
DROP TABLE T_UserEmployee;
DROP TABLE T_UserClient;
DROP TABLE T_UserItem;
DROP TABLE T_ObjSecRef;
DROP TABLE T_Scheme;
DROP TABLE T_SchemeRef;
DROP TABLE T_ScriptSource;
DROP TABLE T_Template;
DROP TABLE T_TemplateDtls;
DROP TABLE T_Trans;
DROP TABLE T_User;
DROP TABLE T_UserGroup;
DROP TABLE T_UserParam;

/* Prompt*****[ Ending DropTabs.sql ]***** */
