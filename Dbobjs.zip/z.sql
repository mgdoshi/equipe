insert into t_branch ( branch_id, branch_name, branch_desc )
values ( 1, 'x', 'x');
commit;

